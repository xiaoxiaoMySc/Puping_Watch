#include "menu.h"
#include "sys.h"               
#include "stm32f10x.h"
#include <math.h>
#include<main.h>
#include<MyRTC.h>
#include<bmp280.h>
#include<Game_Snake.h>
#include<mainmax.h>
#include<game4.h>
#include<game5.h>
#include<game7.h>
#include<music.h>
#include<game6.h>
#include<game4.h>
int dhxg=0;
int8_t Speed_Factor = 12;				//��궯���ٶ�ϵ��;
float  Roll_Speed = 1.3;				   //���������ٶ�ϵ��;



float Actual;
		 float Error1;
	 float Error0;
float Target=0;
 float ErrorInt;
float Kp;
	float Ki;
float Kd;
float Out;
				 int sysj1=0;







float sydhth(int mod)
{
	
	
	if(mod==1)
	{
	Actual +=sysj1;
			
			Error1 = Error0;
	
			Error0 =Target- Actual;
			
			if (Ki != 0)
			{
				ErrorInt += Error0;
			}
			else
			{
				ErrorInt = 0;
			}
			
			Out = Kp * Error0 + Ki * ErrorInt + Kd * (Error0 - Error1);
	
	
	sysj1=Out;
	
		}
	
				return Out;

}





uint8_t d1=9,d2=1,yiup=0,xiup,ytup=0,xtup,s1;
                                                                                                                                               
int8_t menu_Roll_event(void){if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)==0){if(yiup){if(xiup>s1){s1=d2;xiup=0;return 1;}else{xiup++;return 0;}}else{yiup=1;xiup=0;s1=d1;return 1;}}else{yiup=0;}if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)==0){if(ytup){if(xtup>s1){s1=d2;xtup=0;return -1;}else{xtup++;return 0;}}else{ytup=1;xtup=0;s1=d1;return -1;}}else{ytup=0;}return 0;}
																																						
uint8_t yu=0,xu,upp=0,s2;

  
int8_t menu_Enter_event(void){if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)==0){if(upp==0){if(yu){if(xu>s2){upp=1;return 2;}else{xu++;return 0;}}else{yu=1;xu=0;s2=d1;return 0;}}else{return 0;}}else{if(yu){if(upp){yu=0;upp=0;return 0;}else{yu=0;return 1;}}return 0;}}


/////////////////////
void xs_fc2(cd2OptionTypeDef *zz2)
{
	

dack=0;
	dackdh();
	dack=0;
LK=0;

	while(1)
	{
	static	int KEY;
static	int xb=0;
static	 int xsnumber=0;
static	int xsshow=0;
static	float dhyyy,dhyyy1,dhxxx,dhxxx1;
static	float dhyyy2,dhyyy3,dhxxx2,dhxxx3;
	static		float fk,fk1=12,hx,hx1=80,fkpy,fkpy1=-60;
		static int cdsx=0;
		int fangkuang_x=-38,fangkuang_y=8;
lightdh();
	KEY=menu_Roll_event();
	if(KEY==-1)
	{fk=0;
		hx=80;
		xb++;        fkpy=0;

	}
	if(KEY==1)
	{fk=0;
        fkpy=-120;
		hx=80;
		xb--;
	}
	
	
	if(xb>xsnumber)
		xb=0;
if(xb<0)
		xb=xsnumber;
	
	
	KEY=menu_Enter_event();
	if(KEY==1)
	{
		
		zz2[xb].func();






	}
	if(xb==0&&KEY==1)
		{			
			dack=0;
	dackdh();
	dack=0;
LK=0;
			xsnumber=0;xsshow=0;cdsx=0;
			return ;
		}
	////////////////
		if(cdsx==0)
		{
	for( xsnumber=0;  zz2[xsnumber].String!=".";xsnumber++);

	
	
	xsnumber--;
			cdsx=1;
		}
		OLED_Clear();

//zfdh();


	
	for(xsshow=0;xsshow<=xsnumber	;	xsshow++)
	{
		static float ui_x,ui_1;
		
		dhyyy3=xb*65;
		dhxxx3=xb*50;
		dhyyy2+=(dhyyy3-dhyyy2)/1;
		dhxxx2+=(dhxxx3-dhxxx2)/1;
dhyyy1=dhyyy2;
		dhxxx1=dhxxx2;

		dhyyy+=(dhyyy1-dhyyy)/33;

				dhxxx+=(dhxxx1-dhxxx)/33;

				ui_x=83+xsshow*50-(dhxxx+=1);
                 ui_1=83+xsshow*65-(dhyyy+=1);
	//OLED_ShowString1(60,95+xsshow*64-(dhyyy+=1),zz2[xsshow].String,OLED_8X16);
		OLED_ShowString1(-ui_1+114,48,zz2[xsshow].String,OLED_8X16);
				OLED_ClearArea(0,48,62,16);

	//OLED_ClearArea(60,0,68,48);
		//OLED_ShowString1(60,48,zz2[xsshow].String,OLED_8X16);

OLED_ShowImage(ui_x,14,32,32,zz2[xsshow].pc);	
	//OLED_ReverseArea(0,0,ui_x,10);

//		OLED_ClearArea(108,0,28,64);
//OLED_ShowImage(5+xsshow*128-(dhxxx+=1),10+xsshow*64-(dhyyy+=1),128,64,zz2[xsshow].pc);
	}
	/////////////
//		OLED_ClearArea(108,0,28,64);
	fk+=(fk1-fk)/4;
		fkpy+=(fkpy1-fkpy)/4;

    OLED_DrawLine(-10+68+fk-fangkuang_x+fkpy,-10+20+fk-fangkuang_y,-10+77+fk-fangkuang_x+fkpy,-10+20+fk-fangkuang_y);
	OLED_DrawLine(68+(-10+fk)-fangkuang_x+fkpy,20+(-10+fk)-fangkuang_y,68+(-10+fk)-fangkuang_x+fkpy,29+(-10+fk)-fangkuang_y);
	
	OLED_DrawLine(68+(-10+fk)-fangkuang_x+fkpy,58-(-10+fk)-fangkuang_y,77+(-10+fk)-fangkuang_x+fkpy,58-(-10+fk)-fangkuang_y);
	OLED_DrawLine(68+(-10+fk)-fangkuang_x+fkpy,58-(-10+fk)-fangkuang_y,68+(-10+fk)-fangkuang_x+fkpy,49-(-10+fk)-fangkuang_y);

	OLED_DrawLine(108-(-10+fk)-fangkuang_x+fkpy,20+(-10+fk)-fangkuang_y,99-(-10+fk)-fangkuang_x+fkpy,20+(-10+fk)-fangkuang_y);
	OLED_DrawLine(108-(-10+fk)-fangkuang_x+fkpy,20+(-10+fk)-fangkuang_y,108-(-10+fk)-fangkuang_x+fkpy,29+(-10+fk)-fangkuang_y);
	
	OLED_DrawLine(108-(-10+fk)-fangkuang_x+fkpy,58-(-10+fk)-fangkuang_y,99-(-10+fk)-fangkuang_x+fkpy,58-(-10+fk)-fangkuang_y);
	OLED_DrawLine(108-(-10+fk)-fangkuang_x+fkpy,58-(-10+fk)-fangkuang_y,108-(-10+fk)-fangkuang_x+fkpy,49-(-10+fk)-fangkuang_y);

timer_apper2();

///////////////////
dh=dhfy;
(*dh)(1);
//////////////////////////
hx+=(hx1-hx)/5;
		OLED_DrawLine(0-(-80+hx),10,98,10);

		OLED_DrawLine(104,13,127,13);
		OLED_DrawLine(98,10,104,13);


		OLED_DrawLine(0-(-80+hx),47,44-(-80+hx),47);
			OLED_DrawLine(44-(-80+hx),47,52-(-80+hx),63);
/////////////////
if(fx_set==1)
		OLED_Reverse();	

	OLED_Update();
	//delay_ms(10);
}		

	} 
/////////////////////



/* 

	void xs_fc(cdOptionTypeDef *zz)
{ 
	
	
dack=0;
	dackdh();
	dack=0;
LK=0;
	while(1)
	{
		static int KEY;
static	int xb=0;
static	 int xsnumber=0;
static	int xsshow=0;
	static int gb=0;
static float dhx,dhx1,dhy,dhy1;		
static	float dhyy,dhyy1;
static float jmdh,jmdh1=128;
	static	float jmdh2,jmdh3=128;

static	int pb,pb1;
		static int cdsx=0;
				static float fk_zf_dh_y;

		sysj=0;
lightdh();
	KEY=menu_Roll_event();
	if(KEY==-1)
	{
		gb++;
		xb++;
	}
	if(KEY==1)
	{
		gb--;
		xb--;
	}
	
	
	if(xb>xsnumber)
		xb=xsnumber;
if(xb<0)
		xb=0;
	if(xsnumber>=3)
	{
	if(gb>3)
		gb=3;
if(gb<0)
		gb=0;
}
	else{
		if(gb>xsnumber)
		gb=xsnumber;
if(gb<0)
		gb=0;
		
	}
	KEY=menu_Enter_event();
	if(KEY==1)
	{jmdh=0;			jmdh2=0;
cdsx=0;
					xsnumber=0;xsshow=0;

		zz[xb].func();
	}
	if(xb==0&&KEY==1)
		{			dack=0;
	dackdh();
	dack=0;
LK=0;
			jmdh=0;			jmdh2=0;
cdsx=0;
		
			
			
			xb=0;xsnumber=0;xsshow=0;gb=0;
			return ;
		}
	////////////////
	



if(cdsx==0)
{
	for( xsnumber=0;  zz[xsnumber].String!=".";xsnumber++);

	
	
	xsnumber--;
	
		cdsx=1;
}
	OLED_Clear();
zfdh();

	for(xsshow=0;xsshow<=xsnumber	;	xsshow++)
	{
		dhyy1=(xb-gb)*16;

		dhyy+=(dhyy1-dhyy)/50;
		jmdh2+=(jmdh3-jmdh2)/30;
		fk_zf_dh_y=51+xsshow*16-(dhyy+=1);
			 		OLED_DrawRectangle(0,0,160,fk_zf_dh_y,OLED_UNFILLED);

		     OLED_ShowString1(0+128-jmdh2,fk_zf_dh_y,zz[xsshow].String,OLED_8X16);


		/////////////
dhx1=strlen(zz[xb].String)*8;
dhy1=gb*16;
	////////////////// 
	
	
}
////////////

	/////////////
	
	pb1=64*xb/xsnumber;
			pb+=(pb1-pb)/4;
		jmdh+=(jmdh1-jmdh)/5;
OLED_ClearArea(110,0,18,64);
//OLED_ReverseArea(-128+124+jmdh,0,4,pb++);
OLED_DrawRectangle(-128+124+jmdh,0,4,pb++,OLED_FILLED);
	OLED_DrawLine(127-128+jmdh,0,124-128+jmdh,0);
		OLED_DrawLine(127-128+jmdh,0,127-128+jmdh,63);
	OLED_DrawLine(127-128+jmdh,63,124-128+jmdh,63);
		
	//////////////
	dhx+=(dhx1-dhx)/8;
		dhy+=(dhy1-dhy)/8;
if(gb_tb==0)
		     OLED_ShowString1(-3+dhx++,+dhy++,"<--",OLED_6X8);////////
	if(gb_tb==1)
		     OLED_ShowString1(-3+dhx++,+dhy++,"<<<",OLED_6X8);////////
	if(gb_tb==2)
		OLED_ReverseArea(7,+dhy++,-11+dhx++,16);
	
	if(fx_set==1)
		OLED_Reverse();
		OLED_DrawRectangle(1,1,110,63,OLED_UNFILLED);
	OLED_Update();delay_ms(10);
}		
}



*/







    //����ѡ��������;//
uint8_t Get_NameLen(char* String)
{
	uint8_t i = 0, len = 0;
	while(String[i] != '\0')			        //�����ַ�����ÿ���ַ�
	{
		if(String[i] > '~'){len += 2; i += 2;}//���������Ӣ���ַ�����ΪGB2312�����ʽ���ȼ�2��i+=2����UTF-8�����ʽ���3
		else{len += 1; i += 1;}				 //����Ӣ���ַ����ȼ�1
	}
	return len;
}












/**
  * �� �����˵�����
  * �� ����ѡ���б�
  * ˵ ������ѡ���б���ʾ����,�����ݰ����¼�ִ����Ӧ����
  */
void xs_fc(struct option_class2* option)
{
	
	
dack=0;
	dackdh();
	dack=0;
LK=0;
	int8_t  Catch_i = 1;		   //ѡ���±�
	int8_t  Cursor_i = 0;	      //����±�
	int8_t  Show_i = 0; 		 //��ʾ��ʼ�±�
	int8_t  Max = 0;			//ѡ������
	int8_t  Roll_Event = 0;	   //�����¼�
	uint8_t Prdl ;            //���������񳤶� 
	float  mubiao = 0 , mubiao_up = 0;   //Ŀ����������ȣ��ϴν���������

	
	
	while(option[++Max].Name[0] != '.');    	       //��ȡ��Ŀ����,����ļ�����ͷΪ'.'��Ϊ��β;
	Max--;											  //����ӡ".."
	
	for(int8_t i = 0; i <= Max; i++)				//����ѡ��������;
	{		
		option[i].NameLen = Get_NameLen(option[i].Name);
	}
	
	static float Cursor_len_d0 = 0, Cursor_len_d1 = 0, Cursor_i_d0 = 0, Cursor_i_d1 = 0;//���λ�úͳ��ȵ�����յ�
	
	int8_t Show_d = 0, Show_i_temp = Max;				        //��ʾ�������
		
	Prdl = 64/Max;	  // ��Ļ�߶� / ��Ŀ����
	
	
	while(1)
	{
		lightdh();

		OLED_Clear();
		
		Roll_Event = menu_Roll_event();				      //��ȡ�����¼�
		if(Roll_Event)							         //����а����¼�
		{					sysj1=-50;

			Cursor_i -= Roll_Event;					   //�����±�
			Catch_i -= Roll_Event;
			
			if(Catch_i < 0) {Catch_i = 0;}			//����ѡ���±�
			if(Catch_i > Max) {Catch_i = Max;}
			
			if(Cursor_i < 0) {Cursor_i = 0;}     //���ƹ��λ��
			if(Cursor_i > 3) {Cursor_i = 3;}
			if(Cursor_i > Max) {Cursor_i = Max;}
		}
		
	/**********************************************************/
	/*��ʾ���*/
		
		Show_i = Catch_i - Cursor_i;			    //������ʾ��ʼ�±�
  			                                       
		
		if(Show_i - Show_i_temp)			     //����±���ƫ��
		{
			Show_d = (Show_i - Show_i_temp) * MEHE;
			Show_i_temp = Show_i;
		}
		if(Show_d) {Show_d /= Roll_Speed;}	//�����仯�ٶ�
		
		for(int8_t i = 0; i < 5; i++)	  //������ʾѡ�����Ͷ�Ӧ����
		{	
			if(Show_i + i > Max ) {break;}			
			OLED_ShowString1(2, (i* MEHE)+Show_d +2, option[Show_i + i].Name, OLED_8X16);
						 		OLED_DrawRectangle(0,0,160,(i* MEHE)+Show_d +2,OLED_UNFILLED);
OLED_ClearArea(110,0,18,64);
			
			if( option[Show_i + i].mode == ON_OFF )  				//����ǿ�����
			{
				 OLED_DrawRectangle(96, (i* MEHE)+Show_d +4, 12, 12, OLED_UNFILLED);
				if( *( option[Show_i + i].Num) )    				//������ش�(����ֵΪ��)
				{
					OLED_DrawRectangle(99, (i* MEHE)+Show_d +7, 6, 6, OLED_FILLED);
				}
			}
			else if( option[Show_i + i].mode == 3 )   				//����Ǳ�����
			{
				//�����λ��Ϊ��
				if ( *( option[Show_i + i].Num) / OLED_Pow(10, 3 - 0 - 1) % 10 )              
				OLED_ShowNum(92, (i* MEHE)+Show_d +6, *( option[Show_i + i].Num), 3, OLED_6X8);
				//���ʮλ��Ϊ��
				else if ( *( option[Show_i + i].Num) / OLED_Pow(10, 3 - 1 - 1) % 10 )
				OLED_ShowNum(95, (i* MEHE)+Show_d +6, *( option[Show_i + i].Num), 2, OLED_6X8);
				//�����λ��Ϊ��
				else if ( *( option[Show_i + i].Num) / OLED_Pow(10, 3 - 2 - 1) % 10 )
				OLED_ShowNum(98, (i* MEHE)+Show_d +6, *( option[Show_i + i].Num), 1, OLED_6X8);
				
				else   
				OLED_ShowNum(98, (i* MEHE)+Show_d +6, 0, 1, OLED_6X8);
			}
		}
		
		
		
		
		
	/**********************************************************/
	/*������*/
		
	
		Cursor_i_d1 = Cursor_i * MEHE;						//��ѯ���Ŀ��λ��
		Cursor_len_d1 = option[Catch_i].NameLen * WORD_H + 4;	   //��ѯ���Ŀ�����
		
		/*����˴�ѭ�����λ��*///�����ǰλ�ò���Ŀ��λ��,��ǰλ����Ŀ��λ���ƶ�
		if((Cursor_i_d1 - Cursor_i_d0) > 1) {Cursor_i_d0 += (Cursor_i_d1 - Cursor_i_d0) / Speed_Factor + 1;}		
		else if((Cursor_i_d1 - Cursor_i_d0) < -1) {Cursor_i_d0 += (Cursor_i_d1 - Cursor_i_d0) / Speed_Factor - 1;}
		else {Cursor_i_d0 = Cursor_i_d1;}
		
		/*����˴�ѭ��������*/
		if((Cursor_len_d1 - Cursor_len_d0) > 1) {Cursor_len_d0 += (Cursor_len_d1 - Cursor_len_d0) / Speed_Factor + 1;}
		else if((Cursor_len_d1 - Cursor_len_d0) < -1) {Cursor_len_d0 += (Cursor_len_d1 - Cursor_len_d0) / Speed_Factor - 1;}
		else {Cursor_len_d0 = Cursor_len_d1;}
	
		if(dhxg==1)
		{Kp=0.06;
	 Ki=0.06;
 Kd=0.06;
if(gb_tb==0)
		     OLED_ShowString1(Cursor_len_d0+3+sydhth(1),Cursor_i_d0+7+sydhth(1),"<-",OLED_6X8);////////
	if(gb_tb==1)
		     OLED_ShowString1(Cursor_len_d0+3+sydhth(1),Cursor_i_d0+7+sydhth(1),"<--",OLED_6X8);////////
	if(gb_tb==2)
		OLED_ReverseArea(0+sydhth(1),Cursor_i_d0+2+sydhth(1),Cursor_len_d0+3+sydhth(1),16+sydhth(1));
	
		}
	if(dhxg==0)
		{if(gb_tb==0)
		     OLED_ShowString1(Cursor_len_d0+3,Cursor_i_d0+7,"<-",OLED_6X8);////////
	if(gb_tb==1)
		     OLED_ShowString1(Cursor_len_d0+3,Cursor_i_d0+7,"<--",OLED_6X8);////////
	if(gb_tb==2)
		OLED_ReverseArea(0,Cursor_i_d0+2,Cursor_len_d0+3,16);}

		    // OLED_ShowString1(Cursor_len_d0+3,Cursor_i_d0+7,"<-",OLED_6X8);////////

		OLED_DrawRectangle(1,1,110,63,OLED_UNFILLED);
		
							
	/**********************************************************/
		//������//
			
		if(Catch_i== Max) {mubiao = 64 ;}	
		else{ mubiao = Prdl * Catch_i ;}
		
		if(mubiao_up<mubiao) { mubiao_up += 1.4 ;}
		if(mubiao_up>mubiao) { mubiao_up -= 1.4 ;}
		
		OLED_DrawLine(123, 0, 127, 0);
		OLED_DrawLine(125, 0, 125, 63);  
		OLED_DrawLine(123, 63, 127, 63);  

		OLED_DrawRectangle(123, 0, 5, mubiao_up, OLED_FILLED);
		
	/**********************************************************/
	   //ˢ����Ļ//	
	 // delay_ms(6);

	   
	if(fx_set==1)
		OLED_Reverse();


		OLED_Update();
		
		
	/**********************************************************/
	   //��ȡ����//
		if(menu_Enter_event())			                  	
		{					sysj1=-50;

			if( option[Catch_i].mode == Function )          //����ǿɽ��뺯��
			{
				/*������ܲ�Ϊ����ִ�й���,���򷵻�*/
				if(option[Catch_i].func) 
				{
					
						
					option[Catch_i].func();
					

				}
				else 
				{
				
					
	
dack=0;
	dackdh();
	dack=0;
LK=0;
					return;
				}
			}
			else if( option[Catch_i].mode == ON_OFF )                    //����ǿ���
			{
				
				*( option[Catch_i].Num) =  !*( option[Catch_i].Num);  //��ǰ����ȡ��
				
				if( option[Catch_i].func){option[Catch_i].func();} //ִ�й���һ��
				
			}
			else if( option[Catch_i].mode == Number )            //����Ǳ���
			{
				
				
				//�ڲ��ı���������//
				int8_t p;
				float NP=0 , NP_target = 96;               //��������С��Ŀ�����С
				float GP=0 , GP_target ;                 //�����������ȣ�Ŀ����������
//				float tap = 80/255;	     				 //��������	0.31
				
				
				
				while(1) 								
				{
					if( NP < NP_target )              //����������û����
					{
						if( NP_target - NP > 25 ) NP += 5 ;
						else if( NP_target - NP > 5 ) NP += 2.5 ;
						else if( NP_target - NP > 0 ) NP += 0.5 ;
						
						OLED_DrawRectangle(16, 8, NP, NP/2, OLED_UNFILLED);
						OLED_ClearArea(17, 9, NP-2, NP/2-2);
						
					   OLED_Update();												
					}
					else
					{
//						 GP_target = *( option[Catch_i].Num) * tap ;						
						 GP_target = *( option[Catch_i].Num) * 0.31 ;
						if(GP < GP_target)
						{ 
							if( GP_target - GP > 25 ) GP += 5 ;
							else if( GP_target - GP > 7 ) GP += 2.4 ;
							else if( GP_target - GP > 0 ) GP += 0.5 ;
						}
						if(GP > GP_target)
						{ 	
							if( GP - GP_target > 25 ) GP -= 5 ;
							else if( GP - GP_target > 7 ) GP -= 2.4 ;
							else if( GP - GP_target > 0 ) GP -= 0.5 ;
						}
						
						OLED_ClearArea(24, 43, 80, 3);
						OLED_DrawRectangle(24, 43, GP , 3, OLED_FILLED);												
						
						OLED_ClearArea(55, 20, 18, 8);
						//�����λ��Ϊ��
						if ( *( option[Catch_i].Num) / OLED_Pow(10, 3 - 0 - 1) % 10 )              
						OLED_ShowNum(55, 20, *( option[Catch_i].Num), 3, OLED_6X8);
						//���ʮλ��Ϊ��
						else if ( *( option[Catch_i].Num) / OLED_Pow(10, 3 - 1 - 1) % 10 )
						OLED_ShowNum(58, 20, *( option[Catch_i].Num), 2, OLED_6X8);
						//�����λ��Ϊ��
						else if ( *( option[Catch_i].Num) / OLED_Pow(10, 3 - 2 - 1) % 10 )
						OLED_ShowNum(61, 20, *( option[Catch_i].Num), 1, OLED_6X8);						
						else   
						OLED_ShowNum(61, 20, 0, 1, OLED_6X8);
						
					   OLED_Update();	
						
					}
					
						
					
					   p = menu_Roll_event();   
					   if( p == 1)
					   { 					sysj1=-50;

							*( option[Catch_i].Num) += 1;
							if( option[Catch_i].func){option[Catch_i].func();} //ִ�й���һ��
							
					   }	 
					   else if( p == -1)
					   { 					sysj1=-50;

							*( option[Catch_i].Num) -= 1;
							if( option[Catch_i].func){option[Catch_i].func();} //ִ�й���һ��
					   }
					   
					   p=menu_Enter_event();
					   if(p==1){
						   					sysj1=-50;

						   OLED_Clear();
						   OLED_Update();	

						   break;											
					   }
					   else if ( p==2 ){
										sysj1=-50;

						   OLED_Clear();
						   OLED_Update();	

						   break;					
					}					   
				}
											
			}
			
			//����Ȳ��ǣ����������غͺ�����һ�ʵ���չʾ����
			
			
		}


		
	}
}


















void game_menu()
{
	
	 struct option_class2 CDtb[]={
		 {"<<<" ,Function  , RETURN  },
			 	{"~��������",Function,Game_Of_Life_Play},

		 //{"~���ĵ���Ϸ",Function,game2},
		// {"-̰����",Function,game4},


		 {"~̰����",Function,Game_Snake_Init},
{"~������",Function,game6},
		{"~����˹����",Function,game5},
		{"~ɨ��",Function,game7},

			 			 {".."},

			 
		 };
		 xs_fc(CDtb);
}

void xingxi()
{
	
	struct option_class2 CDtb[]={
		 {"<<<" ,Function  , RETURN  },
		 //{"-��Ϣ:",Display},

																		 {"-����:",Display},
																		 																		 {"-STM32F103",Display},


		 		// {"-W25Q128",Display},
		 {"-0.96OLED",Display},
		 {"-���:200ma",Display},

	 {"-MAX30102",Display},
		// {"-ADXL345",Display},
		// {"-Mini Player",Display},
																		 {"-����:",Display},
//																		 																		 {"-BiBiССMySc",Display,nun},
{"-Mr.Q",Display},
/*
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},

{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},

{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},

{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},

{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},

{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},

{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},

{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},

{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},

{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},
{"-Oh!!!!",Display},

{"-Oh!!!!",Display},
{"-Ha!!!!",Display},

*/
			 			 {".."},

			 
		 };
		 xs_fc(CDtb);
}

void dcs()
{
	
	struct option_class2 CDtb[]={
 {"<<<" ,Function  , RETURN  },
		
 {"-distract",Display},
 {"-speculate",Display},
 {"-inhabit",Display},
 {"-reproach",Display},
 {"-compass",Display},
 {"-integrate",Display},
 {"-comment",Display},
 {"-endeavor",Display},
 {"-recreation",Display},


			 			 {".."},

			 
		 };
		 xs_fc(CDtb);
}




void save_date()
{
	int8_t p;
	dack=0;
dackdh();
	dack=0;

		 LK=0;				
	
	while(1)
	{
	
lightdh();

FLASH_WriteMoreData(0x0800CFEC,&dhxg,2);
FLASH_WriteMoreData(0x0800CFEF,&gb_tb,2);
FLASH_WriteMoreData(0x0800CFF2,&sy_set,2);
FLASH_WriteMoreData(0x0800CFF5,&taiwan,2);
FLASH_WriteMoreData(0x0800CFF7,&fx_set,2);
FLASH_WriteMoreData(0x0800CFF9,&dj,2);
FLASH_WriteMoreData(0x0800CFFC,&xptime,3);

OLED_Clear();

OLED_ShowString1(0,0,"OK",OLED_8X16);

OLED_Update();
		
		
			dackdh();
LK=0;
		
			break;delay_ms(10);
			
			
	}
}










void xtsz()
{
	
	 struct option_class2 CDtb[]={
		 {"<<<" ,Function  , RETURN  },
			 		 {"~�����ʽ",Function,gbys},
					 			 		 {"*��Ļ����",ON_OFF,nun,&fx_set},
										 
		 		 {"*Ϩ������",ON_OFF,nun,&dj},

		 		 {"+Ϩ��ʱ��",Number,nun,&xptime},
				{"*̧������",ON_OFF,nun,&taiwan},
 		//{"~Picture",Function,Show_BMP},
			 			 		 		 {"~��������",Function,kj},
			 			 		 		 {"*���Զ���",ON_OFF,nun,&dhxg},

			 			 					 			 		 {"*����",ON_OFF,nun,&sy_set},
		 {"~ϵͳ��ѹ",Function,xtdy},
		 {"~English",Function, dcs},
		// {"~Save",Function,save_date},

		 {"~��Ϣ",Function, xingxi},



			 			 {".."},

			 
		 };
		 xs_fc(CDtb);
}
	void main_menu()
{
	cd2OptionTypeDef CDtb[]={
						{bp_tb,"���ر���",nun},
						{yxj1,"��Ϸ",game_menu},
//{sp1,"��Ƶ����",nun},

					//	{syj_tb,"������",nun},
								//{music1,"����",mp3yy},
{music1,"����",music_music},
//{sbq_1,"ʾ����",sbq},
			//	{dyb1,"��ѹ��",dyb},
					//			{omb1,"ŷķ��",om},	
		//	{qyj1,"��ѹ��",bmp},
 // {spy_tb,"ˮƽ��",adxl},

//{jb1,"�Ʋ�",nun},
{xl1,"���ʲ���",max},
{APPWXZF,"΢���տ�",WeChat_SK},
{APPZFBZF,"֧����",ZFB_SK},


				{sdt1,"�ֵ�Ͳ",sdt},
				
								{sz1,"ϵͳ����",xtsz},
								{sy,".",nun},

				

	};
			 xs_fc2(CDtb);

}
void main_menu1()
{
	
	struct option_class2 CDtb[]={
		 {"<<<" ,Function  , RETURN  },
			 		 		 		 {"~ʱ������",Function,set_time},
		 		// {"-����",Function,djs},

		 		 {"~����ʱ",Function,djs},

	 {"~���",Function,mb},

			 			 {".."},

			 
		 };
		 xs_fc(CDtb);
}






