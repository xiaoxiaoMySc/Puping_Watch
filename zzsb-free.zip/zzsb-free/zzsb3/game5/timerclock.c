#include "stm32f10x.h"                  // Device header
#include<game5.h>
#include<game7.h>
#include<game6.h>
#include<game4.h>
void timerini()
{
	TIM_TimeBaseInitTypeDef timer_ini;
	NVIC_InitTypeDef nvic_ini_a;
	TIM_init(TIM3,10000,900);
	TIM_ITSetUp(3);
}

void TIM3_IRQHandler(void)
{	
	u8 count;

	if (TIM_GetFlagStatus(TIM3,TIM_FLAG_Update)==SET)
	{
		mix++;
		if (mix>70) mix=20;
		time++;
		if (time>10) time=6;
		key++;
		if (key>10) key=5;

count_game7++;if (count_game7>=8){count_game7=0;key_game7++;time1_game7++;if (time1_game7==6) time1_game7=0;if (key_game7>10) key_game7=5;}
				time_game7++;if(time_game7>8) time_game7=0;
				count1_game7++;if (count1_game7>=3) {count1_game7=0;count2++;if (count2>=6) count2=0;}


	key_game6++;if (key_game6>10) key_game6=5;
		   qaq++;
		   if (qaq>=3) qaq=0;



key_game4++;if (key_game4>10) key_game4=5;
				time1s++;
				if (time1s==2) {time1s=0;}
				time2s++;if(time2s>1) {time2s=0;zset=1;}
				count++;
				if (count>=4) {planttime++;count=0;if (planttime>1) {planttime=0;eatonce=1;}}
				zmiao++;if (zmiao>=25) {if (znum<21)zmiao=0;else zmiao=9;znum++;zonce=1;}
				suntime++;if (suntime>=80) {suntime=0;sunget=1;sunnum++;}
				if (sunget==1)
				{
					sunshow++;
					if (sunshow==5) {sunshow=0;sunget=0;addsunnum=1;}
				}




	}
	  TIM_ClearFlag(TIM3,TIM_FLAG_Update);
}

