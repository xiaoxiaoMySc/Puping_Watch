

#include "stm32f10x.h"
#include<math.h>
#include<stdio.h>
#include<Delay.h>
#include<OLED.h>
#include<OLED_Data.h>
#include<stdlib.h>
#include<KEY.h>
#include<menu.h>
#include<game5.h>

#include "timerclock.h"
u8 boxsave[12][9];
u8 mix=20,xp=1,getmix=2;
u8 time=5,draw=0,key=0,keyvalue=0,k1=0,k2=0,k3=0,zhuangtai=0,run=1;
u8 left,right,turn,mode,savemode;
u8 tgame=2;
u16 score=0;
/*屎山代码，不便修改，下载试玩，bug勿怪
oled驱动代码来自江协科技
*/
void drawbox(u8 x,u8 y)
{
	OLED_DrawRectangle(35+x*5,y*5, 5,5, OLED_FILLED);
}
void keyintput()
{
	static int KEY;
	KEY=menu_Enter_event();
	        if (key>1)
					{
						key=0;
						
						 if (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)==0)
						{
						
							keyvalue=1;
						}
				 	   if (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)==0)
						{						
							keyvalue=2;
						}
						
				  }
				 if (KEY==1)
						{
							
							keyvalue=3;
						} 
						if (KEY==2)
						{
							
							tgame=0;
						}
						delay_ms(30);
}
void getbox()
{
		u8 ii,xx,yy,zz,aa;
	if (boxsave[0][0]+boxsave[0][1]+boxsave[0][2]+boxsave[0][3]+boxsave[0][4]+boxsave[0][5]+boxsave[0][6]+boxsave[0][7]+boxsave[0][8]!=0)
	{
		run=0;
	}
	  for (ii=0;ii<12;ii++)
		{
			if (boxsave[ii][0]+boxsave[ii][1]+boxsave[ii][2]+boxsave[ii][3]+boxsave[ii][4]+boxsave[ii][5]+boxsave[ii][6]+boxsave[ii][7]+boxsave[ii][8]==9)
			{
			 	zz=ii;
				for (xx=0;xx<=ii;xx++)
				{
					for(yy=0;yy<9;yy++)
					{
						if (zz!=0)
						{
						boxsave[zz][yy]=boxsave[zz-1][yy];
						}
					  else
						{
									for (aa=0;aa<10;aa++)
										{
											boxsave[0][aa]=0;
										}
						}											
					}
					zz--;	
				}
				OLED_ClearArea(35,0,45,60);
				OLED_Update();
				for (xx=0;xx<9;xx++)
				{
					for (yy=11;yy>0;yy--)
							if (boxsave[yy][xx]==1) drawbox(xx,yy);
			  }
				score=score+1000;
			}
		}
		
		
}
void thinkstickleft()
{
	if (zhuangtai==0)
	{
			if  ((boxsave[xp/5][getmix-1]+boxsave[(xp-5)/5][getmix-1]+boxsave[(xp-10)/5][getmix-1]+boxsave[(xp-15)/5][getmix-1]==0)&&getmix!=0)  left=1;
	}
	else if (zhuangtai==1)
	{
		if  (getmix<3)
		{
		   if  ((boxsave[xp/5][getmix-1]==0)&&getmix!=0)   left=1;
		}
		else 
		{
			 if  ((boxsave[xp/5][getmix-3]==0)&&getmix!=2)   left=1;
		}
	}
}
void thinkstickturn()
{
	if (zhuangtai==1) turn=1;
	else if (zhuangtai==0)
	{
		if  (getmix<3)
		{
		   if  (boxsave[xp/5][getmix]+boxsave[xp/5][getmix+1]+boxsave[xp/5][getmix+2]==0)   turn=1;
		}
		else 
		{
			 if  (boxsave[xp/5][getmix]+boxsave[xp/5][getmix-1]+boxsave[xp/5][getmix-2]==0)    turn=1;
		}
	}
}
void thinkstickright()
{
	if (zhuangtai==0)
	{
			if  ((boxsave[xp/5][getmix+1]+boxsave[(xp-5)/5][getmix+1]+boxsave[(xp-10)/5][getmix+1]+boxsave[(xp-15)/5][getmix+1]==0)&&getmix<8)  right=1;
	}
	else if (zhuangtai==1)
	{
		if  (getmix<3)
		{
		   if  ((boxsave[xp/5][getmix+3]==0)&&getmix!=6)    right=1;
		}
		else 
		{
			 if  ((boxsave[xp/5][getmix]==0)&&getmix<8)    right=1;
		}
	}
}
void showstick()
{
							if (zhuangtai==0)
						{
							OLED_DrawRectangle(35+getmix*5,xp-15,5,15, OLED_FILLED);
							OLED_ClearArea(35+getmix*5,xp-16,5,1);
							OLED_Update();
						}
						else if (zhuangtai==1)
						{
							if (getmix<3)
							{
								OLED_DrawRectangle(35+getmix*5,xp-5,15,5, OLED_FILLED);
								OLED_ClearArea(35+getmix*5,xp-6,15,1);
								OLED_Update();
							}
							else 
							{
								OLED_DrawRectangle(35+(getmix-2)*5,xp-5,15,5, OLED_FILLED);
								OLED_ClearArea(35+(getmix-2)*5,xp-6,15,1);
								OLED_Update();
							}
						}
}
void stick()
{
	u8 ii;
				if (time>=tgame)
			{
			   time=0;

				showstick();

						
					if (keyvalue==1)   	//左侧移动
						{
							thinkstickleft();
						   if (left==1)
						 	{
								if (zhuangtai==0)
								{
								OLED_ClearArea(35+getmix*5,xp-15,5,15);
								}
								else if (zhuangtai==1)
								{
										if (getmix<3) OLED_ClearArea(35+getmix*5,xp-5,15,5);
									  else OLED_ClearArea(25+getmix*5,xp-5,15,5);
								}
								OLED_Update();
								getmix--;
								showstick();
								keyvalue=0;
								left=0;
							}
						}
					else if (keyvalue==2)   	//右侧移动
						{
						  thinkstickright();
							if (right==1)
							{
								if (zhuangtai==0)
								{
								OLED_ClearArea(35+getmix*5,xp-15,5,15);
								}
								else if (zhuangtai==1)
								{
										if (getmix<3) OLED_ClearArea(35+getmix*5,xp-5,15,5);
									  else OLED_ClearArea(25+getmix*5,xp-5,15,5);
								}
								OLED_Update();
								getmix++;
								showstick();
								keyvalue=0;
								right=0;
							}
						}
					else if (keyvalue==3)    //旋转
					{
						 thinkstickturn();
								if (turn==1)
								{
								if (zhuangtai==0)
								{
											OLED_ClearArea(35+getmix*5,xp-15,5,15);
											zhuangtai=1;
											showstick();
								}
								else if (zhuangtai==1)
								{
									if (getmix<3)
									{
										OLED_ClearArea(35+getmix*5,xp-5,15,5);
										OLED_Update();
									}
									else 
									{
										OLED_ClearArea(25+getmix*5,xp-5,15,5);
										OLED_Update();
									}
									zhuangtai=0;
									showstick();
								}
								keyvalue=0;
								turn=0;
							}
				  }
		      if (xp%5==0)
					{
						if (zhuangtai==0)
						{
								if (boxsave[xp/5][getmix]==1)
								{
									for (ii=0;ii<4;ii++)
									{
										boxsave[xp/5-ii][getmix]=1;
									}
									xp=61;
								}
					  }
						else if (zhuangtai==1)
						{
							if (getmix<3)
							{
							 if (boxsave[xp/5][getmix]+boxsave[xp/5][getmix+1]+boxsave[xp/5][getmix+2]!=0)
								{
									
									for (ii=0;ii<3;ii++)
									{
									 boxsave[(xp-5)/5][getmix+ii]=1;
							    }
									xp=61;
								}
							}
								else
								{
										if (boxsave[xp/5][getmix]+boxsave[xp/5][getmix-1]+boxsave[xp/5][getmix-2]!=0)
										{
											
											for (ii=0;ii<3;ii++)
											{
											 boxsave[(xp-5)/5][getmix-ii]=1;
											}
											xp=61;
										}
						  	}
							
						}
					}
					
					xp++;
					 if (xp>=61)
					{
						getbox();
						getmix=mix/10;
						if (getmix>90) getmix=0;
						xp=1;
						zhuangtai=0;
						draw=1;
						tgame=2;
						savemode=mode;
					}
				}
		  
}
void showlleft()
{
		if (zhuangtai==0)
	{
			if  ((boxsave[xp/5][getmix-1]+boxsave[(xp-5)/5][getmix-1]+boxsave[(xp-10)/5][getmix-1]+boxsave[(xp-15)/5][getmix-1]==0)&&getmix!=0)  left=1;
	}
	  if (zhuangtai==1)
		{
			if  ((boxsave[xp/5][getmix-1]==0)&&getmix!=0)   left=1;
		}
		if (zhuangtai==2)
		{
			if  ((boxsave[xp/5][getmix-1]+boxsave[(xp-5)/5][getmix-1]+boxsave[(xp-10)/5][getmix-1]+boxsave[(xp-15)/5][getmix-1]==0)&&getmix!=0)  left=1;
		}
		if (zhuangtai==3)
		{
			if  ((boxsave[xp/5][getmix-3]+boxsave[(xp-5)/5][getmix-3]==0)&&getmix!=2)   left=1;
		}
}
void showlright()
{
	if (zhuangtai==0)
	{
		if ((boxsave[xp/5][getmix+2]+boxsave[(xp-5)/5][getmix+1]+boxsave[(xp-10)/5][getmix+1]+boxsave[(xp-15)/5][getmix+1]==0)&&getmix<7)  right=1;
	}
	else if (zhuangtai==1)
	{
		  if  ((boxsave[xp/5][getmix+3]+boxsave[(xp-5)/5][getmix+3]==0)&&getmix!=6)    right=1;
	}
	else if (zhuangtai==2) 
	{
		if ((boxsave[xp/5][getmix+1]+boxsave[(xp-5)/5][getmix+1]+boxsave[(xp-10)/5][getmix+1]+boxsave[(xp-15)/5][getmix+2]==0)&&getmix<7)   right=1;
	}
	else if (zhuangtai==3)
	{
		 if  ((boxsave[xp/5][getmix]==0)&&getmix<8)    right=1;
	}
}
void showlturn()
{
	if (zhuangtai==0)
						{
							if (getmix>3)
							{
								if (boxsave[xp/5][getmix+2]+boxsave[(xp-5)/5][getmix+2]==0)   turn=1;
							}
							else 
							{
								if (boxsave[xp/5][getmix-1]+boxsave[xp/5][getmix-2]+boxsave[(xp-5)/5][getmix-2]==0)   turn=1;
							}
					  }
						else if (zhuangtai==1)
						{
						
							 if (boxsave[(xp/5)-1][getmix]+boxsave[(xp/5)-2][getmix]+boxsave[(xp/5)-2][getmix+1]==0)   turn=1;
									
							}
						else if (zhuangtai==2)
						{
						
							if (boxsave[xp/5][getmix+1]==0) 				 turn=1;
						}
						else if (zhuangtai==3)
						{
								
										if ((boxsave[(xp/5)-1][getmix]+boxsave[(xp/5)-2][getmix]+boxsave[(xp/5)-2][getmix+1]==0)&&getmix<8)   turn=1;
						}
}
void showL()
{
			if (zhuangtai==0)
						{
							OLED_DrawRectangle(35+getmix*5,xp-15,5,15, OLED_FILLED);
							OLED_DrawRectangle(40+getmix*5,xp-5,5,5, OLED_FILLED);
							OLED_ClearArea(35+getmix*5,xp-16,5,1);
							OLED_ClearArea(40+getmix*5,xp-6,5,1);
							OLED_Update();
						}
			else if (zhuangtai==1)
						{
			
								OLED_DrawRectangle(35+getmix*5,xp-5,15,5, OLED_FILLED);
								OLED_DrawRectangle(45+getmix*5,xp-10,5,5, OLED_FILLED);
								OLED_ClearArea(35+getmix*5,xp-6,10,1);
								OLED_ClearArea(45+getmix*5,xp-11,5,1);
								OLED_Update();
						}
					else if (zhuangtai==2)
					{
							OLED_DrawRectangle(35+getmix*5,xp-15,5,15, OLED_FILLED);
							OLED_DrawRectangle(40+getmix*5,xp-15,5,5, OLED_FILLED);
							OLED_ClearArea(35+getmix*5,xp-16,5,1);
							OLED_ClearArea(40+getmix*5,xp-16,5,1);
							OLED_Update();
					}
					else if (zhuangtai==3)
					{
								OLED_DrawRectangle(35+(getmix-2)*5,xp-5,15,5, OLED_FILLED);
								OLED_DrawRectangle(35+(getmix-2)*5,xp-10,5,5, OLED_FILLED);
								OLED_ClearArea(35+(getmix-1)*5,xp-6,10,1);
								OLED_ClearArea(35+(getmix-2)*5,xp-11,5,1);
								OLED_Update();
					}
}
void L()
{
	u8 ii;
			if (time>=tgame)
			{
			   time=0;
				showL();

						
					if (keyvalue==1)   	//左侧移动
						{
					 showlleft();
						   if (left==1)
						 	{
								if (zhuangtai==0)
								{
										OLED_ClearArea(35+getmix*5,xp-15,5,15);
										OLED_ClearArea(40+getmix*5,xp-5,5,5);
								}
								else if (zhuangtai==1)
								{
										OLED_ClearArea(35+getmix*5,xp-5,15,5);
										OLED_ClearArea(45+getmix*5,xp-10,5,5);
							
								}
								else if (zhuangtai==2)
								{
										OLED_ClearArea(35+getmix*5,xp-15,5,15);
										OLED_ClearArea(40+getmix*5,xp-15,5,5);
										OLED_Update();
								}
								else if (zhuangtai==3)
								{
									
											OLED_ClearArea(35+(getmix-2)*5,xp-5,15,5);
							      	OLED_ClearArea(35+(getmix-2)*5,xp-10,5,5);
								}
								OLED_Update();
								getmix--;
								showL();
								keyvalue=0;
								left=0;
							}
						}
					else if (keyvalue==2)   	//右侧移动
						{
							showlright();
							if (right==1)
							{
								if (zhuangtai==0)
								{
							OLED_ClearArea(35+getmix*5,xp-15,5,15);
										OLED_ClearArea(40+getmix*5,xp-5,5,5);
								}
								else if (zhuangtai==1)
								{
								
												OLED_ClearArea(35+getmix*5,xp-5,15,5);
									    	OLED_ClearArea(45+getmix*5,xp-10,5,5);
										
									 
								}
									else if (zhuangtai==2)
								{
										OLED_ClearArea(35+getmix*5,xp-15,5,15);
										OLED_ClearArea(40+getmix*5,xp-15,5,5);
										
								}
								else if (zhuangtai==3)
								{
									
											OLED_ClearArea(35+(getmix-2)*5,xp-5,15,5);
							      	OLED_ClearArea(35+(getmix-2)*5,xp-10,5,5);
								}
								OLED_Update();
								getmix++;
								showL();
								keyvalue=0;
								right=0;
							}
						}
					else if (keyvalue==3)    //旋转
					{
						showlturn();
								if (turn==1)
								{
								if (zhuangtai==0)
								{
												OLED_ClearArea(35+getmix*5,xp-15,5,15);
										OLED_ClearArea(40+getmix*5,xp-5,5,5);
									   if (getmix<3) zhuangtai=1;
									   else zhuangtai=3;
											showL();
								}
								else if (zhuangtai==1)
								{
								
										OLED_ClearArea(35+getmix*5,xp-5,15,5);
										OLED_ClearArea(45+getmix*5,xp-10,5,5);
										OLED_Update();
									zhuangtai=2;
									showL();
								}
									else if (zhuangtai==2)
								{
									  OLED_ClearArea(35+getmix*5,xp-15,5,15);
										OLED_ClearArea(40+getmix*5,xp-15,5,5);
										OLED_Update();
									  zhuangtai=0;
									  showL();
								}
								else if (zhuangtai==3)
								{
											OLED_ClearArea(35+(getmix-2)*5,xp-5,15,5);
							      	OLED_ClearArea(35+(getmix-2)*5,xp-10,5,5);
										  OLED_Update();
									    zhuangtai=2;
									    showL();
								}
								keyvalue=0;
								turn=0;
							}
				  }

					if (xp%5==0)
					{
					
						if (zhuangtai==0)
						{
								if (boxsave[xp/5][getmix]+boxsave[xp/5][getmix+1]!=0)
								{
									for (ii=1;ii<4;ii++)
									{
										boxsave[(xp/5)-ii][getmix]=1;
									}
									  boxsave[(xp/5)-1][getmix+1]=1;
									xp=61;
								}
					  }
						else if (zhuangtai==1)
						{
						
							 if (boxsave[xp/5][getmix]+boxsave[xp/5][getmix+1]+boxsave[xp/5][getmix+2]!=0)
								{
									
									for (ii=0;ii<3;ii++)
									{
									 boxsave[(xp-5)/5][getmix+ii]=1;
							    }
									boxsave[(xp-10)/5][getmix+2]=1;
									xp=61;
								}						
							}
						else if (zhuangtai==2)
						{
						
							 if (boxsave[xp/5][getmix]!=0)
								{
									
									for (ii=1;ii<4;ii++)
									{
										boxsave[(xp/5)-ii][getmix]=1;
							    }
								 boxsave[(xp/5)-3][getmix+1]=1;
									xp=61;
								}						
							}
						else if (zhuangtai==3)
						{
								
										if (boxsave[xp/5][getmix]+boxsave[xp/5][getmix-1]+boxsave[xp/5][getmix-2]!=0)
										{
											for (ii=0;ii<3;ii++)
											{
											 boxsave[(xp-5)/5][getmix-ii]=1;
											}
											boxsave[(xp-10)/5][getmix-2]=1;
											xp=61;
										}
						}
					}
					xp++;
					 if (xp>=61)
					{
						getbox();
						getmix=mix/10;
						if (getmix>90) getmix=0;
						xp=1;
						zhuangtai=0;
						draw=1;
						tgame=2;
						savemode=mode;
					}
				
		  }
}
void showZ()
{
			if (zhuangtai==0)
						{
							OLED_DrawRectangle(35+(getmix-1)*5,xp-10,10,5, OLED_FILLED);
							OLED_DrawRectangle(35+getmix*5,xp-5,10,5, OLED_FILLED);
							OLED_ClearArea(35+(getmix-1)*5,xp-11,10,1);
							OLED_ClearArea(35+(getmix+1)*5,xp-6,5,1);
							OLED_Update();
						}
			else if (zhuangtai==1)
						{
								OLED_DrawRectangle(35+(getmix-1)*5,xp-15,5,10, OLED_FILLED);
								OLED_DrawRectangle(35+getmix*5,xp-10,5,10, OLED_FILLED);
								OLED_ClearArea(35+(getmix-1)*5,xp-16,5,1);
								OLED_ClearArea(35+getmix*5,xp-11,5,1);
								OLED_Update();
						}
}
void zleft()
{
	if (zhuangtai==0)
	{
		if ((boxsave[getmix-2][(xp-10)/5]+boxsave[getmix-1][(xp-5)/5]==0)&&(getmix-1>0)) left=1;
	}
	else if (zhuangtai==1)
	{
			if ((boxsave[getmix-2][(xp-15)/5]+boxsave[getmix-2][(xp-10)/5]+boxsave[getmix-1][(xp-5)/5]==0)&&(getmix-1>0)) left=1;
	}
}
void zright()
{
	if (zhuangtai==0)
	{
		if ((boxsave[getmix+1][(xp-10)/5]+boxsave[getmix+2][(xp-5)/5]==0)&&(getmix+1<8)) right=1;
	}
	else if (zhuangtai==1)
	{
			if ((boxsave[getmix][(xp-15)/5]+boxsave[getmix+1][(xp-10)/5]+boxsave[getmix+1][(xp-5)/5]==0)&&(getmix<8)) right=1;
	}
}
void zturn()
{
	if (zhuangtai==0)
	{
		if (boxsave[getmix-1][(xp-15)/5]==0) turn=1;
	}
	else if (zhuangtai==1)
	{
			if ((boxsave[getmix+1][(xp-5)/5]==0)&&(getmix+1<8)) turn=1;
	}
}
void Z()
{
			if (time>=tgame)
			{
			   time=0;
				showZ();
						if (keyvalue==1)   	//左侧移动
						{
					     zleft();
						   if (left==1)
						 	{
								if (zhuangtai==0)
								{
										OLED_ClearArea(35+(getmix-1)*5,xp-10,10,5);
										OLED_ClearArea(35+getmix*5,xp-5,10,5);
								}
								else if (zhuangtai==1)
								{
									  OLED_ClearArea(35+(getmix-1)*5,xp-15,5,10);
										OLED_ClearArea(35+getmix*5,xp-10,5,10);
							
								}
								OLED_Update();
								getmix--;
								showZ();
								keyvalue=0;
								left=0;
							}
						}
					else if (keyvalue==2)   	//右侧移动
						{
							 zright();
							if (right==1)
							{
								if (zhuangtai==0)
								{
						      	OLED_ClearArea(35+(getmix-1)*5,xp-10,10,5);
										OLED_ClearArea(35+getmix*5,xp-5,10,5);
								}
								else if (zhuangtai==1)
								{
								
												  OLED_ClearArea(35+(getmix-1)*5,xp-15,5,10);
									      	OLED_ClearArea(35+getmix*5,xp-10,5,10);			 
								}
								OLED_Update();
								getmix++;
								showZ();
								keyvalue=0;
								right=0;
							}
						}
					else if (keyvalue==3)    //旋转
					{
						  zturn();
								if (turn==1)
								{
								if (zhuangtai==0)
								{
										OLED_ClearArea(35+(getmix-1)*5,xp-10,10,5);
										OLED_ClearArea(35+getmix*5,xp-5,10,5);
										OLED_Update();
									 	zhuangtai=1;
											showZ();
								}
								else if (zhuangtai==1)
								{
								
									 OLED_ClearArea(35+(getmix-1)*5,xp-15,5,10);
									 OLED_ClearArea(35+getmix*5,xp-10,5,10);		
									OLED_Update();
									zhuangtai=0;
									showZ();
								}
								keyvalue=0;
								turn=0;
							}
				  }
					
					if (xp%5==0)
					{
					

						if (zhuangtai==0)
						{
								if (boxsave[(xp-5)/5][getmix-1]+boxsave[xp/5][getmix]+boxsave[xp/5][getmix+1]!=0)
								{
									
										boxsave[(xp-10)/5][getmix-1]=1;
									  boxsave[(xp-10)/5][getmix]=1;
									  boxsave[(xp-5)/5][getmix]=1;
									  boxsave[(xp-5)/5][getmix+1]=1;
									xp=61;
								}
					  }
						else if (zhuangtai==1)
						{
								if (boxsave[(xp-5)/5][getmix-1]+boxsave[xp/5][getmix]!=0)
								{
								  	boxsave[(xp-15)/5][getmix-1]=1;
										boxsave[(xp-10)/5][getmix-1]=1;
									  boxsave[(xp-10)/5][getmix]=1;
									  boxsave[(xp-5)/5][getmix]=1;		
										xp=61;
								}
					  }
					}
					xp++;
					 if (xp>=61)
					{
						getbox();
						getmix=mix/10;
						if (getmix>90) getmix=0;
						xp=1;
						zhuangtai=0;
						draw=1;
						tgame=2;
						savemode=mode;
					}
				
		  }
}
void showbox()
{
							OLED_DrawRectangle(35+getmix*5,xp-10,10,10, OLED_FILLED);
							OLED_ClearArea(35+getmix*5,xp-11,10,1);
							OLED_Update();
}
void box()
{
			if (time>=tgame)
			{
			   time=0;
				 showbox();

						
					if (keyvalue==1)   	//左侧移动
						{
						   if (boxsave[(xp-5)/5][getmix-1]+boxsave[(xp-10)/5][getmix-1]==0&&getmix>0)
						 	{
								OLED_ClearArea(35+getmix*5,xp-10,10,10);
								OLED_Update();
								getmix--;
								showbox();
								keyvalue=0;
							}
						}
					else if (keyvalue==2)   	//右侧移动
						{
						if (boxsave[(xp-5)/5][getmix+2]+boxsave[(xp-10)/5][getmix+2]==0&&getmix<7)
							{
							 
						  	OLED_ClearArea(35+getmix*5,xp-10,10,10);
								OLED_Update();
								getmix++;
								showbox();
								keyvalue=0;					
							}
						}
					if (xp%5==0)
					{
					   if (boxsave[xp/5][getmix]+boxsave[xp/5][getmix+1]!=0)
						 {
							 boxsave[(xp-5)/5][getmix]=1;
							 boxsave[(xp-5)/5][getmix+1]=1;
							 boxsave[(xp-10)/5][getmix]=1;
							 boxsave[(xp-10)/5][getmix+1]=1;
							 xp=61;
						 }
					}
					xp++;
					 if (xp>=61)
					{
						getbox();
						getmix=mix/10;
						if (getmix>90) getmix=0;
						xp=1;
						zhuangtai=0;
						draw=1;
						tgame=2;
						savemode=mode;
					}
		  }
}

void game5(void)
{	
	
		int8_t p;
	dack=0;
dackdh();
	dack=0;

		 LK=0;	
	OLED_Clear();

	TIM_Cmd(TIM3,ENABLE);

	for (xp=0;xp<10;xp++)
	{
		boxsave[12][xp]=1;
	}
	OLED_DrawRectangle(34, -1, 47,62, OLED_UNFILLED);
	OLED_Update();
	savemode=mode;
	while (1)
	{
		
		lightdh();
		if (run==1)
		{
		  keyintput();
		  if (mix<40&&mix>30) mode=0;
		  else if (mix>=40&&mix<55) mode=1;
	  	else if (mix>=55) mode=2;
		  else mode=3;
		  switch (savemode)
			{
				case 0:box();break;
				case 1:stick();break;
				case 2:L();break;
				case 3:Z();break;
			}
		  OLED_ShowNum(90 ,50, score, 6, OLED_6X8);
		}
		else 
		{
			dackdh();
LK=0;
		   OLED_ShowString1(32, 30, "GAME OVER", OLED_8X16);
		   OLED_Update();
		   for(int save_oo=0;save_oo<=12;save_oo++)
		   		   for(int save_oo1=0;save_oo1<=9;save_oo1++)
		    boxsave[save_oo][save_oo1]=0;

		   		   run=1;
mix=20,xp=1,getmix=2;
 time=5,draw=0,key=0,keyvalue=0,k1=0,k2=0,k3=0,zhuangtai=0;
 tgame=2;
score=0;
	TIM_Cmd(TIM3,DISABLE);

		   break;
		}
		
	}
}
