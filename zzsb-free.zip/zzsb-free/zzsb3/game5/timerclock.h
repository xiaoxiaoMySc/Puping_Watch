#ifndef __timerclock_h
#define __timerclock_h
void timerini(void);
#endif
