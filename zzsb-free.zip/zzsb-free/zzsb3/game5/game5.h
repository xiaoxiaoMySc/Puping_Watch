#ifndef __GAME5_H
#define __GAME5_H
void game5(void);
extern u8 mix,time,key;
#endif