extern const unsigned char* bp_tp[];
extern  unsigned char dian [] ;