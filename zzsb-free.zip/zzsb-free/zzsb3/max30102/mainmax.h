#ifndef __MAINMAX_H
#define __MAINMAX_H	 
void max();

		 				    
#endif
