#ifndef __MUSIC_H
#define __MUSIC_H

typedef struct {
    uint16_t note;  // 音符频率
    uint16_t duration; // 音符时长(ms)
} MusicNote;
extern const MusicNote* songs[] ;
void music_music(void);
void PlayMusic(const MusicNote *music) ;
extern const MusicNote symphony3[];
 
#endif