
#include<menu.h>
#include "stm32f10x.h"
#include<Delay.h>
#include<KEY.h>
// 音符频率定义 (Hz)
#define C3  131
#define D3  147
#define E3  165
#define F3  175
#define G3  196
#define A3  220
#define B3  247
#define C4  262
#define D4  294
#define E4  330
#define F4  349
#define G4  392
#define A4  440
#define B4  494
#define C5  523
#define D5  587
#define E5  659
#define F5  698
#define G5  784

// 添加高音区定义
#define F6  1397
#define G6  1568
#define A6  1760
#define B6  1976
#define C7  2093
// 高音区定义
#define C6  1047
#define D6  1175
#define E6  1319
#define A5  880
#define B5  988
#define G5  784
#define F5  698
#define A4  440
#define B4  494
#define C5  523
#define D5  587
#define E5  659
#define REST 0   // 休止符


// 扩展音高定义
#define E2  82
#define A2  110
#define E3  165
#define A3  220
#define C4  262
#define E4  330
#define G4  392
#define A4  440
#define B4  494
#define C5  523
#define D5  587
#define E5  659
#define F5  698
// 节拍时长 (ms)
// 速度控制 (BPM)
#define TEMPO 108// 原曲速度108
#define Q (60000 / TEMPO) // 四分音符
#define H (2 * Q)         // 二分音符
#define W (4 * Q)         // 全音符
#define E (Q / 2)         // 八分音符
// 音乐数据结构 
typedef struct {
    uint16_t note;  // 音符频率
    uint16_t duration; // 音符时长(ms)
} MusicNote;

// 歌曲1: 《小星星》
const MusicNote song1[] = {
    {C4, Q}, {C4, Q}, {G4, Q}, {G4, Q}, 
    {A4, Q}, {A4, Q}, {G4, H}, 
    {F4, Q}, {F4, Q}, {E4, Q}, {E4, Q}, 
    {D4, Q}, {D4, Q}, {C4, H},
    {0, 0}  // 结束标记
};

// 歌曲2: 《欢乐颂》
const MusicNote song2[] = {
    {E4, Q}, {E4, Q}, {F4, Q}, {G4, Q},
    {G4, Q}, {F4, Q}, {E4, Q}, {D4, Q},
    {C4, Q}, {C4, Q}, {D4, Q}, {E4, H},
    {E4, E}, {D4, E}, {D4, H},
    {REST, 0}  // 结束标记
};

// 歌曲3: 《生日快乐》
const MusicNote song3[] = {
    {G4, E}, {G4, E}, {A4, Q}, {G4, Q}, 
    {C5, Q}, {B4, H}, 
    {G4, E}, {G4, E}, {A4, Q}, {G4, Q}, 
    {D5, Q}, {C5, H},
    {G4, E}, {G4, E}, {G5, Q}, {E5, Q}, 
    {C5, Q}, {B4, Q}, {A4, H},
    {F5, E}, {F5, E}, {E5, Q}, {C5, Q}, 
    {D5, Q}, {C5, H},
    {REST, 0}  // 结束标记
};

// 贝多芬第一交响曲主题
const MusicNote symphony1[] = {
    {C4, Q}, {E4, Q}, {G4, H}, 
    {C4, Q}, {E4, Q}, {G4, H}, 
    {A3, Q}, {C4, Q}, {E4, H},
    {A3, Q}, {C4, Q}, {E4, H},
    {REST, 0}
};

// 贝多芬第二交响曲主题
const MusicNote symphony2[] = {
    {D4, E}, {F4, E}, {A4, Q}, {F4, E}, {D4, E}, 
    {C4, Q}, {E4, Q}, {G4, H},
    {D4, E}, {F4, E}, {A4, Q}, {F4, E}, {D4, E}, 
    {C4, Q}, {E4, Q}, {G4, H},
    {REST, 0}
};

// 贝多芬第三交响曲"英雄"主题
const MusicNote symphony3[] = {
    {E4, Q}, {E4, Q}, {F4, Q}, {G4, Q},
    {G4, Q}, {F4, Q}, {E4, Q}, {D4, Q},
    {C4, Q}, {C4, Q}, {D4, Q}, {E4, H},
    {E4, E}, {D4, E}, {D4, H},
    {REST, 0}
};

// 贝多芬第四交响曲主题
const MusicNote symphony4[] = {
    {B3, Q}, {D4, Q}, {G4, Q}, {D4, Q},
    {B3, Q}, {D4, Q}, {G4, H},
    {A3, Q}, {C4, Q}, {F4, Q}, {C4, Q},
    {A3, Q}, {C4, Q}, {F4, H},
    {REST, 0}
};

// 贝多芬第五交响曲"命运"主题
const MusicNote symphony5[] = {
    {G3, E}, {G3, E}, {G3, E}, {E4, H},
    {F3, E}, {F3, E}, {F3, E}, {D4, H},
    {G3, E}, {G3, E}, {G3, E}, {E4, H},
    {C4, Q}, {B3, Q}, {A3, H},
    {REST, 0}
};

// 贝多芬第六交响曲"田园"主题
const MusicNote symphony6[] = {
    {F4, Q}, {A4, Q}, {C5, H},
    {F4, Q}, {A4, Q}, {C5, H},
    {E4, Q}, {G4, Q}, {B4, H},
    {E4, Q}, {G4, Q}, {B4, H},
    {REST, 0}
};

// 贝多芬第七交响曲主题
const MusicNote symphony7[] = {
    {E4, Q}, {D4, E}, {C4, E}, {B3, Q}, {A3, Q},
    {E4, Q}, {D4, E}, {C4, E}, {B3, Q}, {A3, Q},
    {D4, Q}, {C4, E}, {B3, E}, {A3, Q}, {G3, Q},
    {D4, Q}, {C4, E}, {B3, E}, {A3, Q}, {G3, Q},
    {REST, 0}
};

// 贝多芬第八交响曲主题
const MusicNote symphony8[] = {
    {F4, Q}, {G4, E}, {A4, E}, {B4, Q}, {C5, H},
    {F4, Q}, {G4, E}, {A4, E}, {B4, Q}, {C5, H},
    {E4, Q}, {F4, E}, {G4, E}, {A4, Q}, {B4, H},
    {E4, Q}, {F4, E}, {G4, E}, {A4, Q}, {B4, H},
    {REST, 0}
};

// 贝多芬第九交响曲"合唱"主题
const MusicNote symphony9[] = {
    {D4, Q}, {D4, Q}, {E4, Q}, {F4, Q},
    {F4, Q}, {E4, Q}, {D4, Q}, {C4, Q},
    {B3, Q}, {B3, Q}, {C4, Q}, {D4, H},
    {D4, E}, {C4, E}, {C4, H},
    {REST, 0}
};
const MusicNote symphony2_full[] = {
    // 第一乐章
    {REST, W}, // 停顿
    // 插入第一乐章内容
    {D3, H}, {A3, H}, {D4, H}, {F4, H},
    {E4, Q}, {D4, Q}, {C4, Q}, {B3, Q},
    {D4, Q}, {F4, Q}, {A4, Q}, {G4, E}, {F4, E},
    {E4, Q}, {G4, Q}, {B4, Q}, {A4, E}, {G4, E},
    {F4, Q}, {A4, Q}, {C5, Q}, {B4, E}, {A4, E},
    {G4, Q}, {B4, Q}, {D5, H},
    {C5, Q}, {B4, Q}, {A4, Q}, {G4, Q},
    {F4, Q}, {E4, Q}, {D4, Q}, {C4, Q},
    {B3, Q}, {A3, Q}, {G3, Q}, {F3, Q},
    {D4, Q}, {F4, Q}, {A4, Q}, {G4, E}, {F4, E},
    {E4, Q}, {G4, Q}, {B4, Q}, {A4, E}, {G4, E},
    {F4, Q}, {A4, Q}, {C5, H},
    //{REST, W}, {REST, W}, // 乐章间停顿
    
    // 第二乐章
    {A3, Q}, {C4, Q}, {E4, Q}, {G4, H},
    {F4, Q}, {E4, Q}, {D4, Q}, {C4, H},
    {B3, Q}, {D4, Q}, {G4, Q}, {F4, E}, {E4, E},
    {D4, Q}, {F4, Q}, {A4, H},
    {A3, Q}, {C4, Q}, {E4, Q}, {G4, H},
    {F4, Q}, {E4, Q}, {D4, Q}, {C4, H},
    {B3, H}, {C4, H}, {D4, H}, {E4, H},
    //{REST, W}, {REST, W}, // 乐章间停顿
    
    // 第三乐章
    {D4, E}, {D4, E}, {D4, E}, {F4, E}, {A4, E}, {F4, E},
    {D4, E}, {D4, E}, {D4, E}, {F4, E}, {A4, E}, {F4, E},
    {E4, E}, {E4, E}, {E4, E}, {G4, E}, {B4, E}, {G4, E},
    {E4, E}, {E4, E}, {E4, E}, {G4, E}, {B4, E}, {G4, E},
    {A3, Q}, {C4, Q}, {E4, Q}, {G4, Q},
    {F4, Q}, {E4, Q}, {D4, Q}, {C4, Q},
    {B3, Q}, {D4, Q}, {G4, Q}, {F4, E}, {E4, E},
    {D4, E}, {D4, E}, {D4, E}, {F4, E}, {A4, E}, {F4, E},
    {D4, E}, {D4, E}, {D4, E}, {F4, E}, {A4, E}, {F4, E},
   // {REST, W}, {REST, W}, // 乐章间停顿
    
    // 第四乐章
    {D4, E}, {A3, E}, {D4, E}, {F4, E},
    {E4, E}, {D4, E}, {C4, E}, {B3, E},
    {A3, E}, {D4, E}, {F4, E}, {A4, E},
    {G4, E}, {F4, E}, {E4, E}, {D4, E},
    {C4, Q}, {E4, Q}, {G4, Q}, {B4, Q},
    {A4, Q}, {G4, Q}, {F4, Q}, {E4, Q},
    {D4, Q}, {F4, Q}, {A4, Q}, {C5, Q},
    {B4, Q}, {A4, Q}, {G4, Q}, {F4, Q},
    {D4, E}, {A3, E}, {D4, E}, {F4, E},
    {E4, E}, {D4, E}, {C4, E}, {B3, E},
    {A3, E}, {D4, E}, {F4, E}, {A4, E},
    {D4, Q}, {D4, Q}, {D4, Q}, {D4, Q},
    {D4, H}, {D4, H}, {D4, W},
    
    {REST, 0} // 结束
};




// 贝多芬 - 致爱丽丝 (Für Elise) 完整版
const MusicNote fur_elise_full[] = {
    // 主题A (第一部分)
    {E5, E}, {D5, E}, {E5, E}, {D5, E}, {E5, E}, {B4, E}, {D5, E}, {C5, E},
    {A4, Q}, {REST, E}, {C4, E}, {E4, E}, {A4, E}, {B4, E},
    {REST, E}, {E4, E}, {G4, E}, {B4, E}, {C5, Q},
    
    // 主题A (重复)
    {E5, E}, {D5, E}, {E5, E}, {D5, E}, {E5, E}, {B4, E}, {D5, E}, {C5, E},
    {A4, Q}, {REST, E}, {C4, E}, {E4, E}, {A4, E}, {B4, E},
    {REST, E}, {E4, E}, {C5, E}, {B4, E}, {A4, H},
    
    // 过渡段B
    {B4, E}, {C5, E}, {D5, E}, {E5, Q}, {REST, E},
    {G4, E}, {F5, E}, {E5, E}, {D5, Q}, {REST, E},
    {F4, E}, {E5, E}, {D5, E}, {C5, Q}, {REST, E},
    {E4, E}, {D5, E}, {C5, E}, {B4, Q}, {REST, E},
    
    // 主题C (中部)
    {E4, E}, {A4, E}, {C5, E}, {E5, Q}, {REST, E},
    {E4, E}, {A4, E}, {C5, E}, {E5, Q}, {REST, E},
    {E4, E}, {G4, E}, {B4, E}, {D5, E}, {G5, E}, {D5, E}, {B4, E}, {G4, E},
    {E4, E}, {G4, E}, {B4, E}, {D5, E}, {G5, E}, {D5, E}, {B4, E}, {G4, E},
    
    // 主题C (发展)
    {A4, E}, {C5, E}, {E5, E}, {A5, Q}, {REST, E},
    {A4, E}, {C5, E}, {E5, E}, {A5, Q}, {REST, E},
    {A4, E}, {C5, E}, {F5, E}, {A5, Q}, {REST, E},
    {B4, E}, {D5, E}, {G5, E}, {B5, Q}, {REST, E},
    
    // 过渡段B再现
    {B4, E}, {C5, E}, {D5, E}, {E5, Q}, {REST, E},
    {G4, E}, {F5, E}, {E5, E}, {D5, Q}, {REST, E},
    {F4, E}, {E5, E}, {D5, E}, {C5, Q}, {REST, E},
    {E4, E}, {D5, E}, {C5, E}, {B4, Q}, {REST, E},
    
    // 主题A再现
    {E5, E}, {D5, E}, {E5, E}, {D5, E}, {E5, E}, {B4, E}, {D5, E}, {C5, E},
    {A4, Q}, {REST, E}, {C4, E}, {E4, E}, {A4, E}, {B4, E},
    {REST, E}, {E4, E}, {C5, E}, {B4, E}, {A4, H},
    
    // 尾声
   // {A4, E}, {B4, E}, {C5, E}, {D5, E}, {E5, E}, {F5, E},
   // {G5, E}, {A5, E}, {B5, E}, {C6, H}, {REST, E},
  //  {E5, E}, {F5, E}, {G5, E}, {A5, E}, {B5, E}, {C6, E},
   // {D6, E}, {E6, H}, {REST, E},
    
    // 结尾和弦
  //  {A3, Q}, {C4, Q}, {E4, Q}, {A4, H},
   // {A2, Q}, {E3, Q}, {A3, Q}, {C4, H},
   // {A2, H}, {E3, H}, {A3, W},
    
    {REST, 0} // 结束
};
///《Far Away From Home》
// Groove Coverage - Far Away From Home (完整版)
const MusicNote far_away_from_home[] = {
    // 前奏
    {C5, E}, {D5, E}, {E5, E}, {G5, Q}, {REST, E},
    {C5, E}, {D5, E}, {E5, E}, {G5, Q}, {REST, E},
    {A4, E}, {C5, E}, {D5, E}, {E5, Q}, {REST, E},
    {A4, E}, {C5, E}, {D5, E}, {E5, H}, {REST, E},
    
    // 主歌1
    {C5, Q}, {C5, E}, {D5, E}, {E5, Q}, {G5, E}, {E5, E}, 
    {D5, Q}, {D5, E}, {E5, E}, {G5, Q}, {A5, E}, {G5, E},
    {E5, Q}, {E5, E}, {G5, E}, {A5, Q}, {C6, E}, {A5, E},
    {G5, Q}, {G5, E}, {A5, E}, {C6, H}, {REST, E},
    
    // 副歌1
    {G5, E}, {E5, E}, {D5, E}, {C5, Q}, {REST, E},
    {G5, E}, {E5, E}, {D5, E}, {C5, Q}, {REST, E},
    {A5, E}, {G5, E}, {E5, E}, {D5, Q}, {REST, E},
    {A5, E}, {G5, E}, {E5, E}, {D5, H}, {REST, E},
    
    // 主歌2
    {C5, Q}, {C5, E}, {D5, E}, {E5, Q}, {G5, E}, {E5, E}, 
    {D5, Q}, {D5, E}, {E5, E}, {G5, Q}, {A5, E}, {G5, E},
    {E5, Q}, {E5, E}, {G5, E}, {A5, Q}, {C6, E}, {A5, E},
    {G5, Q}, {G5, E}, {A5, E}, {C6, H}, {REST, E},
    
    // 副歌2
    {G5, E}, {E5, E}, {D5, E}, {C5, Q}, {REST, E},
    {G5, E}, {E5, E}, {D5, E}, {C5, Q}, {REST, E},
    {A5, E}, {G5, E}, {E5, E}, {D5, Q}, {REST, E},
    {A5, E}, {G5, E}, {E5, E}, {D5, H}, {REST, E},
    
    // 间奏 (电子音乐部分)
    {C6, E}, {D6, E}, {E6, E}, {G6, Q}, {REST, E},
    {C6, E}, {D6, E}, {E6, E}, {G6, Q}, {REST, E},
    {A5, E}, {C6, E}, {D6, E}, {E6, Q}, {REST, E},
    {A5, E}, {C6, E}, {D6, E}, {E6, H}, {REST, E},
    
    // 桥段
    {G5, Q}, {E5, E}, {D5, E}, {C5, Q}, {REST, E},
    {A5, Q}, {G5, E}, {E5, E}, {D5, Q}, {REST, E},
    {C6, Q}, {A5, E}, {G5, E}, {E5, Q}, {REST, E},
    {D6, Q}, {C6, E}, {A5, E}, {G5, H}, {REST, E},
    
    // 副歌3 (高潮)
    {G5, E}, {E5, E}, {D5, E}, {C5, Q}, {C5, E}, 
    {G5, E}, {E5, E}, {D5, E}, {C5, Q}, {C5, E},
    {A5, E}, {G5, E}, {E5, E}, {D5, Q}, {D5, E},
    {A5, E}, {G5, E}, {E5, E}, {D5, H}, {REST, E},
    
    // 结尾
    {C5, Q}, {D5, Q}, {E5, H}, {REST, E},
    {C5, Q}, {D5, Q}, {E5, H}, {REST, E},
    {A4, Q}, {C5, Q}, {D5, H}, {REST, E},
    {A4, Q}, {C5, Q}, {D5, W}, 
    
    {REST, 0 } // 结束
};



// 歌曲列表
const MusicNote* songs[] = {fur_elise_full};

void GPIO_Configuration(void);
void TIM1_Configuration(void);
void PlayMusic(const MusicNote *music);
void RCC_init(void) {
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | 
                          RCC_APB2Periph_TIM1 | RCC_APB2Periph_AFIO, ENABLE);
}
// 当前播放的歌曲索引
volatile uint8_t currentSong = 0;
int music_state=0; 

void gamemusic();
void music_music(void) {
    // 系统初始化
            
RCC_init();
    GPIO_Configuration();

    TIM1_Configuration();
    // 循环播放音乐
    while(1) {
            OLED_Clear();

  static int KEY;
KEY=key_scan(0);

if(KEY==key2ps)
{        TIM_Cmd(TIM1, DISABLE);

    
    break;
}

if(KEY==key3ps)
{
	currentSong++;
    music_state=0;
}

if(KEY==key1ps)
{
	currentSong--;
    music_state=0;
}
if(currentSong>0)
currentSong=0;
if(currentSong<0)
currentSong=0;

OLED_ShowString1(0,0,"MUSIC",OLED_8X16);
OLED_ShowNum(0,32,currentSong,2,OLED_8X16);
OLED_Update();

if(music_state==0)
        PlayMusic(songs[currentSong]);



    }
}


// GPIO配置
void GPIO_Configuration(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    
    // PA8 - TIM1_CH1 (蜂鸣器)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  // 复用推挽输出
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    // PB12 - 按键切换歌曲 (外部下拉)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;    // 上拉输入
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}



// TIM1 PWM配置
void TIM1_Configuration(void) { 
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;
    
    // 时基配置
    TIM_TimeBaseStructure.TIM_Period = 0;  // 初始值，播放时动态设置
    TIM_TimeBaseStructure.TIM_Prescaler = 72 - 1; // 72MHz/72 = 1MHz
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);
    
    // PWM模式配置
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OCInitStructure.TIM_Pulse = 0; // 初始占空比
    TIM_OC1Init(TIM1, &TIM_OCInitStructure);
    
    // 启动TIM1
    TIM_CtrlPWMOutputs(TIM1, ENABLE);
    TIM_Cmd(TIM1, DISABLE); // 初始禁用
}


// 在播放函数中添加动态控制
void PlayWithExpression(uint16_t note, uint16_t duration, uint8_t position) {
    uint8_t velocity = 70; // 默认音量
    
    // 根据位置调整音量
    if(position < 30 || position > 120) velocity = 50; // 开头结尾较弱
    else if(position > 60 && position < 90) velocity = 90; // 高潮部分较强
    
    if(note != REST) {
        uint16_t period = 1000000 / note;
        TIM1->ARR = period - 1;
        TIM1->CCR1 = period * velocity / 100;
    }
    delay_ms(duration);
}

// 不同段落使用不同音色
void SetTimbre(uint8_t section) {
    // 0=主题A, 1=过渡B, 2=主题C, 3=尾声
    switch(section) {
        case 0: // 柔和音色
            TIM1->CCR1 = TIM1->ARR * 40 / 100; // 40%占空比
            break;
        case 1: // 明亮音色
            TIM1->CCR1 = TIM1->ARR * 60 / 100; // 60%占空比
            break;
        case 2: // 圆润音色
            TIM1->CCR1 = TIM1->ARR * 50 / 100; // 50%占空比
            break;
        case 3: // 柔和音色
            TIM1->CCR1 = TIM1->ARR * 30 / 100; // 30%占空比
            break;
    }
}

// 添加Rubato节奏处理
void PlayWithRubato(uint16_t note, uint16_t duration, uint8_t phrase_end) {
    uint16_t actual_duration = duration;
    
    if(phrase_end) {
        // 乐句结尾稍慢
        actual_duration = duration * 1.15;
    } else {
        // 乐句中间保持或稍快
        actual_duration = duration * 0.95;
    }
    
    if(note != REST) {
        uint16_t period = 1000000 / note;
        TIM1->ARR = period - 1;
        TIM1->CCR1 = period / 2;
    }
    delay_ms(actual_duration);
}



void PlayMusic(const MusicNote *music) {
    uint32_t i = 0;
    uint8_t section = 0; // 0=主题A, 1=过渡B, 2=主题C, 3=尾声
      OLED_ShowString1(60,0,"ON",OLED_8X16);
OLED_ShowNum(0,32,currentSong,2,OLED_8X16);
OLED_Update();
if(sy_set==1)
        TIM_Cmd(TIM1, ENABLE);
        else    TIM_Cmd(TIM1, DISABLE);

    while(music[i].duration != 0) {static int KEY;
KEY=key_scan(0);
        // 检测段落变化
        if(i == 16) section = 1; // 进入过渡段B
        else if(i == 32) section = 2; // 进入主题C
        else if(i == 80) section = 3; // 进入尾声
        
        // 设置音色
        SetTimbre(section);
        
        // 检查是否为乐句结尾
        uint8_t phrase_end = 0;
        if(i > 0 && music[i+1].duration == 0) phrase_end = 1; // 下一音符是休止符
        if((i+1) % 8 == 0) phrase_end = 1; // 每8个音符一个乐句
        
        if(music[i].note != REST) {
            // 应用动态和节奏处理
            PlayWithExpression(music[i].note, music[i].duration, i);
        } else {
            // 休止符
            delay_ms(music[i].duration);
        }
        
        // 短暂静音分隔音符
        TIM1->CCR1 = 0;
        delay_ms(15);
        
        i++;
 

if(KEY==key2ps)
{break;}


    }
    TIM_Cmd(TIM1, DISABLE);
            music_state=1;
}


