#include<stm32f10x.h>
#include<OLED.h>
#include<OLED_Data.h>
#include<menu.h>
#include<KEY.h>
#include<Delay.h>
#include<ADC.h>
#include<bmp280.h>
#include<bsp_exti.h>
#include<24cxx.h>
#include<MyRTC.h>
#include<ADXL.h>
#include<usart.h>
#include<bp.h>


int8_t Cube[8][3] = {{5, 5, 5}, {-5, 5, 5}, {-5, -5, 5}, {5, -5, 5},  //A B C D
										{5, 5, -5}, {-5, 5, -5}, {-5, -5, -5}, {5, -5, -5}};  //E F G H
double Cube_display[8][3] = {{5, 5, 5}, {-5, 5, 5}, {-5, -5, 5}, {5, -5,5},  //A B C D
										{5,5, -5}, {-5, 5, -5}, {-5, -5, -5}, {5, -5, -5}}; 

uint8_t Cor_TransX(double x){
	return x + 64;
}

uint8_t Cor_TransY(double y){
	return y + 32;
}

void Cube_rotate(double thetaX, double thetaY, double thetaZ){
	uint8_t i ;
	for(i=0; i<8; i++){
		Cube_display[i][0] = Cube[i][0];
		Cube_display[i][1] = Cube[i][1] * cos(thetaX) - Cube[i][2] * sin(thetaX);
		Cube_display[i][2] = Cube[i][1] * sin(thetaX) + Cube[i][2] * cos(thetaX);
		
		Cube_display[i][0] = Cube_display[i][0] * cos(thetaY) - Cube_display[i][2] * sin(thetaY);
		Cube_display[i][1] = Cube_display[i][1];
		Cube_display[i][2] = Cube_display[i][0] * sin(thetaY) + Cube_display[i][2] * cos(thetaY);
		
		Cube_display[i][0] = Cube_display[i][0] * cos(thetaZ) - Cube_display[i][1] * sin(thetaZ);
		Cube_display[i][1] = Cube_display[i][0] * sin(thetaZ) + Cube_display[i][1] * cos(thetaZ);
		Cube_display[i][2] = Cube_display[i][2];
	}
}
int zfx=-20,zfy=26;
void DrawCube(){
	OLED_DrawLine(Cor_TransX(Cube_display[0][0])+zfx, Cor_TransY(Cube_display[0][1])+zfy,  //AB
	         Cor_TransX(Cube_display[1][0])+zfx, Cor_TransY(Cube_display[1][1])+zfy);
	
	OLED_DrawLine(Cor_TransX(Cube_display[1][0])+zfx, Cor_TransY(Cube_display[1][1])+zfy,  //BC
	         Cor_TransX(Cube_display[2][0])+zfx, Cor_TransY(Cube_display[2][1])+zfy);
	
	OLED_DrawLine(Cor_TransX(Cube_display[2][0])+zfx, Cor_TransY(Cube_display[2][1])+zfy,  //CD
	         Cor_TransX(Cube_display[3][0])+zfx, Cor_TransY(Cube_display[3][1])+zfy);
	
	OLED_DrawLine(Cor_TransX(Cube_display[3][0])+zfx, Cor_TransY(Cube_display[3][1])+zfy,  //DA
	         Cor_TransX(Cube_display[0][0])+zfx, Cor_TransY(Cube_display[0][1])+zfy);
	
	OLED_DrawLine(Cor_TransX(Cube_display[4][0])+zfx, Cor_TransY(Cube_display[4][1])+zfy,  //EF
	         Cor_TransX(Cube_display[5][0])+zfx, Cor_TransY(Cube_display[5][1])+zfy);
	
	OLED_DrawLine(Cor_TransX(Cube_display[5][0])+zfx, Cor_TransY(Cube_display[5][1]+zfy),  //FG
	         Cor_TransX(Cube_display[6][0])+zfx, Cor_TransY(Cube_display[6][1])+zfy);
	
	OLED_DrawLine(Cor_TransX(Cube_display[6][0])+zfx, Cor_TransY(Cube_display[6][1])+zfy,  //GH
	         Cor_TransX(Cube_display[7][0])+zfx, Cor_TransY(Cube_display[7][1])+zfy);
	 
	OLED_DrawLine(Cor_TransX(Cube_display[7][0])+zfx, Cor_TransY(Cube_display[7][1])+zfy,  //HE
	         Cor_TransX(Cube_display[4][0])+zfx, Cor_TransY(Cube_display[4][1])+zfy);
					 
	OLED_DrawLine(Cor_TransX(Cube_display[0][0])+zfx, Cor_TransY(Cube_display[0][1])+zfy,  //AE
	         Cor_TransX(Cube_display[4][0])+zfx, Cor_TransY(Cube_display[4][1])+zfy);
	
	OLED_DrawLine(Cor_TransX(Cube_display[1][0])+zfx, Cor_TransY(Cube_display[1][1])+zfy,  //BF
	         Cor_TransX(Cube_display[5][0])+zfx, Cor_TransY(Cube_display[5][1])+zfy);
	
	OLED_DrawLine(Cor_TransX(Cube_display[2][0])+zfx, Cor_TransY(Cube_display[2][1])+zfy,  //CG
	         Cor_TransX(Cube_display[6][0])+zfx, Cor_TransY(Cube_display[6][1])+zfy);
	
	OLED_DrawLine(Cor_TransX(Cube_display[3][0])+zfx, Cor_TransY(Cube_display[3][1])+zfy,  //DH
	         Cor_TransX(Cube_display[7][0])+zfx, Cor_TransY(Cube_display[7][1])+zfy);
}


   

float o;
void zfdh()
{
double PI = 3.141592;
	
			Cube_rotate(PI / 180 * o, PI / 90 * o, 0);			
o+=4;
			if(o>1000)
				o=0;
			DrawCube();


}


uint16_t second, minute, hour, week, day, month, year;
static uint8_t bcd_to_binary(uint8_t value)
{
//    return (((value & 0xf0) >> 4) * 10) + (value & 0x0f);
	uint8_t m , n;
	m = (uint8_t) ((value >> 4 ) * 10);
	n =  value & (uint8_t)0x0F;
	return (m+n);
}
			     int sysj=0;

	float (*dh)(int mode);
	float (*dh1)(int mode);
	
float dhfy(int mode)
{
	if(mode==1)
	{
	if(sysj<=10)
sysj+=0.4;
	
if(sysj<=20)
sysj+=0.8;
if(sysj<=30)
sysj+=1.3;
if(sysj<=40)
sysj+=2.2;
if(sysj<=50)
sysj+=3;
if(sysj<=60)
sysj+=3.4;
if(sysj<=70)
sysj+=3;
if(sysj<=80)
sysj+=2.2;
if(sysj<=90)
sysj+=1.4;
if(sysj<=100)
sysj+=1;
if(sysj<=110)
sysj+=0.6;
if(sysj<=120)
sysj+=0.4;
if(sysj<=130)
sysj+=0.2;
	}
	return sysj;
}
void timer_apper2()
{
	zfx=52;
	zfy=-25;
	MyRTC_ReadTime();
 second = MyRTC_Time[5] ;
        minute = MyRTC_Time[4] ;
        hour = MyRTC_Time[3] ;OLED_ShowNum(0-100+sysj,0,hour,2,OLED_6X8);
		OLED_ShowNum(30-100+sysj,0,minute,2,OLED_6X8);
		OLED_ShowNum(60-100+sysj,0,second,2,OLED_6X8);
		OLED_ShowString1(20-100+sysj,0,":",OLED_6X8);
		OLED_ShowString1(50-100+sysj,0,":",OLED_6X8);
	////////////////////
static int nb=0;
			static float Pl;
			static float T;
					static float P;
 lightdh();

//Pl=bmp280_GetAltitude();
	//	T=bmp280_T();
			//	P=bmp280_P();

		OLED_ShowSignedNum(0+100-sysj,55,T,2,OLED_6X8);
OLED_ShowString1(34+100-sysj,55,"C",OLED_6X8);
OLED_ShowString1(26+100-sysj,47,".",OLED_6X8);

///////////////////
		// zfdh();

dh=dhfy;
(*dh)(1);
}

void time_appear()
{

MyRTC_ReadTime();
        second = MyRTC_Time[5] ;
        minute = MyRTC_Time[4] ;
        hour = MyRTC_Time[3] ;
        week =  MyRTC_Time[6] ;
        day =  MyRTC_Time[2] ;
        month =  MyRTC_Time[1] ;
        year = MyRTC_Time[0] ;
       
   		OLED_ShowNum(118-100+sysj,0,week,1,OLED_8X16);

					OLED_ShowNum(44-100+sysj,0,month,2,OLED_8X16);
		OLED_ShowNum(81-100+sysj,0,day,2,OLED_8X16);
		OLED_ShowNum(0+100-sysj,15,hour,2,OLED_8X16);
		OLED_ShowNum(30+100-sysj,15,minute,2,OLED_8X16);
		OLED_ShowNum(60+100-sysj,15,second,2,OLED_8X16);
		OLED_ShowString1(20+100-sysj,15,":",OLED_8X16);
		OLED_ShowString1(50+100-sysj,15,":",OLED_8X16);

dh=dhfy;
(*dh)(1);
}





int  jm_dh_x=-100,jm_dh_x1=-3;




void time_appear3()
{
	zfx=-18;
	zfy=26;
static int dian_time=0;
MyRTC_ReadTime();
        second = MyRTC_Time[5] ;
        minute = MyRTC_Time[4] ;
        hour = MyRTC_Time[3] ;
        week =  MyRTC_Time[6] ;
        day =  MyRTC_Time[2] ;
        month =  MyRTC_Time[1] ;
        year = MyRTC_Time[0] ;
		
	jm_dh_x+=(jm_dh_x1-jm_dh_x)/4;

if(dian_time>40&&dian_time<80)
{
				OLED_ShowImage(55+jm_dh_x,8,10,50,dian);

}
else
OLED_ClearArea(55,8,10,50);
if(dian_time>80)
dian_time=0;
dian_time++;



OLED_ShowImage(5+jm_dh_x,8,30,50,bp_tp[(hour-hour%10)/10]);
		OLED_ShowImage(32+jm_dh_x,8,30,50,bp_tp[hour%10]);
		OLED_ShowImage(69+jm_dh_x,8,30,50,bp_tp[(minute-minute%10)/10]);
		OLED_ShowImage(96+jm_dh_x,8,30,50,bp_tp[minute%10]);

OLED_ShowNum(107-jm_dh_x,0,second,2,OLED_8X16);
OLED_ShowNum(65-jm_dh_x,56,month,2,OLED_6X8);
OLED_ShowString1(78-jm_dh_x,56,".",OLED_6X8);

OLED_ShowNum(83-jm_dh_x,56,day,2,OLED_6X8);
OLED_ShowString1(95-jm_dh_x,56,".",OLED_6X8);
OLED_ShowNum(107-jm_dh_x,56,week,1,OLED_6X8);


OLED_DrawLine(-5-jm_dh_x,10,100-jm_dh_x,10);

OLED_DrawLine(100-jm_dh_x,10,110-jm_dh_x,0);
OLED_DrawLine(0-jm_dh_x,50,55-jm_dh_x,50);
OLED_DrawLine(55-jm_dh_x,50,60-jm_dh_x,64);
if(sy_set==1)
OLED_ShowImage(67-jm_dh_x,-2,10,11,voice);
else
OLED_ShowImage(67-jm_dh_x,-2,13,11,voice2);
OLED_ShowImage(82-jm_dh_x,-2,12,11,Mysoft);


OLED_ShowString1(-5-jm_dh_x,56,"No app",OLED_6X8);

	//	OLED_ShowImage(40,20,30,50,bp_tp[(second-second%10)/10]);
	//	OLED_ShowImage(120,20,30,50,bp_tp[second%10]);

}

int power_sb=1;
int djtime=0;
	int dj=1;
int xptime=100;
int tw_x,tw_y,tw_z;
int jc=1;
int main()
{
	
	delay_init();
	key_int();
//Bmp280Init();
	OLED_Init();
ADC_gpio_init();
	ADC_init();
	DMA_init();
	extil_init();
	 //AT24CXX_Init(); 
	MyRTC_Init();
		timerini();
		TIM_Cmd(TIM3,DISABLE);
	//ADXL345_Init();
	//gpio_init_1();
	//ck_init_1();
GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE); 
/*
FLASH_ReadMoreData(0x0800CFEC,&dhxg,2);
FLASH_ReadMoreData(0x0800CFEF,&gb_tb,2);
FLASH_ReadMoreData(0x0800CFF2,&sy_set,2);
FLASH_ReadMoreData(0x0800CFF5,&taiwan,2);
FLASH_ReadMoreData(0x0800CFF7,&fx_set,2);
FLASH_ReadMoreData(0x0800CFF9,&dj,2);
FLASH_ReadMoreData(0x0800CFFC,&xptime,3);
*/
	dack=0;
dackdh();
	dack=0;

		 LK=0;
			//	AT24CXX_Read(0x02,&fx_set,1);
					//	AT24CXX_Read(0x03,&dj,1);
				//AT24CXX_Read(0x04,&xptime,3);

	while(1)
   {
		 
		 lightdh();
		 
if(taiwan==1)
{

	get_angle(&tw_x,&tw_y,&tw_z);
if(tw_x>87)
{jc=0;
}
if(tw_x<-120)
{jc=1;
}}

if(jc==0)
{ 
	for(int gj_dh=0;gj_dh<=32;gj_dh+=1)
	{
		//OLED_ClearArea(0,0,128,gj_dh-1);
//OLED_ClearArea(0,64-gj_dh+1,128,32);
	OLED_DrawLine(0,gj_dh,128,gj_dh);

	OLED_DrawLine(0,64-gj_dh,128,64-gj_dh);
	OLED_WriteCommand(0x81);
OLED_WriteCommand(225-gj_dh*7);

OLED_Update();
	}
	
				 LK=0;
  
	dack=0;
	OLED_Power(0);
}

if(jc==1)
{	OLED_Power(1);

		 if(power_sb==0)
{	 	
			  jm_dh_x=-100;

	for(int gj_dh=0;gj_dh<=32;gj_dh+=1)
	{
		//OLED_ClearArea(0,0,128,gj_dh-1);
//OLED_ClearArea(0,64-gj_dh+1,128,32);
	OLED_DrawLine(0,gj_dh,128,gj_dh);

	OLED_DrawLine(0,64-gj_dh,128,64-gj_dh);
	OLED_WriteCommand(0x81);
OLED_WriteCommand(225-gj_dh*7);

OLED_Update();
	}
	
			 LK=0;

	dack=0;
			OLED_Power(0);

		 __WFI();	//WFIָ�����˯��
}


//delay_ms(25);


////////////////
/*
	   static int dog=0;
		 static int dog1=0;
		 static int dog2=0;
*/
	 int p=0;


if(dj==1)
{
djtime++;
if(djtime>xptime*4)
{djtime=0;
	power_sb=0;
}		
}
	OLED_Power(1);

	
OLED_Clear();
/*
zfdh();

		  if(dog2>=6)
			{
			 dog2=0;
			}
			 if(dog2>=0&&dog2<3)
			 {
       OLED_ShowImage(0,0,128,64,sy);
			 }
			 if(dog2>=3&&dog2<6)
			 {
       OLED_ShowImage(0,0,128,64,sy4);
			 }
dog2++;
dog++;
		 if(dog>7&&dog1==0)
		 {
			 dog1=1;
		 }
		 if(dog1==1)
		 { dog-=2;
			 if(dog<0)
			 {
				 dog1=0;
				 
			 }
		 }
		 dog2++;
		 
		OLED_ShowString1(0,40-dog,"!!!",OLED_8X16);
		*/
time_appear3();
		  dycl();
		// zfdh();
		 OLED_Update();
		 ///////////////////////
		 
	   
   
	   p = menu_Roll_event();	
	  
	   if( p == 1)
			 
	   { 
		  jm_dh_x=-100;
		   
			   main_menu1(); 
		   
			 sysj=0;
       }	 
	   p = menu_Enter_event();	

     if(p==2)
	 {		  jm_dh_x=-100;

			 power_sb=0;


	 }

		   
	   p = menu_Roll_event();	
	   if(p==-1)
	   { 
		 		  jm_dh_x=-100;

		   			 			 sysj=0;

			   main_menu();
		   
			 			 sysj=0;

	   }	
   }
 }
}

void EXTI0_IRQHandler(void)
{
	if (EXTI_GetITStatus(EXTI_Line0) == SET)	   
	{							  jm_dh_x=-100;
 
		power_sb=1;

		
		EXTI_ClearITPendingBit(EXTI_Line0);																										
	}
}
