
#include "stm32f10x.h"
#include<math.h>
#include<stdio.h>
#include<Delay.h>
#include<OLED.h>
#include<OLED_Data.h>
#include<stdlib.h>
#include<KEY.h>
#include<menu.h>
#include<game7.h>
#include "timerclock.h"
//oledÇý¶¯´úÂëÀ´×Ô½­Ð­¿Æ¼¼
//oled½Ób6b7b8b9£¨b7Îª¸ßµçÆ½£©
//Ò»¸öÁ½ÖáÒ¡¸Ë£¬x½Óa0£¬y½Óa1£¬z½Óa2
int x,y,xx,yy,xxx,yyy,xi,yi;
u8 keyvalue_game7,key_game7=5;
u8 count_game7,count1_game7,count2;
u8 time_game7,time1_game7;
u8 boomover=0;
u8 map[16][8];
u8 save[16][8];
u8 flag[16][8];
u8 boomnum,over;
u8 find1,find2,find3,find4;
u16 winnum,winini,win;
  int KEY;
int xnadc_count_x=20000,xnadc_count_y=20000;
void getnum(u8 aa,u8 aaa) //»ñÈ¡ÖÜÎ§¶àÉÙÀ×
{
	u8 t;
	for (t=0;t<8;t++)
	{
		switch(t)
		{
			case 0:if ((map[aa+1][aaa]==10)&&(aa+1<16)) boomnum++;break;
			case 1:if ((map[aa-1][aaa]==10)&&(aa-1>=0)) boomnum++;break;
			case 2:if ((map[aa+1][aaa+1]==10)&&(aaa+1<8)&&(aa+1<16)) boomnum++;break;
			case 3:if ((map[aa+1][aaa-1]==10)&&(aaa-1>=0)&&(aa+1<16)) boomnum++;break;
			case 4:if ((map[aa-1][aaa-1]==10)&&(aa-1>=0)&&(aaa-1>=0)) boomnum++;break;
			case 5:if ((map[aa-1][aaa+1]==10)&&(aa-1>=0)&&(aaa+1<8)) boomnum++;break;
			case 6:if ((map[aa][aaa+1]==10)&&(aaa+1<8)) boomnum++;break;
			case 7:if ((map[aa][aaa-1]==10)&&(aaa-1>=0)) boomnum++;break;
		}
	}
}
void noboom(u8 aa,u8 aaa)  //°´¼üµÚÒ»ÏÂ¾Å¹¬¸ñÄÚÃ»ÓÐÀ×
{
	u8 t;
	for (t=0;t<8;t++)
	{
		switch(t)
		{
			case 0:if ((map[aa+1][aaa]==10)&&(aa+1<16)) map[aa+1][aaa]=11;break;
			case 1:if ((map[aa-1][aaa]==10)&&(aa-1>=0)) map[aa-1][aaa]=11;break;
			case 2:if((map[aa+1][aaa+1]==10)&&(aaa+1<8)&&(aa+1<16)) map[aa+1][aaa+1]=11;break;
			case 3:if ((map[aa+1][aaa-1]==10)&&(aaa-1>=0)&&(aa+1<16)) map[aa+1][aaa-1]=11;break;
			case 4:if ((map[aa-1][aaa-1]==10)&&(aa-1>=0)&&(aaa-1>=0)) map[aa-1][aaa-1]=11;break;
			case 5:if ((map[aa-1][aaa+1]==10)&&(aa-1>=0)&&(aaa+1<8)) map[aa-1][aaa+1]=11;break;
			case 6:if ((map[aa][aaa+1]==10)&&(aaa+1<8))  map[aa][aaa+1]=11;break;
			case 7:if ((map[aa][aaa-1]==10)&&(aaa-1>=0)) map[aa][aaa-1]=11;break;
		}
		if (map[aa][aaa]==10) map[aa][aaa]=11;
	}
}
void boomini()  //Õ¨µ¯Î±Ëæ»ú£¬ÔÚ´Ë´Î¿ÉÐÞ¸ÄÕ¨µ¯¸öÊý
{
	u8 j,k;
	u32 all;
	for (j=0;j<16;j++)
	for (k=0;k<8;k++)
	{map[j][k]=11;}
	for (j=0;j<16;j++)
	{all=(count1_game7+count2+count_game7)%10;if (all<8)map[j][all]=10;delay_ms(20+all);}
	map[all+count1_game7][7]=10;
	boomover=1;
	noboom(xx/8,yy/8);
	for (j=0;j<16;j++)
	for (k=0;k<8;k++)
	{if (map[j][k]!=10) {getnum(j,k);map[j][k]=boomnum;boomnum=0;}
	 if (map[j][k]==10) winini++;	
	}
}
static int state_game7=0;

void getad()  //Ò¡¸ËºÍ°´¼ü////////////////////////////////////////////////////////////////////////////////////
{
   

KEY=key_scan(0);
if(KEY==key1ps)
{
state_game7++;
}
if(state_game7>3)
state_game7=0;
if(state_game7==0)
{
if(KEY==key3ps)
xnadc_count_x+=600;
if(KEY==key2ps)
xnadc_count_x-=600;
}
if(state_game7==1)
{
if(KEY==key3ps)
xnadc_count_y+=600;
if(KEY==key2ps)
xnadc_count_y-=600;
}

	if (xnadc_count_x>=xi+100||xnadc_count_x<=xi-100||xnadc_count_y>=xi+100||xnadc_count_y<=xi-100)
		{
      x=xnadc_count_x;
		  y=xnadc_count_y;
			xxx=x/100-xi/100;
			yyy=y/100-xi/100;
			if (xx+xxx/4>0&&xx+xxx/4<128)	xx=xx+xxx/4;
			if (yy+yyy/4>0&&yy+yyy/4<64) yy=yy+yyy/4;
		}
			if (key_game7>1)
		{
            
		if(state_game7==2){
              	if (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)==0)
					{
						if (boomover==0) 
						boomini();
							keyvalue_game7=1;
							key_game7=0;
					}
				if (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)==0)
				{
					if (flag[xx/8][yy/8]==0) flag[xx/8][yy/8]=1;
					else if(flag[xx/8][yy/8]==1) flag[xx/8][yy/8]=0;
								key_game7=0;
				}}
		}
}
void find (u8 c,u8 cc)   //ÕÒµ½ÓÐÊý×ÖµÄÇøÓò²¢ÔÝÍ£
{
	u8 t;
	t=0;
	while (over==0)
	{
		if(find1==0) {if (c+t==15) find1=1;if (map[c+t][cc]==0) save[c+t][cc]=map[c+t][cc];else {if (map[c+t][cc]==10) find1=1;else {save[c+t][cc]=map[c+t][cc];find1=1;}}}
		if(find2==0) {if (c==t) find2=1;if (map[c-t][cc]==0) save[c-t][cc]=map[c-t][cc];else {if (map[c-t][cc]==10) find2=1;else {save[c-t][cc]=map[c-t][cc];find2=1;}}}
		if(find3==0) {if (cc+t==7) find3=1;if (map[c][cc+t]==0) save[c][cc+t]=map[c][cc+t];else {if (map[c][cc+t]==10) find3=1;else {save[c][cc+t]=map[c][cc+t];find3=1;}}}
		if(find4==0) {if (cc==t) find4=1;if (map[c][cc-t]==0) save[c][cc-t]=map[c][cc-t];else {if (map[c][cc-t]==10) find4=1;else {save[c][cc-t]=map[c][cc-t];find4=1;}}}
		if (find1+find2+find3+find4==4) over=1;
		t++;
	}
	over=0;find1=0;find2=0;find3=0;find4=0;
}
void findnum()   //ÕÒµ½Êý×Ö
{
	u8 j,k;

	 for (j=0;j<16;j++)
	 for (k=0;k<8;k++)
		{
			if (save[j][k]==0) find (j,k);
			if (save[j][k]==11) winnum++;
		}
		if (winnum==winini) win=1;
		winnum=0;
} 
void play()   //µã»÷Âß¼­
{
	if (keyvalue_game7==1)
	{
		if (save[xx/8][yy/8]==11)
		{
			save[xx/8][yy/8]=map[xx/8][yy/8];if (save[xx/8][yy/8]==10) win=2;
		}
	}
}
void showboom()  //ÏÔÊ¾
{
	u8 j,k;
	for (j=0;j<16;j++)
	for (k=0;k<8;k++)
	{  OLED_DrawLine(0, 0+8*k, 128,  0+8*k);OLED_DrawLine(0+8*j,0, 0+8*j,64);if (save[j][k]==10)  (j*8, k*8,7, 7, boom);
		if (save[j][k]!=10&&save[j][k]!=0&&save[j][k]!=11) OLED_ShowNum(j*8, k*8, save[j][k],1, OLED_6X8);
		if (save[j][k]!=11) {if (save[j][k]==0) OLED_ClearArea(j*8, k*8,8, 8);OLED_ReverseArea(j*8, k*8,8, 8);}
		if (flag[j][k]==1) OLED_ShowImage(j*8+1, k*8+1,5, 5, flagbmp);
	}
}
void game7(void)
{
int8_t p;
		dack=0;
dackdh();
dack=0;

		 LK=0;		

	u8 j,k;
	for (j=0;j<16;j++)for (k=0;k<8;k++){map[j][k]=11;save[j][k]=11;}
		TIM_Cmd(TIM3,ENABLE);

	xi=xnadc_count_x;
	yi=xnadc_count_y;
	while (1)
	{ lightdh();
		if (win==0)
		{
		getad();
		play();
		OLED_ClearArea(0, 0,128, 64);
	  showboom();
		findnum();
		if (save[xx/8][yy/8]==11)OLED_DrawCircle(xx,yy,1,OLED_FILLED);
		OLED_ReverseArea(0, 0,128,64);
		if (save[xx/8][yy/8]!=11) OLED_DrawCircle(xx,yy,1,OLED_FILLED);
		keyvalue_game7=0;
		}
		else if (win==1)
		{



x=0,y=0,xx=0,yy=0,xxx=0,yyy=0,xi=0,yi=0;

 keyvalue_game7=0,key_game7=5;
 count_game7=0,count1_game7=0,count2=0;
 time_game7=0,time1_game7=0;
 boomover=0;
  for(int save_oo=0;save_oo<=15;save_oo++)
  {
		   		   for(int save_oo1=0;save_oo1<=7;save_oo1++)
				   {
 map[save_oo][save_oo1]=0;
 save[save_oo][save_oo1]=0;
 flag[save_oo][save_oo1]=0;				   }}
 
 boomnum=0,over=0;
find1=0,find2=0,find3=0,find4=0; winnum=0,winini=0,win=0;




			OLED_ShowString1(50,30,"YOU WIN!", OLED_6X8);
						OLED_Update();

            if(key_game7==2)
			dackdh();
LK=0;	TIM_Cmd(TIM3,DISABLE);

            break;
		}
		else if (win==2)
		{

x=0,y=0,xx=0,yy=0,xxx=0,yyy=0,xi=0,yi=0;

 keyvalue_game7=0,key_game7=5;
 count_game7=0,count1_game7=0,count2=0;
 time_game7=0,time1_game7=0;
 boomover=0;
  for(int save_oo=0;save_oo<=15;save_oo++)
  {
		   		   for(int save_oo1=0;save_oo1<=7;save_oo1++)
				   {
 map[save_oo][save_oo1]=0;
 save[save_oo][save_oo1]=0;
 flag[save_oo][save_oo1]=0;				   }}
 
 boomnum=0,over=0;
find1=0,find2=0,find3=0,find4=0; winnum=0,winini=0,win=0;




			OLED_ShowString1(50,30,"you lose", OLED_6X8);
			OLED_Update();
             if(key_game7==2)
			 dackdh();
LK=0;	TIM_Cmd(TIM3,DISABLE);

            break;
		}
        OLED_ShowNum(122,58,state_game7,1,OLED_6X8);

		OLED_Update();
        if(state_game7==3)
        if(KEY==2){

			
x=0,y=0,xx=0,yy=0,xxx=0,yyy=0,xi=0,yi=0;

 keyvalue_game7=0,key_game7=5;
 count_game7=0,count1_game7=0,count2=0;
 time_game7=0,time1_game7=0;
 boomover=0;
  for(int save_oo=0;save_oo<=15;save_oo++)
  {
		   		   for(int save_oo1=0;save_oo1<=7;save_oo1++)
				   {
 map[save_oo][save_oo1]=0;
 save[save_oo][save_oo1]=0;
 flag[save_oo][save_oo1]=0;				   }}
 
 boomnum=0,over=0;
find1=0,find2=0,find3=0,find4=0; winnum=0,winini=0,win=0;
dackdh();
LK=0;
//		
	TIM_Cmd(TIM3,DISABLE);

			 break;
		}
       
	}
}

