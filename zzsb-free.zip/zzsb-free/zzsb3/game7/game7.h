#ifndef __GAME7_H
#define __GAME7_H
void game7();
extern u8 key_game7,count_game7,count1_game7,count2,time_game7,time1_game7;
 
 
#endif