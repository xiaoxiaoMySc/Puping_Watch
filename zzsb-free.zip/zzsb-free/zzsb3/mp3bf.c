#include<usart.h>
#include<stm32f10x.h>
#include<OLED.h>
#include<OLED_Data.h>
#include<Delay.h>
#include<menu.h>
#include<menu.h>
void mp3_init()
{
//	gpio_init_3();
//	ck_init_3();
//	
}

void mp3_start()
{
int8_t p;
		dack=0;
dackdh();
	dack=0;

		 LK=0;
	put3(0x7E);
put3(0xFF);
put3(0x06);
put3(0x06);
put3(0x00);
put3(0x00);
put3(0x05);
put3(0xEF);
	while(1)
	{
		
	static int mode=0,num=0,bfmd=0,vec=5;
		static int bfmode=0;
		static int bfmdxz,bfmdxz1;
				static int bfmdxz2,bfmdxz3;
		static int bfmdxz4,bfmdxz5;
		static int bfmdxz6,bfmdxz7;

		
 lightdh();
		OLED_Clear();
OLED_ShowString1(0,0,"<���ֲ���>",OLED_8X16);
		OLED_ShowString1(0,50,"mode:cycle all",OLED_6X8);
		OLED_ShowString1(90,50,"vce:",OLED_6X8);

		OLED_ShowString1(12,25,"<<",OLED_8X16);
				OLED_ShowString1(61,25,"O",OLED_8X16);

		OLED_ShowString1(100,25,">>",OLED_8X16);
OLED_ShowNum(90,2,num,4,OLED_6X8);
		OLED_ShowNum(114,50,vec,2,OLED_6X8);

if(bfmode==0)
			OLED_ShowString1(0,50,"mode:cycle all",OLED_6X8);
else
					OLED_ShowString1(0,50,"mode:mix all",OLED_6X8);
bfmdxz2+=(bfmdxz3-bfmdxz2)/8;
bfmdxz4+=(bfmdxz5-bfmdxz4)/8;
bfmdxz6+=(bfmdxz7-bfmdxz6)/8;

bfmdxz+=(bfmdxz1-bfmdxz)/8;
OLED_DrawRectangle(bfmdxz,bfmdxz2,bfmdxz4,bfmdxz6,OLED_UNFILLED);
//			OLED_ReverseArea();


	   p = menu_Roll_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  
		if(bfmd==0)
		{
			bfmdxz1=96;bfmdxz3=-7;bfmdxz5=24;bfmdxz7=8;
////			OLED_ReverseArea(90,2,24,8);

	   if( p == 1){ 
put3(0x7E);
put3(0xFF);
put3(0x06);
put3(0x02);
put3(0x00);
put3(0x00);
put3(0x00);
put3(0xEF);
num--;
			 OLED_ReverseArea(12,25,16,16);
	   }	 
       else if( p == -1){ 
			 OLED_ReverseArea(100,25,16,16);

put3(0x7E);
put3(0xFF);
put3(0x06);
put3(0x01);
put3(0x00);
put3(0x00);
put3(0x00);
put3(0xEF);
				 num++;
	   }
	 }
			 if(bfmd==1)
		{			bfmdxz1=-6;bfmdxz3=-6;bfmdxz5=85;bfmdxz7=24;

//										 OLED_ReverseArea(0,0,83,16);

			if(p==1)
			{
mode=0,num=0,bfmd=0,vec=5;bfmode=0;bfmdxz=0;
							bfmdxz1=90;bfmdxz3=2;bfmdxz5=24;bfmdxz7=8;

				
		dackdh();
LK=0;
		
			break;
			}
		}
		if(bfmd==2)
		{					bfmdxz1=93;bfmdxz3=55;bfmdxz5=36;bfmdxz7=8;

//			OLED_ReverseArea(90,50,36,8);

if(p==1)
{put3(0x7E);
put3(0xFF);
put3(0x06);
put3(0x04);
put3(0x00);
put3(0x00);
put3(0x00);
put3(0xEF);
	vec++;
}
			if(p==-1)
{put3(0x7E);
put3(0xFF);
put3(0x06);
put3(0x05);
put3(0x00);
put3(0x00);
put3(0x00);
put3(0xEF);
	vec--;
}
if(vec>30)
vec=30;
if(vec<0)
	vec=0;
		}
		if(bfmd==3)
		{			bfmdxz1=-6;bfmdxz3=55;bfmdxz5=91;bfmdxz7=8;

//			OLED_ReverseArea(0,50,84,8);

			if(p==1)
			{
		put3(0x7E);
put3(0xFF);
put3(0x06);
put3(0x018);
put3(0x00);
put3(0x00);
put3(0x00);
put3(0xEF);
				bfmode=1;
			}
			
			if(p==-1)
			{
		put3(0x7E);
put3(0xFF);
put3(0x06);
put3(0x019);
put3(0x00);
put3(0x00);
put3(0x00);
put3(0xEF);
				bfmode=0;
			}
			
		}
		
		if(bfmd>3)
			bfmd=0;
		
		p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����
		if(p==1){
			mode++;
		}
		else if ( p==2 ){
		bfmd++;
			
			
		}
		
		if(mode>1)
			mode=0;
		
		if(mode==0)
		{OLED_ShowString1(61,25,"O",OLED_8X16);
//			p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����
		if(p==1)
			{
		put3(0x7E);
put3(0xFF);
put3(0x06);
put3(0x0D);
put3(0x00);
put3(0x00);
put3(0x00);
put3(0xEF);
		}
		}else
		{
//			p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����
		if(p==1)
			{OLED_ShowString1(61,25,"=",OLED_8X16);
		put3(0x7E);
put3(0xFF);
put3(0x06);
put3(0x0E);
put3(0x00);
put3(0x00);
put3(0x00);
put3(0xEF);
		}
		
		}
	
		OLED_Update();delay_ms(15);

	}




}