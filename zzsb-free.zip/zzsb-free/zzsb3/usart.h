#ifndef _USART_H
#define _USART_H
#include<stm32f10x.h>
 extern u8 RxBuffer[3];
extern vu8 RxCount;
extern vu8 RxHeader;
extern vu8 RxOK;
extern vu8 RxLen;
extern unsigned int a;

void  gpio_init_1();
void ck_init_1();

void  gpio_init_2();
void ck_init_2();

void  gpio_init_3();
void ck_init_3();
void EMPTYRxBuffer(u8 len);


unsigned int Serial_GetRxFlag(void);
void USART1_IRQHandler();

void put1(int hex);
void put1_2(int hex);

void put(int *str);
void put3(int hex);

#endif