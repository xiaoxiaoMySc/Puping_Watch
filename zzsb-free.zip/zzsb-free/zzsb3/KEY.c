#include<KEY.h>
#include<stm32f10x.h>
#include<Delay.h>

#define key1 GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)
#define key2 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)
#define key3 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)

#define keyunps 0
#define key1ps 1
#define key2ps 2
#define key3ps 3

void key_int()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);

	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_8|GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
}
void Key_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);

}






	int key_scan(unsigned int MODE)
{
	static int ky=0;
	if(MODE) ky=0;
	if(ky==0&&(key1==0||key2==0||key3==0))
	{
		
		delay_ms(5);
		ky=1;
		if(key1==0)
			return key1ps;
		if(key2==0)
			return key2ps;
		if(key3==0)
			return key3ps;
		
	}
	if(key1==1&&key2==1&&key3==1)
	{
		ky=0;
		return keyunps;
	}
	return 0;
}


