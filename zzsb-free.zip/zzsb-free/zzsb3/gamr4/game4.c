


#include "stm32f10x.h"
#include<math.h>
#include<stdio.h>
#include<Delay.h>
#include<OLED.h>
#include<OLED_Data.h>
#include<stdlib.h>
#include<KEY.h>
#include<menu.h>
#include<game4.h>
#include "timerclock.h"
//oledÇý¶¯´úÂëÀ´×Ô½­Ð­¿Æ¼¼
//oled½Ób6b7b8b9£¨b7Îª¸ßµçÆ½£©
//Ò»¸öÁ½ÖáÒ¡¸Ë£¬x½Óa0£¬y½Óa1£¬z½Óa2
int x_game4,y_game4,xx_game4,yy_game4,xxx_game4,yyy_game4,xi_game4,yi_game4;
u8 time1s,key_game4,keyvalue_game4,plantmode=0,clear=0,time2s,planttime,znum,zonce,eatonce,pheathy,move,zset,sunshow,addsunnum,suntime;
u8 zmiao;
int kill;
u8 sunnum=2,sunget=0;
u8 hangi,hit;
u8 map_game4[4][7];
u8 zheath[4][50];
u8 pheath[4][7];
u8 zmove[4][50];
u8 hittime[4][7];
u8 ztime[4][50];
u8 hitmove[4][50];
u8 beannum[4][7];
u8 onece[4][7];
u8 gameover=0;
int xnadc_count_x_4=20000,xnadc_count_y_4=20000;
int KEY_game4;
int state_game4;
void getad_game4()
{


KEY_game4=key_scan(0);
if(KEY_game4==key1ps)
{
state_game4++;
}
if(state_game4>3)
state_game4=0;
if(state_game4==0)
{
if(KEY_game4==key3ps)
xnadc_count_x_4+=500;
if(KEY_game4==key2ps)
xnadc_count_x_4-=500;
}
if(state_game4==1)
{
if(KEY_game4==key3ps)
xnadc_count_y_4+=500;
if(KEY_game4==key2ps)
xnadc_count_y_4-=500;
}

	if (xnadc_count_x_4>=xi_game4+100||xnadc_count_x_4<=4-100||xnadc_count_y_4>=xi_game4+100||xnadc_count_y_4<=xi_game4-100)
		{
      x_game4=xnadc_count_x_4;
		  y_game4=xnadc_count_y_4;
			xxx_game4=x_game4/100-xi_game4/100;
			yyy_game4=y_game4/100-xi_game4/100;
			if (xx_game4+xxx_game4/4>0&&xx_game4+xxx_game4/4<128)	xx_game4=xx_game4+xxx_game4/4;
			if (yy_game4+yyy_game4/4>0&&yy_game4+yyy_game4/4<64) yy_game4=yy_game4+yyy_game4/4;
		}


			if (key_game4>1)
		{
			if(state_game4==2)
			{
		if (GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)==0)
					{
							keyvalue_game4=1;
							key_game4=0;
					}}



		}
}








void zhave(u8 liez)
{
	 u8 zd;
	 for(zd=0;zd<50;zd++)
	{
		if (zmove[liez][zd]==0) {zmove[liez][zd]=128;zheath[liez][zd]=4;break;}//zheath½©Ê¬µÄÑªÁ¿
	}
}
void zmap()  //³ö¹ÖÊý¾Ý
{
	u8 y_game4;
	if (zonce==1)
	{
					if (znum<=20)
					{
					switch (znum)
					{
						case 0:zhave(0);break;
						case 1:zhave(1);break;
						case 2:zhave(1);zhave(2);break;
						case 3:zhave(3);zhave(1);break;
						case 4:zhave(2);zhave(4);break;
						case 5:zhave(3);zhave(1);zhave(1);break;
						case 6:zhave(3);zhave(1);break;
						case 7:zhave(1);zhave(2);break;
						case 8:zhave(0);zhave(1);break;
						case 9:zhave(0);zhave(1);break;
						case 10:zhave(1);zhave(1);break;
						case 11:zhave(0);zhave(3);break;
						case 12:zhave(2);zhave(2);break;
						case 13:zhave(0);zhave(2);break;
						case 14:zhave(3);zhave(1);break;
						case 15:zhave(0);zhave(3);break;
						case 16:zhave(1);zhave(3);break;
						case 17:zhave(0);zhave(3);break;
						case 18:zhave(3);zhave(3);break;
						case 19:zhave(2);zhave(1);break;
						case 20:zhave(0);zhave(1);break;
					}
					}
					else 
					{
						znum=21;
						for (y_game4=0;y_game4<4;y_game4++)
						{
							zhave(y_game4);
						}
						
					}
			zonce=0;
		}
}
void beanhitmove(u8 liei)
{
	u8 zi;
	hangi=0;
	for (hangi=0;hangi<50;hangi++)
	{
		if (hitmove[liei][hangi]!=0) 
		{
				OLED_DrawCircle(hitmove[liei][hangi],7+liei*15,1,OLED_FILLED);
				hitmove[liei][hangi]=hitmove[liei][hangi]+1;
				for(zi=0;zi<50;zi++)
				{
					if ((zmove[liei][zi]-hitmove[liei][hangi])>0&&(zmove[liei][zi]-hitmove[liei][hangi]<3)) {zheath[liei][zi]--;if (zheath[liei][zi]==0) {kill++;zmove[liei][zi]=0;}hitmove[liei][hangi]=0;break;}
				}
				if (hitmove[liei][hangi]>=128) hitmove[liei][hangi]=0;
		}
	}
		for (hangi=0;hangi<50;hangi++)
		{
			if (zmove[liei][hangi]!=0)
			{
					 for(zi=0;zi<7;zi++)
							{
								if (ztime[liei][hangi]==0) {zmove[liei][hangi]=zmove[liei][hangi]-1;move=1;ztime[liei][hangi]=1;}
								if (zmove[liei][hangi]<120)
								{
										if (zmove[liei][hangi]-(21+zi*15)>1&&zmove[liei][hangi]-(21+zi*15)<3)
										{
											if (map_game4[liei][zi]!=0) {if (move==1) {zmove[liei][hangi]=zmove[liei][hangi]+1;move=0;}if (planttime==0&&eatonce==1)  {pheath[liei][zi]--;eatonce=0;}	}	
										if (pheath[liei][zi]==0) map_game4[liei][zi]=0;
										}
								}
							}
			if (time1s==1) OLED_ShowImage(zmove[liei][hangi]-1,liei*15, 11,15, zomb1);
			else OLED_ShowImage(zmove[liei][hangi],liei*15, 11,15, zomb2);		
			}
			if (zmove[liei][hangi]>0&&zmove[liei][hangi]<14) gameover=1;
	  }
}
void ztimeset()
{
	u8 tt,t;
	for (t=0;t<4;t+=1 )
	for (tt=0;tt<50;tt++)
	{
		ztime[t][tt]=0;
	}
}
void zombieshit()
{
  u8 lie,hang;
	u8 getnum,numz;
	for (lie=0;lie<4;lie++)
	{																	
				for (hang=0;hang<7;hang++)
				{
					if(map_game4[lie][hang]==2)
					{
						for (numz=0;numz<50;numz++)
						{
							if (zmove[lie][numz]>hang*15+14) {hit=1;break;}
						}
						if (hit==1)
						{
						if (planttime==1) {if (onece[lie][hang]==0) {hittime[lie][hang]=0;onece[lie][hang]=1;}}
						else  {onece[lie][hang]=0;}
						if (hittime[lie][hang]==0)
						{
																	getnum=0;
																	for (getnum=0;getnum<50;getnum++)
																	{
						                    	  if (hitmove[lie][getnum]==0) break;
																	}
																	hitmove[lie][getnum]=18+hang*15;	
						}
						hittime[lie][hang]=1;
						hit=0;
				  	}
					}	
				}
		beanhitmove(lie);
  }
}
void getplant()
{
	
		if (xx_game4>0&&xx_game4<14)
		{
			if(sunnum!=0)
	{
			if (yy_game4>8&&yy_game4<22)   { OLED_ReverseArea(3,12,9,11);if (keyvalue_game4==1) {plantmode=1;clear=0;}}
			else if (yy_game4>22&&yy_game4<36) {OLED_ReverseArea(3,25,9,11);if (keyvalue_game4==1) {plantmode=2;clear=0;}}
			if (sunnum>1) {if (yy_game4>36&&yy_game4<50)  {OLED_ReverseArea(3,39,9,11);if (keyvalue_game4==1) {plantmode=3;clear=0;}}}
	}
			if (yy_game4>50&&yy_game4<62)  {OLED_ReverseArea(3,51,9,8);if (keyvalue_game4==1) {clear=1;plantmode=0;}}
		}
}
void heathy()
{
if (plantmode==1) {pheathy=2;sunnum--;}
else if (plantmode==2) {pheathy=2;sunnum--;}
else if (plantmode==3) {pheathy=10;sunnum=sunnum-2;}
}
void moveplant()
{
		if (keyvalue_game4==1)
		{
			if (xx_game4>14&&xx_game4<124)
			{
				if (yy_game4>0&&yy_game4<15) {if (map_game4[0][(xx_game4-14)/15]==0) {map_game4[0][(xx_game4-14)/15]=plantmode;heathy();pheath[0][(xx_game4-14)/15]=pheathy;plantmode=0;}}
				else if (yy_game4>15&&yy_game4<30) {if (map_game4[1][(xx_game4-14)/15]==0) {map_game4[1][(xx_game4-14)/15]=plantmode;heathy();pheath[1][(xx_game4-14)/15]=pheathy;plantmode=0;}}
				else if (yy_game4>30&&yy_game4<45) {if (map_game4[2][(xx_game4-14)/15]==0) {map_game4[2][(xx_game4-14)/15]=plantmode;heathy();pheath[2][(xx_game4-14)/15]=pheathy;plantmode=0;}}
				else if (yy_game4>45&&yy_game4<60) {if (map_game4[3][(xx_game4-14)/15]==0) {map_game4[3][(xx_game4-14)/15]=plantmode;heathy();pheath[3][(xx_game4-14)/15]=pheathy;plantmode=0;}}			
			if (clear==1)
			{
			  if (yy_game4>0&&yy_game4<15) {map_game4[0][(xx_game4-14)/15]=0;}
				else if (yy_game4>15&&yy_game4<30) {map_game4[1][(xx_game4-14)/15]=0;}
				else if (yy_game4>30&&yy_game4<45) {map_game4[2][(xx_game4-14)/15]=0;}
				else if (yy_game4>45&&yy_game4<60) {map_game4[3][(xx_game4-14)/15]=0;}			
				clear=0;
			}
			}
		}
}
void showplant()
{
	u8 i,k;
	for(i=0;i<4;i++)
	for (k=0;k<7;k++)
	{
		if(map_game4[i][k]!=0)
		{
			if (time1s==1)
			{
					switch (map_game4[i][k])
				{
					case 1:if (sunget==1) OLED_ShowImage(16+k*15,5+i*15, 6,9, sun);else OLED_ShowImage(16+k*15,3+i*15, 10,12, flower1);break;
					case 2:OLED_ShowImage(16+k*15,4+i*15, 10,12, bean1);break;
					case 3:OLED_ShowImage(16+k*15,4+i*15, 10,12, nut1);break;
				}
    	}
			else 
			{
				switch (map_game4[i][k])
				{
					case 1:if (sunget==1) OLED_ShowImage(16+k*15,5+i*15, 6,9, sun);else OLED_ShowImage(16+k*15,3+i*15, 10,12, flower2);break;
					case 2:OLED_ShowImage(16+k*15,4+i*15, 10,12, bean2);break;
					case 3:OLED_ShowImage(16+k*15,4+i*15, 10,12, nut2);break;
				}
			}
		}
	}
}
void addsun()
{
	u8 ss,sss;
		if (addsunnum==1)	{
		for (ss=0;ss<4;ss++)
		for (sss=0;sss<7;sss++)
		{
		if (map_game4[ss][sss]==1) sunnum++;
		}
		addsunnum=0;
	 }
}
void game4(void)
{	timerini();
	xi_game4=xnadc_count_x_4;
	yi_game4=xnadc_count_y_4;
	while (1)
	{
		if (gameover==0)
		{
		OLED_ClearArea(0, 0,128, 64);
		getad_game4();
		OLED_ShowImage(0,0, 126,62, bmp_ZWDZJS);
		OLED_ShowNum(3, 2,sunnum,2,OLED_6X8);
		zmap();
		addsun();
		getplant();
		if(plantmode!=0||clear!=0) moveplant();
			if (zset==1){ztimeset();zset=0;}
		showplant();
		zombieshit();
		if (plantmode==0&&clear==0) OLED_DrawCircle(xx_game4,yy_game4,2-keyvalue_game4,OLED_FILLED);
		else 
		{switch (plantmode)
		{
			case 1:OLED_ShowImage(xx_game4-5,yy_game4-5, 9,12, flower);break;
			case 2:OLED_ShowImage(xx_game4-5,yy_game4-5, 9,12, bean);break;
			case 3:OLED_ShowImage(xx_game4-5,yy_game4-5, 9,12, nut);break;
		}
		if (clear==1) OLED_ShowImage(xx_game4-5,yy_game4-5, 12,12, set);
		}
		if (keyvalue_game4==1) keyvalue_game4=0;
		OLED_ReverseArea(0, 0,128,64);

			        OLED_ShowNum(122,58,state_game4,1,OLED_6X8);

		OLED_Update();

		if(state_game4==3)
		{
if(KEY_game4==2)
break;

		}
	  }
		else
		{
			OLED_ShowString1(30, 25,"GAME OVER", OLED_8X16);
			OLED_ShowString1(30, 42,"kill",OLED_6X8);
			OLED_ShowNum(64 , 42,kill,6,OLED_6X8);
			OLED_Update();
			break;
		}
	}
}
