#ifndef __GAME4_H
#define __GAME4_H
void game4();
extern int x_game4,y_game4,xx_game4,yy_game4,xxx_game4,yyy_game4,xi_game4,yi_game4;
extern u8 time1s,key_game4,keyvalue_game4,plantmode,clear,time2s,planttime,znum,zonce,eatonce,pheathy,move,zset,sunshow,addsunnum,suntime;
extern u8 zmiao;
extern int kill;
extern u8 sunnum,sunget;
#endif
