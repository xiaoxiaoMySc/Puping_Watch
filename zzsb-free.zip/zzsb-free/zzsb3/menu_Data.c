#include <string.h>
#include <math.h>
#include "menu.h" 
#include "Delay.h"
#include "OLED.h"
#include<main.h>
#include<ADC.h>
#include<OLED_Data.h>
#include<bmp280.h>
#include<24cxx.h>
#include<MyRTC.h>
#include "string.h" 	
#include "ADXL.h"
#include<mp3bf.h>
unsigned int dy[30];
unsigned int dy1[20];
float sbq1[100];
float sbq2[100];
static int sbqtimer=0;
static int sbqd=0;
static int sbqcy=1;
static int sbqdy=4;
static int sbqdx;
							static int sbqdy;
void timer_INIT();
void sbq(void);
void dyb(void);
void om(void);
void nun()
	{
		return;
	}

//////////////////////////////

void mp3yy()
{
	mp3_init();
	mp3_start();
}

//////////////////////////////////
void om(void)
{
	int8_t p;
	
	dack=0;
dackdh();
	dack=0;

		 LK=0;
	while(1)
	{
				 lightdh();

		static int jz=0;
			static int vat=0;
unsigned int j=0;
			static int iy=0;
						unsigned int yy=0;
						static int start=0;
							static int jt=0;
														static int jt1=0;

	OLED_Clear();
		
OLED_ShowString1(60,32,"OM",OLED_8X16);
							OLED_ShowString1(0,0," <ŷķ��>",OLED_8X16);
							OLED_ShowString1(100,48,"90K",OLED_8X16);

		
OLED_ShowString1(0,48,"0",OLED_8X16);
if(jt+3<82)
{
OLED_ReverseArea(17,54,jt+3,10);
	
}
else 
{
OLED_ReverseArea(17,54,82,10);}
if(jt<jt1)

							{
								jt+=3;
							}
							if(jt>jt1)
							{
								jt-=3;
							}
							jt1=((3.3-(75/82+1)*0.000808*(iy/20))*820/((iy/20)*0.000808)-750)/800;
							
			
	

if(start==0)
{
	
	ADC_SoftwareStartConvCmd(ADC1,ENABLE);
			OLED_ShowString1(0,16,"------START------",OLED_8X16);

	
		if(vat<20)
			{
			dy1[vat]=	ADC_Value[1];
				vat++;
			}
			if(vat>=20)
			{
				iy=0;
				vat=0;
				while(j<20)
				{
					yy=dy1[j];
					iy=yy+iy;
					j++;
				}
				
			}
		
			
			
}


if(start==1){
									ADC_SoftwareStartConvCmd(ADC1,DISABLE);
	OLED_ShowString1(0,16,"------STOP------",OLED_8X16);
}					
if((3.3-(75/82+1)*0.000808*(iy/20))*820/((iy/20)*0.000808)-750>90000)
			{
OLED_ShowString1(0,32,"******",OLED_8X16);
			}
				else{					OLED_ShowNum(0,32,(3.3-(75/82+1)*0.000808*(iy/20))*820/((iy/20)*0.000808)-750-jz,6,OLED_8X16);

				}
	

	
	




		
	   p = menu_Roll_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  
	   if( p == 1){ 

start++;
if(start>1)
{
	start=0;
}

	   }	
if(p==-1)
{
	
		jz=(3.3-(75/82+1)*0.000808*(iy/20))*820/((iy/20)*0.000808)-750;

	
}	
     	   p = menu_Enter_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  

 
		 if ( p==2 ){
											ADC_SoftwareStartConvCmd(ADC1,DISABLE);

			dackdh();
LK=0;
			break;
			
		}	
		 OLED_Update();delay_ms(10);
	}
}








///////////////
void sbq(void)
{
	int8_t p;
	timer_INIT();
	dack=0;
dackdh();
	dack=0;

		 LK=0;			
	while(1)
	{
			 lightdh();

			
		
		
	static int start=0;
							static int md=0;
																							OLED_Clear();
	OLED_ShowString1(35,48,"us",OLED_8X16);
	OLED_ShowNum(0,48,sbqcy*100,4,OLED_8X16);
OLED_ShowString1(60,48,"UP",OLED_8X16);
OLED_ShowNum(102,0,sbqdy,2,OLED_8X16);
						OLED_ShowString1(112,32,"V",OLED_8X16);

OLED_ShowNum(102,32,0,1,OLED_8X16);
OLED_ShowString1(88,48,"BACK",OLED_8X16);
							OLED_DrawLine(0,49,127,49);
									OLED_DrawLine(99,48,99,0);

					OLED_DrawLine(10,44,10,48);
					OLED_DrawLine(20,44,20,48);
					OLED_DrawLine(30,44,30,48);
					OLED_DrawLine(40,44,40,48);
					OLED_DrawLine(50,44,50,48);
					OLED_DrawLine(60,44,60,48);
					OLED_DrawLine(70,44,70,48);
					OLED_DrawLine(80,44,80,48);
p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����
		
	 if ( p==2 ){
		OLED_ReverseArea(88,48,33,16);	
	
																	ADC_SoftwareStartConvCmd(ADC1,DISABLE);
	TIM_Cmd(TIM2,DISABLE);
	
		dackdh();
LK=0;
break;			
		}
 p = menu_Roll_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  
	   if( p == 1){ 

md++;
	if(md>4)
		md=0;
	   }	 
     
		
if(start==0)
{
	sbqtimer=0;
								ADC_SoftwareStartConvCmd(ADC1,ENABLE);
	TIM_Cmd(TIM2,ENABLE);
OLED_ShowString1(100,16,"S",OLED_8X16);

}	

if(start==1)
{
	sbqtimer=1;
																		ADC_SoftwareStartConvCmd(ADC1,DISABLE);
	TIM_Cmd(TIM2,DISABLE);
OLED_ShowString1(100,16,"P",OLED_8X16);

}






if(md==0)
{
							if(p==-1)
							{	start++;
								if(start>1)
									start=0;
							}			
	
	OLED_ReverseArea(100,16,8,16);

}
if(md==1)
{
		OLED_ReverseArea(0,48,50,16);
if(p==-1)
{
	sbqcy++;
}
p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����

	if(p==2)
{
	sbqcy--;
}
	if(sbqcy<1)
		sbqcy=50;
	if(sbqcy>50)
		sbqcy=1;
	
}

if(md==2)
{
	OLED_ReverseArea(60,48,17,16);
	
	
}

if(md==3)
{
	 p = menu_Roll_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  

	OLED_ReverseArea(100,0,18,16);
	if(p==-1)
	{
		sbqdy--;
		if(sbqdy<1)
			sbqdy=1;
	}
	p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����

	if(p==2)
	{
		sbqdy++;
		if(sbqdy>30)
			sbqdy=30;
	}
}
		if(md==4)
{	OLED_ReverseArea(84,48,35,16);

}	

					

							
						
					
				
						for(sbqdx=0;sbqdx<99;sbqdx++)
								{
									if(sbq1[sbqdx]>48)
									{
										sbq1[sbqdx]=48;
									}
									if(sbq1[sbqdx+1]>48)
									{
										sbq1[sbqdx+1]=48;
									}
//							OLED_DrawPoint(sbqdx,48-sbq1[sbqdx]);
									OLED_DrawLine(sbqdx,48-sbq1[sbqdx],sbqdx+1,48-sbq1[sbqdx+1]);
								}
								
																								OLED_Update();


delay_ms(10);

		
	  	
	}
}

///////////////////////////
void dyb(void)
{
	int8_t p;
		dack=0;
dackdh();
	dack=0;

		 LK=0;		

	while(1)
	{
				 lightdh();

		
		static int vat=0;
unsigned int j=0;
			static int iy=0;
						unsigned int yy=0;
			static int start=0;
							static int jt=0;
							static int jt1=0;
		OLED_Clear();
		
			OLED_ShowFloatNum(20,32,(iy/30)*4.10/665,2,2,OLED_8X16);
OLED_ShowString1(70,32,"V",OLED_8X16);
							OLED_ShowString1(0,0," <��ѹ��>",OLED_8X16);
OLED_ShowString1(100,48,"30V",OLED_8X16);
OLED_ShowString1(0,48,"0V",OLED_8X16);
							
if(jt+3<82)
{
OLED_ReverseArea(17,54,jt+3,10);
			
}
else {OLED_ReverseArea(17,82,jt+3,10);
}
if(jt<jt1)
							{
								jt++;
							}
							if(jt>jt1)
							{
								jt--;
							}
							jt1=((iy/30)*4.10/665)*3;
			dh=dhfy;
(*dh)(1);
					




if(start==0)
{
		OLED_ShowString1(0,16,"------START------",OLED_8X16);

	ADC_SoftwareStartConvCmd(ADC1,ENABLE);
	if(vat<30)
			{
			dy[vat]=	ADC_Value[0];
				vat++;
			}
			if(vat>=30)
			{
				iy=0;
				vat=0;
				while(j<30)
				{
					yy=dy[j];
					iy=yy+iy;
					j++;
				}
				
			}
	
	
	
}

if(start==1){
									ADC_SoftwareStartConvCmd(ADC1,DISABLE);
	OLED_ShowString1(0,16,"------STOP------",OLED_8X16);

}

OLED_Update();

		
							
	
							
				
	




		
	   p = menu_Enter_event();   
	   if( p == 1){ 

	start++;
if(start>1)
{
	start=0;
}
	   }	 
     
		
		 if ( p==2 ){
											ADC_SoftwareStartConvCmd(ADC1,DISABLE);

			dackdh();
LK=0;
break;			
			
		}	delay_ms(10);
	}
}














//****************Life_Play************************************************//


extern uint8_t OLED_DisplayBuf[8][128];		//��������

uint8_t Nodes_Cache[8][128];				//���㻺��

void Update_Display(void)					//�ϴ���Ļ
{
	memcpy(OLED_DisplayBuf, Nodes_Cache, 1024);
}

void Point_life(uint8_t X, uint8_t Y)		//д����
{
	Nodes_Cache[(Y/8)][X] |= (0x01 << (Y%8));
}

void Point_death(uint8_t X, uint8_t Y)		//д����
{
	Nodes_Cache[(Y/8)][X] &= ~(0x01 << (Y%8));
}

uint8_t CountPointRound(uint8_t X, uint8_t Y)		//ͳ�Ƶ���Χϸ������
{
	return ( 
	OLED_GetPoint(X-1, Y-1) + 	OLED_GetPoint(X  , Y-1) + 	OLED_GetPoint(X+1, Y-1) + 
	OLED_GetPoint(X-1, Y  ) + 								OLED_GetPoint(X+1, Y  ) + 
	OLED_GetPoint(X-1, Y+1) + 	OLED_GetPoint(X  , Y+1) + 	OLED_GetPoint(X+1, Y+1)
	);
}

void OLED_Rotation_C_P(int8_t CX, int8_t CY, float* PX, float* PY, int16_t Angle)//��ת��
{
	float Theta = (3.14 / 180) * Angle;
	float Xd = *PX - CX;
	float Yd = *PY - CY;
	
	*PX = (Xd) * cos(Theta) - (Yd) * sin(Theta) + CX;// + 0.5;
	*PY = (Xd) * sin(Theta) + (Yd) * cos(Theta) + CY;// + 0.5;
}

void Game_Of_Life_Turn(void)		//ˢ����Ϸ�غ�
{
	uint8_t x, y;
	uint8_t Count;
	
	for(y = 0; y < 64; y ++)
	{
		for(x = 0; x < 128; x ++)
		{
			Count = CountPointRound(x, y);
			if(OLED_GetPoint(x, y))
			{
				if(Count < 2 || Count > 3)
				{
					Point_death(x, y);
				}
			}
			else
			{
				if(Count == 3)
				{
					Point_life(x, y);
				}
			}
		}
	}	
	Update_Display();
}

void Game_Of_Life_Seed(int16_t seed)		//��Ϸ��ʼ������
{
	srand(seed);
	for(uint8_t i = 0; i < 8; i ++)
		for(uint8_t j = 0; j < 128; j ++)
	{
		Nodes_Cache[i][j] = rand();
	}
	Update_Display();
}

void Game_Of_Life_Play(void)		//��Ϸ��ʼ
{
		dack=0;
dackdh();
	dack=0;

		 LK=0;			
	uint8_t x1 = 8, x2 = 16, y1 = 32, y2 = 32;
	int8_t shift = -1;
	
	
	OLED_Clear();
	uint8_t i, j;
	for (j = 0; j < 8; j ++)				//����8ҳ
	{
		for (i = 0; i < 128; i ++)			//����128��
		{
			Nodes_Cache[j][i] = 0x00;	//���Դ���������ȫ������
		}
	}

	
//	Game_Of_Life_Seed(1);		//��������
	
	int8_t p;
	while(1)
	{			 lightdh();

		Game_Of_Life_Turn();
		
		if(shift > 0) {y2 += menu_Roll_event()*8;}
		else {x2 += menu_Roll_event()*8;}
		x2 %= 128;
		y2 %= 64;
		OLED_DrawLine(x1, y1, x2, y2);
		if((x2 - x1) > 1) {x1 += (x2 - x1) / 8 + 1;}
		else if((x2 - x1) < -1) {x1 += (x2 - x1) / 8 - 1;}
		else {x1 = x2;}
		if((y2 - y1) > 1) {y1 += (y2 - y1) / 2 +1;}
		else if((y2 - y1) < -1) {y1 += (y2 - y1) / 2 - 1;}
		else{y1 = y2;}
		
//		OLED_Rotation_C_P(64, 32, &px, &py, Angle);
//		OLED_DrawLine(64, 32, px+0.5, py+0.5);
		
		OLED_Update();

		//Delay_ms(100);
		
		p=menu_Enter_event();
		if(p==1) {shift = -shift;}	
		else if ( p==2 ){

			dackdh();
LK=0;
			break;
		}	
	}
}
//////////////////////////////////////////////



void game2(void)
{
	int8_t p;
		dack=0;
dackdh();
	dack=0;

		 LK=0;				
	while(1)
	{
		
		 lightdh();

		
		
	static int yx_x,yx_y,yx_z;


static int tiao=0;
		static int tj=0;
		static int pt=0;
		static int xh=0;
		static char scor=0;	
							static int hf=0;

							static int bug=0;
							static int scor1=0;
		static int pt1=0;
							static int gameover=0;
			
		
				OLED_Clear();
						
						
							if(gameover==0){
							OLED_ShowImage(127-pt1,0,128,64,game1_tb);
						OLED_ShowImage(-pt1,0,128,64,game1_tb);
								OLED_ShowNum(0,0,scor,3,OLED_8X16);
							OLED_Update();
											 tiao=0;
		 tj=0;
		 pt=0;
 xh=0;
		 scor=0;
		 pt1=0;
								
								
							}
							
							
if(gameover==1)
{	
	//get_angle(&yx_x,&yx_y,&yx_z);

	if(bug==0)
	{
		scor=0;
		bug=1;
	}
			if(pt1>=127)
			{
				pt1=0;
			}

			OLED_ShowImage(127-pt1,0,128,64,game1_tb);
						OLED_ShowImage(-pt1,0,128,64,game1_tb);
if(pt>=462)
			{
		pt=0;
				xh=1;
			}
			if(xh==1)
			{
						OLED_ShowString1(48-pt,48,"A",OLED_8X16);
						OLED_ShowString1(18-pt,48,"A",OLED_8X16);

			}
			if(pt==50)
			{
				xh=0;
			}
				OLED_ShowString1(50,48-tiao,"H",OLED_8X16);
									OLED_ShowString1(50,38-tiao,"O",OLED_8X16);

OLED_ShowString1(127-pt,48,"A",OLED_8X16);
OLED_ShowString1(167-pt,48,"A",OLED_8X16);
OLED_ShowString1(200-pt,48,"A",OLED_8X16);
OLED_ShowString1(230-pt,48,"A",OLED_8X16);
OLED_ShowString1(264-pt,48,"A",OLED_8X16);
OLED_ShowString1(308-pt,48,"A",OLED_8X16);
OLED_ShowString1(341-pt,48,"A",OLED_8X16);
OLED_ShowString1(370-pt,48,"A",OLED_8X16);
OLED_ShowString1(405-pt,48,"A",OLED_8X16);
OLED_ShowString1(446-pt,48,"A",OLED_8X16);

OLED_ShowString1(480-pt,48,"A",OLED_8X16);
OLED_ShowString1(510-pt,48,"A",OLED_8X16);

	OLED_ShowNum(0,0,scor,6,OLED_8X16);


					OLED_Update();
					scor1++;
					if(scor1>50)
					{
						scor1=0;
					scor++;
					}
		
		if(tj==1)
		{
			if(tiao<=31&&hf==0)
			tiao+=4;
			if(tiao>31)
			{
			hf=1;
			}
			if(hf==1)
				tiao-=4;
			if(tiao<=0)
			{
				hf=0;
				tj=0;
			}
			
		}
		

		pt+=2;
	pt1+=2;

		if(((127-pt)>50&&(127-pt)<56)||((167-pt)>50&&(167-pt)<56)||((200-pt)>50&&(200-pt)<56)||((230-pt)>50&&(230-pt)<56)||((264-pt)>50&&(264-pt)<56)||((308-pt)>50&&(308-pt)<56)||((341-pt)>50&&(341-pt)<56)||((370-pt)>50&&(370-pt)<56)||((405-pt)>50&&(405-pt)<56)||((446-pt)>50&&(446-pt)<56)||((480-pt)>50&&(480-pt)<56)||((510-pt)>50&&(510-pt)<56))
		{
			
		
			if(48-tiao>=33)
			{
				for(int die=0;48-tiao+die<96;die++)
				{
														OLED_ShowString1(60,22-tiao+die,"Oh NO!",OLED_8X16);

									OLED_ShowString1(50,48-tiao+die,"H",OLED_8X16);
														OLED_ShowString1(50,38-tiao+die,"O",OLED_8X16);

OLED_Update();
					delay_ms(10);
				}
				

					OLED_ShowString1(20,16,"GAME OVER!!!",OLED_8X16);
								OLED_Update();
			gameover=0;
			}
		}
	}
					
		
						
	OLED_Update();


		
	   p = menu_Roll_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  
	   if( p == 1||yx_x>30){ 

tj=1;
	   }	 
       else if( p == -1){ 
	gameover++;
								if(gameover>1)
							{
								gameover=0;
				
							}

	   }	
		p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����
		if(p==1){
			
		
			
			
		}
		
		else if ( p==2 ){
		 tiao=0;
		 tj=0;
		 pt=0;
 xh=0;
		 scor=0;
		 pt1=0;
						gameover=0;
	bug=0;
hf=0;
			dackdh();
LK=0;
						break;

		}	delay_ms(10);
	}
}








//*********************************************************************//







///////////////

void bmp(void)
{
	int8_t p;
		dack=0;
dackdh();
	dack=0;

		 LK=0;				
	while(1)
	{
		OLED_Clear();
		static int nb=0;
			static float Pl;
			static float T;
					static float P;
 lightdh();

Pl=bmp280_GetAltitude();
		T=bmp280_T();
				P=bmp280_P();

		OLED_ShowFloatNum(0,0,Pl,4,2,OLED_8X16);
		OLED_ShowSignedNum(0,50,T,2,OLED_8X16);
					OLED_ShowSignedNum(0,24,P,6,OLED_8X16);
OLED_ShowString1(67,0,"m",OLED_8X16);
			OLED_ShowString1(59,24,"Pa",OLED_8X16);
OLED_ShowString1(34,50,"C",OLED_8X16);
OLED_ShowString1(26,40,".",OLED_8X16);
OLED_ShowString1(114,50,"m",OLED_8X16);
		OLED_ShowFloatNum(56,50,Pl-nb,4,1,OLED_8X16);


	   p = menu_Enter_event();   
	   if( p == 1){ 
				nb=Pl;


	   }	 
      if( p ==2){ 
			dackdh();
LK=0;
			break;

	   }	 
			OLED_Update();delay_ms(10);
	}
}

//////////
void error(void)
{
	int8_t p;
	
		OLED_Clear();	
		OLED_ShowString1(39, 16, "OH NO!", OLED_6X8);
		OLED_ShowString1(0, 52, "404", OLED_6X8);
		OLED_Update();
	while(1)
	{

		
		
	   p = menu_Roll_event();   
	   if(p){ 
			break;

			
	   }	 
	   p = menu_Enter_event();
	   if(p){			
						break;

	   }delay_ms(10);
	}
}


///////////////////
void timer_INIT()
{
	
	
	/*����ʱ��*/
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);			//����TIM2��ʱ��
	
	/*����ʱ��Դ*/
	TIM_InternalClockConfig(TIM2);		//ѡ��TIM2Ϊ�ڲ�ʱ�ӣ��������ô˺�����TIMĬ��ҲΪ�ڲ�ʱ��
	
	/*ʱ����Ԫ��ʼ��*/
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;				//����ṹ�����
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;		//ʱ�ӷ�Ƶ��ѡ�񲻷�Ƶ���˲������������˲���ʱ�ӣ���Ӱ��ʱ����Ԫ����
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;	//������ģʽ��ѡ�����ϼ���
	TIM_TimeBaseInitStructure.TIM_Period = 100 - 1;				//�������ڣ���ARR��ֵ
	TIM_TimeBaseInitStructure.TIM_Prescaler = 72 - 1;				//Ԥ��Ƶ������PSC��ֵ
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;			//�ظ����������߼���ʱ���Ż��õ�
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);				//���ṹ���������TIM_TimeBaseInit������TIM2��ʱ����Ԫ	
	
	/*�ж��������*/
	TIM_ClearFlag(TIM2, TIM_FLAG_Update);						//�����ʱ�����±�־λ
																//TIM_TimeBaseInit����ĩβ���ֶ������˸����¼�
																//��������˱�־λ�������жϺ󣬻����̽���һ���ж�
																//�������������⣬������˱�־λҲ��
	
	TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);					//����TIM2�ĸ����ж�
	
	/*NVIC�жϷ���*/
//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);				//����NVICΪ����2
	
	/*NVIC����*/
	NVIC_InitTypeDef NVIC_InitStructure;						//����ṹ�����
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;				//ѡ������NVIC��TIM2��
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;				//ָ��NVIC��·ʹ��
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;	//ָ��NVIC��·����ռ���ȼ�Ϊ2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;			//ָ��NVIC��·����Ӧ���ȼ�Ϊ1
	NVIC_Init(&NVIC_InitStructure);								//���ṹ���������NVIC_Init������NVIC����
	
	/*TIMʹ��*/
	TIM_Cmd(TIM2, ENABLE);	

	
}
static int timercount;

void mb(void)
{	dack=0;
dackdh();
	dack=0;

		 LK=0;				
	int8_t p;
	timer_INIT();
	while(1)
	{ lightdh();

		
			   static int jsmd=0;
								static int timer_second=0;
									static int timer_min=0;
									static int timer_hour=0;
									OLED_Clear();
							OLED_ShowString1(5,0,"<���>",OLED_8X16);
								OLED_ShowNum(5,16,timer_hour,2,OLED_8X16);
																	OLED_ShowNum(60,16,timer_second,2,OLED_8X16);
								OLED_ShowNum(30,16,timer_min,2,OLED_8X16);
									OLED_ShowString1(20,16,":",OLED_8X16);
								OLED_ShowNum(90,16,timercount,3,OLED_8X16);

									OLED_ShowString1(50,16,":",OLED_8X16);
									OLED_ShowString1(80,16,":",OLED_8X16);
								  
									
									if(jsmd==0){	OLED_ShowString1(5,32,"-----STOP------",OLED_8X16);
																		TIM_Cmd(TIM2,DISABLE);

									}
if(jsmd==1){
TIM_Cmd(TIM2,ENABLE);
							OLED_ShowString1(0,32,"-----START-----",OLED_8X16);
}
								



if(timercount>10000)
{
	timercount=0;

timer_second++;}
if(timer_second>59)
{
	timer_second=0;
	timer_min++;
}
if(timer_min>59)
{
	timer_min=0;
	timer_hour++;
}
if(timer_hour>99)
{
	timer_hour=0;
}

	   p = menu_Roll_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  
	   if( p == 1){ 
jsmd++;
	if(jsmd>1)
									jsmd=0;
	   }	 
       else if( p == -1){ 

	
	   }	
		p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����
		if(p==1){
			
			timer_min=0;
	timer_second=0;
	timer_hour=0;
	timercount=0;
				
			//����ĳĳ����//
			
			
		}
		else if ( p==2 ){
			TIM_Cmd(TIM2,DISABLE);

	jsmd=0;
				dackdh();
LK=0;
					break;

			
		}		   OLED_Update();delay_ms(10);

	}
}
/////////////////////////

void set_time(void)
{
	int8_t p;
	OLED_Clear();	dack=0;
dackdh();
	dack=0;

		 LK=0;			
	while(1)
	{
		
		      	 lightdh();

			
	static char timeSZ=0;
OLED_Clear();
							OLED_ShowNum(118,32,week,1,OLED_8X16);

		OLED_ShowNum(0,32,year,4,OLED_8X16);
					OLED_ShowNum(44,32,month,2,OLED_8X16);
		OLED_ShowNum(81,32,day,2,OLED_8X16);
		OLED_ShowNum(0,48,hour,2,OLED_8X16);
		OLED_ShowNum(30,48,minute,2,OLED_8X16);
		OLED_ShowNum(60,48,second,2,OLED_8X16);
		OLED_ShowString1(20,48,":",OLED_8X16);
		OLED_ShowString1(50,48,":",OLED_8X16);
	time_appear();
							p=menu_Roll_event(); //��ȡ������ȷ��������1ȷ����2����

					if(p==1)
								timeSZ++;
							if(timeSZ>6)
								timeSZ=0;
						switch(timeSZ)
							{
							case 0:	OLED_ReverseArea(60,48,16,16);
							if(p==-1)
							{
								second++;
								
																MyRTC_Time[5]=second;
																if(second>59)
																									 MyRTC_Time[4]=minute-1;


	MyRTC_SetTime();

							}
							;break;
   case 1:OLED_ReverseArea(30,48,16,16);
							if(p==-1)
							{
								minute++;   
								
								 MyRTC_Time[4]=minute;
								if(minute>59)
								 MyRTC_Time[3]=hour-1;

MyRTC_SetTime();
							}
							;break;
							case 2:OLED_ReverseArea(0,48,16,16);
							if(p==-1)
							{
								hour++;
								
								MyRTC_Time[3]=hour;
								if(hour>23)
								 MyRTC_Time[2]=day-1;

MyRTC_SetTime();
							}
							;break;
							case 4:OLED_ReverseArea(81,32,16,16);
							if(p==-1)
							{
								day++;    
								
									MyRTC_Time[2]=day;
	

MyRTC_SetTime();
							}
							;break;
							case 3:OLED_ReverseArea(118,32,8,16);
							if(p==-1)
							{
								week++;   MyRTC_Time[6]=week;
MyRTC_SetTime();
								
							}
							;break;
							case 5:OLED_ReverseArea(44,32,16,16);
							if(p==-1)
							{
								month++;    
								
									MyRTC_Time[1]=month;
								if(month>12)
									MyRTC_Time[0]=year-1;

MyRTC_SetTime();
							}
							;break;
							case 6:OLED_ReverseArea(0,32,32,16);
							if(p==-1)
							{
								year++;   
								
								
									MyRTC_Time[0]=year;
MyRTC_SetTime();
							}
							;break;
							
							default:	;break;
						
						}
		
				
		
				




		p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����
	   if( p == 1){ 
	timeSZ++;
							if(timeSZ>6)
								timeSZ=0;

	   }	 
      
	
		 if ( p==2 ){
		dackdh();
LK=0;
						break;

			
		}	
		OLED_Update();delay_ms(15);
	}
}



//////////////////////////
void djs(void)
{  
	int8_t p;
		timer_INIT();
	dack=0;
dackdh();
	dack=0;

		 LK=0;				
	while(1)
	{
 lightdh();

			
									static int jsmd=0;
								static int timer_second=0;
									static int timer_min=0;
									static int timer_hour=0;
									static int szmd=0;
									OLED_Clear();
							OLED_ShowString1(5,0,"<����ʱ��>",OLED_8X16);
								OLED_ShowNum(5,16,timer_hour,2,OLED_8X16);
																	OLED_ShowNum(60,16,timer_second,2,OLED_8X16);
								OLED_ShowNum(30,16,timer_min,2,OLED_8X16);
									OLED_ShowString1(20,16,":",OLED_8X16);
									OLED_ShowString1(5,48,"SET",OLED_8X16);
									OLED_ShowString1(90,48,"BACK",OLED_8X16);

									OLED_ShowString1(50,16,":",OLED_8X16);
								  
									
									
									
										
										
										
									
									
									
									if(szmd==2){
																																	OLED_ReverseArea(90,48,32,16);
									}

	


if(timercount>10000)
{
	timercount=0;

timer_second--;}
if(timer_second<0)
{
if(timer_min>0)
{
	timer_second=59;
}
else
{
	timer_second=0;
}
	timer_min--;
}
if(timer_min<0)
{
	if(timer_hour>0)
	{
	timer_min=59;}
	else{
	timer_min=0;}
	timer_hour--;
}
if(timer_hour<0)
{
	timer_hour=0;
}
		
		
	




					   p = menu_Enter_event(); 

	   if( p == 1){ 
szmd++;
									if(szmd>2)
									szmd=0;

	   }	
	   p = menu_Roll_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  

		 if(szmd==0){	
        if( p == 1){ 

jsmd++;

			if(jsmd>1)
												jsmd=0;
	   }	
		 
		 
		
			
			
		
		
		if(jsmd==0)
										{
										OLED_ShowString1(5,33,"-----STOP------",OLED_8X16);
										OLED_ReverseArea(5,33,128,16);
											TIM_Cmd(TIM2,DISABLE);
										}
										
										if(jsmd==1){
											TIM_Cmd(TIM2,ENABLE);
																		OLED_ShowString1(0,33,"-----START-----",OLED_8X16);

																					OLED_ReverseArea(5,33,128,16);

											
																					if(timer_min==0&&timer_hour==0&&timer_second==0)
																					{
																						
																					OLED_Reverse();
																						
																					}

}
		
		}
		
		if(szmd==1)
									{
										
										static int set_timer_gb=0;
																		OLED_ShowString1(5,48,"SET",OLED_8X16);
															OLED_ReverseArea(5,48,24,16);

if(p==1)
{
	set_timer_gb++;
	if(set_timer_gb>3)
		set_timer_gb=0;
}
	if(set_timer_gb==0)
	{	   
		if(p==-1)
		{
			timer_second++;
			if(timer_second>59)
				timer_second=0;
		}
																							OLED_ReverseArea(60,16,16,16);

	}
	if(set_timer_gb==1)
	{
		if(p==-1)
		{
			timer_min++;
			if(timer_min>59)
				timer_min=0;
		}
																							OLED_ReverseArea(30,16,16,16);

		
	}
	if(set_timer_gb==2)
	{
		if(p==-1)
		{
			timer_hour++;
			if(timer_hour>59)
				timer_hour=0;
		}
																							OLED_ReverseArea(5,16,16,16);

	}

									}
		
		
		
		
			   p = menu_Enter_event(); 
		if ( p==2 ){
			TIM_Cmd(TIM2,DISABLE);
	jsmd=0;
								 timer_second=0;
							 timer_min=0;
								timer_hour=0;
		szmd=0;
		dackdh();
LK=0;
						break;

		}
		OLED_Update();delay_ms(10);
	}
}
/////////////////////////


//////////////////////////
void TIM2_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM2, TIM_IT_Update) == SET)
	{
		
					timercount++;
if(sbqtimer==0)
		{
			static int cyl=1;
			cyl++;

			if(cyl>sbqcy)
			{
			sbqd++;
			cyl=0;

			sbq1[sbqd]=(ADC_Value[0]*4.10/665)*48/sbqdy;
					
						if(sbqd>99)
						{
							sbqd=0;
								
					}
						
					}
		}
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
	}
}
/////////////////////////////


void sdt(void)
{
	int8_t p;
//		dack=0;
//dackdh();
//	dack=0;

//		 LK=0;			
	while(1)
	{	
		
		lightdh();

OLED_Clear();

	OLED_Reverse();

		OLED_Update();


		
	   p = menu_Roll_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  
	   if( p == 1){ 


	   }	 
       else if( p == -1){ 


	   }	
		p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����
		 if ( p==2 ){
		
			dackdh();
LK=0;
		
						break;

		}	delay_ms(10);
	}
}
/////////////////////

void xtdy(void)
{
	int8_t p;
		dack=0;
dackdh();
	dack=0;

		 LK=0;				
	while(1)
	{ lightdh();

		OLED_Clear();

		static int vat=0;
unsigned int j=0;
			static int iy=0;
						unsigned int yy=0;
			static int start=0;
							static int jt=0;
							static int jt1=0;

OLED_ShowFloatNum(20,32,(iy/30)*4.10/665,2,2,OLED_8X16);
OLED_ShowString1(70,30,"V",OLED_8X16);ADC_SoftwareStartConvCmd(ADC1,ENABLE);
				OLED_Update();

	if(vat<30)
			{
			dy[vat]=	ADC_Value[2];
				vat++;
			}
			if(vat>=30)
			{
				iy=0;
				vat=0;
				while(j<30)
				{
					yy=dy[j];
					iy=yy+iy;
					j++;
				}
				
			}
	


		
	   p = menu_Enter_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  
	  
        if( p == 2){ 
		ADC_SoftwareStartConvCmd(ADC1,DISABLE);	dackdh();
LK=0;
						break;

			

	   }	delay_ms(10);
		
	}
}/////////////////////////

////////////////
int gb_tb=0;
void gbys(void)
{
	int8_t p;
		dack=0;
dackdh();
	dack=0;

		 LK=0;				
	
	while(1)
	{
		
		
		
	
 lightdh();

OLED_Clear();
		


		
	   p = menu_Roll_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  
	   if( p == 1){ 
gb_tb++;

	   }	 
       else if( p == -1){ 

gb_tb--;
	   }	
			if(gb_tb>2)
gb_tb=2;
			if(gb_tb<1)
gb_tb=0;
		 switch(gb_tb)
		 {
			 case 0:OLED_ShowString1(0,0,"<-",OLED_8X16);break;
			  case 1:OLED_ShowString1(0,0,"<--",OLED_8X16);break;
			 case 2:OLED_ReverseArea(0,0,20,16);break;
			 default:;break;
		 }
		p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����
		if(p==1){
			
			
		}
		else if ( p==2 ){
//		AT24CXX_Write(0x01,&gb_tb,1);
			dackdh();
LK=0;
			
			break;
			
		}	
		OLED_Update();delay_ms(10);
	}
}

//////////////////

uint8_t fx_set=0;

void pmfx(void)
{
	int8_t p;
		dack=0;
dackdh();
	dack=0;

		 LK=0;				
	
	while(1)
	{
		
 lightdh();
OLED_Clear();
		OLED_ShowString1(10,30,"<��Ļ��������>",OLED_8X16);
	   p = menu_Roll_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  
	   if( p == 1){ 
fx_set=0;

	   }	 
       else if( p == -1){ 

fx_set=1;
	   }	
			 
			 if(fx_set==1)
			 OLED_Reverse();
			
		p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����
	
		 
		 if ( p==2 ){
		
			dackdh();
LK=0;
				AT24CXX_Write(0x02,&fx_set,1);

			break;
			
		}	
		 OLED_Update();delay_ms(10);
	}
}
/////////
int sy_set=1;

void music_set(void)
{
	int8_t p;
		dack=0;
dackdh();
	dack=0;

		 LK=0;				
	
	while(1)
	{
		
 lightdh();
OLED_Clear();
		OLED_ShowString1(10,0,"<��������>",OLED_8X16);
	   p = menu_Roll_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  
	   if( p == 1){ 
sy_set=0;

	   }	 
       else if( p == -1){ 

sy_set=1;
	   }	
			 
			 if(sy_set==1)
					OLED_ShowString1(10,40,"������",OLED_8X16);

					 if(sy_set==0)
					OLED_ShowString1(10,40,"������",OLED_8X16);

		p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����
	
		 
		 if ( p==2 ){
		
			dackdh();
LK=0;
				AT24CXX_Write(0x02,&fx_set,1);

			break;
			
		}	
		 OLED_Update();
	}
}

/// @brief ///////////////////////////
/// @param  
void djsz(void)
{
	int8_t p;
		dack=0;
dackdh();
	dack=0;

		 LK=0;				
	
	while(1)
	{
		
 lightdh();
OLED_Clear();
		OLED_ShowString1(0,0,"<Ϩ������>",OLED_8X16);
		OLED_ShowString1(0,17,"Ϩ������:",OLED_8X16);
		OLED_ShowString1(0,40,"Ϩ��ʱ��:",OLED_8X16);
OLED_ShowNum(70,40,xptime,3,OLED_8X16);
	   p = menu_Roll_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  
		
	   if( p == 1){ 
dj++;

	   }	 
		 if(dj>1)
			 dj=0;
       else if( p == -1){ 

xptime++;
	   }	
			 if(xptime>500)
			 xptime=100;
			 
			  switch(dj)
		 {
			 case 0:OLED_ShowString1(70,17,"��",OLED_8X16);break;
			  case 1:OLED_ShowString1(70,17,"��",OLED_8X16);break;
			 default:;break;
		 }
		  
		 
			 if(fx_set==1)
			 OLED_Reverse();
			
		p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����
	
		 
		 if ( p==2 ){
		
			dackdh();
LK=0;
						AT24CXX_Write(0x03,&dj,1);
				AT24CXX_Write(0x04,&xptime,3);

			break;
			
		}	
		 OLED_Update();delay_ms(10);
	}
}




////////////////
void kj()
{
	
	
	for(int kj=0;kj<30;kj++)
	{
		OLED_Clear();
		OLED_DrawPoint(64,kj);
		OLED_Update();
		
	}
		delay_ms(100);

	for(int kj=0;kj<15;kj++)
	{
		OLED_Clear();
OLED_DrawLine(64,30,64+kj,30);
		OLED_DrawLine(64,30,64-kj,30);
		OLED_Update();
		delay_ms(10);
	}
		delay_ms(100);

for(int kj=0;kj<16;kj++)
	{
		OLED_Clear();
OLED_DrawLine(49+kj,30-kj,79-kj,30+kj);
		OLED_Update();
		delay_ms(10);
	}
	delay_ms(200);
	for(int kj=0;kj<60;kj++)
	{
		OLED_ShowString1(-48+kj,20,"Puping-Watch",OLED_8X16);
				OLED_ShowString1(-48+kj,36,"V1.0",OLED_6X8);

		OLED_ClearArea(0,0,66-kj,64);
		OLED_DrawLine(64-kj,14,64-kj,46);

		OLED_Update();delay_ms(10);
		
	}
	delay_ms(500);
	dack=0;
dackdh();
	dack=0;

		 LK=0;
}
void message()
{
	int8_t p;
		dack=0;
dackdh();
	dack=0;

		 LK=0;				
	
	while(1)
	{
		
		
		
	
 lightdh();
		OLED_Clear();
		OLED_ShowString1(0,0,"����:ССMySc",OLED_8X16);
OLED_ShowString1(0,16,"stm32f103c8t6",OLED_8X16);
OLED_ShowString1(0,32,"200mah",OLED_8X16);
OLED_ShowString1(0,48,"",OLED_8X16);
OLED_Update();


		
	   p = menu_Roll_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  
	   if( p == 1){ 


	   }	 
       else if( p == -1){ 


	   }	
		p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����
		if(p==1){
			
			
		}
		else if ( p==2 ){
		
			dackdh();
LK=0;
		
			break;
			
		}	
	}
	
}








///////////////////////////

void adxl(void)
{
	int8_t p;
		dack=0;
dackdh();
	dack=0;

		 LK=0;				
	float x_angle,y_angle,z_angle;
	short temperature = 0; 				//�¶�ֵ

	while(1)
	{ 
		lightdh();

		OLED_Clear();
		
	get_angle(&x_angle,&y_angle,&z_angle);
		OLED_ShowSignedNum(0,0,x_angle,3,OLED_8X16);
					OLED_ShowSignedNum(0,16,y_angle,3,OLED_8X16);
		OLED_ShowNum(0,32,z_angle,3,OLED_8X16);
OLED_DrawLine(50,0,50,64);
		OLED_DrawPoint(85-y_angle,32-x_angle);

		OLED_Update();
		
			delay_ms(50);



		
	   p = menu_Roll_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  
	   if( p == 1){ 


	   }	 
       else if( p == -1){ 


	   }	
		p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����
		if(p==1){
			
			
		}
		else if ( p==2 ){
		
			dackdh();
LK=0;
		
			break;
			
		}	delay_ms(10);
	}
}
int taiwan=0;

void twlp()
{

int8_t p;
		dack=0;
dackdh();
	dack=0;

		 LK=0;				
	
	while(1)
	{
		
 lightdh();
OLED_Clear();
		OLED_ShowString1(0,0,"<̧������>",OLED_8X16);
				OLED_ShowString1(48,0,"��ر�Ϩ��!!",OLED_8X16);

		if(taiwan==0)
	    	{
					OLED_ShowString1(0,25,"̧�������ر�",OLED_8X16);

		}
else
						OLED_ShowString1(0,25,"̧����������",OLED_8X16);



		
	   p = menu_Roll_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  
	   if( p == 1){ 
taiwan=1;

	   }	 
       else if( p == -1){ 

taiwan=0;
	   }	
		p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����
		if(p==1){
			
			
		}
		else if ( p==2 ){
		
			dackdh();
LK=0;
		
			break;
			
		}	
		OLED_Update();delay_ms(10);
	}
}


void dycl(void)
{

//OLED_ShowFloatNum(31,0,ADC_Value[2]*4.10/665,2,2,OLED_6X8);
//OLED_ShowString1(69,0,"V",OLED_6X8);
	OLED_DrawRectangle(0,0,25,8,OLED_UNFILLED);
	OLED_DrawRectangle(1,1,(ADC_Value[2]*4.10/665-2.5)/0.066,6,OLED_FILLED);
		OLED_DrawRectangle(25,2,3,4,OLED_FILLED);
OLED_ShowFloatNum(30,0,(((ADC_Value[2]*4.10/665-2.5)/0.066)/25)*100,2,1,OLED_6X8);
OLED_ShowChar(60,0,'%',OLED_6X8);
	ADC_SoftwareStartConvCmd(ADC1,ENABLE);

	


		
	}






const unsigned char BMP_people [] ={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x80,0x00,0x00,0x00,0x00,0x00,0x80,0x00,0x00,0x00,0x00,0x80,0xC0,0xE0,0xF0,0xF0,0xF8,0xFC,0xFC,0xFE,0xFE,0xFE,0xFE,0xFE,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFE,0xFE,0xFE,0xFE,0xFC,0xF8,0xF0,0xC0,0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x04,0x00,0x00,0x03,0x00,0x00,0x00,0x00,0x02,0x01,0x00,0xE0,0xF0,0xFC,0xFE,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFE,0xFC,0xF0,0x80,0x00,0x00,0x00,0x00,0x00,0x1C,0x1C,0x1C,0x1C,0x1C,0x1C,0x0C,0x0C,0x1C,0xFC,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFC,0x0C,0x0C,0x0C,0x0C,0xFF,0xFF,0xFF,0xFF,0x7F,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x3F,0x3F,0x3F,0x3F,0x3F,0x7F,0x7F,0x7F,0x7F,0xFF,0xFF,0x7F,0x3F,0x1F,0x3F,0x3F,0x7F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x3F,0x1F,0x1F,0x3F,0x3F,0xFF,0xFF,0xFF,0xFF,0x9F,0x8F,0x83,0x83,0x83,0x83,0x83,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xF8,0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x40,0xC4,0xE1,0xC0,0xC0,0xC0,0xC0,0x40,0x40,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xC0,0xF0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x7F,0x7F,0x7F,0x7F,0x7F,0x7F,0x7F,0x7F,0x7F,0x7F,0xFF,0xFF,0x7F,0x7F,0x3F,0x5F,0x1F,0x3F,0x1C,0x00,0x00,0x30,0x78,0xF8,0xF8,0xF9,0xFC,0xF8,0xF9,0xF8,0xF8,0x38,0x38,0x18,0x18,0x18,0x00,0x00,0x00,0x00,0x00,0x0E,0x0F,0x1F,0x1F,0x0F,0x0F,0x0F,0x0F,0x2F,0x8F,0xAF,0xAF,0xAF,0xAF,0xDF,0xE2,0x7C,0x1C,0x0E,0x07,0x03,0x03,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x07,0x3F,0x7E,0xFC,0xF8,0xF0,0xF0,0xF0,0xE0,0xE0,0xE0,0xE0,0xF0,0x40,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x01,0x01,0x03,0x02,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x01,0x01,0x03,0x03,0x07,0x07,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

const unsigned char* bmp_tp[]={
	
BMP_people
};





void Show_BMP(void)
{
	int8_t p;
		dack=0;
dackdh();
	dack=0;

		 LK=0;				
	
	while(1)
	{
	
	
 lightdh();

static int key,tp_state=0;
key=menu_Roll_event();
if(key==1)
tp_state++;
if(key==-1)
   tp_state--;
if(tp_state>0)
tp_state=0;
if(tp_state<0)
tp_state=0;


    OLED_Clear();

    OLED_ShowImage(33, 0, 55, 73, BMP_people);
OLED_Update();


		
	   p = menu_Roll_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  
	   if( p == 1){ 


}	 
       else if( p == -1){ 


	   }	
p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����
		if(p==1){
			
			
		}
		else if ( p==2 ){
		
			dackdh();
LK=0;
		
			break;delay_ms(10);
			
		}	
	}
}







void whwhSK(uint8_t w)
{	
	OLED_Clear();
	OLED_Reverse();
		if(w)
		{for(u8 i=128;i>108;i--)
			{	OLED_UpdateArea(i,0,1,64);
				delay_ms(10);
			}
			for(u8 i=108;i>98;i--)
			{	OLED_UpdateArea(i,0,1,64);
				delay_ms(7);
			}
			for(u8 i=98;i>0;i--)
			{	OLED_UpdateArea(i,0,1,64);
				delay_ms(1);
			}
			OLED_Clear();
			OLED_ShowImage(41, 0, 45, 45, SKM_ZFB );
			OLED_ShowString1(34, 48, "֧�����տ�", OLED_8X16);
			for(u8 i=128;i>28;i--)
			{	OLED_UpdateArea(i,0,1,64);
				delay_ms(1);
			}
			for(u8 i=28;i>8;i--)
			{	OLED_UpdateArea(i,0,1,64);
				delay_ms(7);
			}
			for(u8 i=8;i>0;i--)
			{	OLED_UpdateArea(i,0,1,64);
				delay_ms(10);
			}
		}
		else
		{
			for(u8 i=0;i<20;i++)
			{	OLED_UpdateArea(i,0,1,64);
				delay_ms(10);
			}
			for(u8 i=20;i<30;i++)
			{	OLED_UpdateArea(i,0,1,64);
				delay_ms(7);
			}
			for(u8 i=30;i<128;i++)
			{	OLED_UpdateArea(i,0,1,64);
				delay_ms(1);
			}
			OLED_Clear();
			OLED_ShowImage(41, 0, 45, 45, SKM_WX );
			OLED_ShowString1(40, 48, "΢���տ�", OLED_8X16);
			for(u8 i=0;i<100;i++)
			{	OLED_UpdateArea(i,0,1,64);
				delay_ms(1);
			}
			for(u8 i=100;i<120;i++)
			{	OLED_UpdateArea(i,0,1,64);
				delay_ms(7);
			}
			for(u8 i=120;i<128;i++)
			{	OLED_UpdateArea(i,0,1,64);
				delay_ms(10);
			}
		}
		
}


void WeChat_SK(void)
{
	int8_t p;
	uint8_t w=0;	
		dack=0;
dackdh();
	dack=0;

		 LK=0;	

	whwhSK(w);	
	
	while(1)
	{
		 lightdh();
	   OLED_Update();
		
	   p = menu_Roll_event();   
	   if( p == 1){ 
		  w = !w ;
			whwhSK(w);	
	   }	 
       else if( p == -1){ 
		  w = !w ;
			whwhSK(w);	
	   }	
		p=menu_Enter_event();
		if(p==1){
			
			dackdh();
LK=0;
			return;
			
		}
		else if ( p==2 ){
		
			dackdh();
LK=0;
			return;
			
		}	
	}

}

void ZFB_SK(void)
{	
	int8_t p;
	uint8_t w=1;
	
		dack=0;
dackdh();
	dack=0;

		 LK=0;	


	whwhSK(w);	
	
	while(1)
	{
				 lightdh();

	   OLED_Update();
		
	   p = menu_Roll_event();   
	   if( p == 1){ 
		  w = !w ;
			whwhSK(w);	
	   }	 
       else if( p == -1){ 
		  w = !w ;
			whwhSK(w);	
	   }	
		p=menu_Enter_event();
		if(p==1){
			
			dackdh();
LK=0;
			return;
			
		}
		else if ( p==2 ){
		
			dackdh();
LK=0;
		
			return;
			
		}	
	}

}






//����ģ��

//void xxxxxxx(void)
//{
//	int8_t p;
//		dack=0;
//dackdh();
//	dack=0;

//		 LK=0;				
//	
//	while(1)
//	{
//		
//		
//		
//	
// lightdh();




//		
//	   p = menu_Roll_event(); //��ȡ���������£�����1Ϊ�£�-1Ϊ��  
//	   if( p == 1){ 


//	   }	 
//       else if( p == -1){ 


//	   }	
//		p=menu_Enter_event(); //��ȡ������ȷ��������1ȷ����2����
//		if(p==1){
//			
//			
//		}
//		else if ( p==2 ){
//		
//			dackdh();
//LK=0;
//		
//			break;delay_ms(10);
//			
//		}	
//	}
//}





