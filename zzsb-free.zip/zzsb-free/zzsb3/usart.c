
#include<usart.h>
#include<stm32f10x.h>
unsigned int a=0;
u8 RxBuffer[3];
vu8 RxCount=0;
vu8 RxHeader=0;
vu8 RxOK=0;
vu8 RxLen=0;
void  gpio_init_1()
{GPIO_InitTypeDef GPIO_InitStructure;
RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);


GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;
GPIO_InitStructure.GPIO_Pin=GPIO_Pin_9;
GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
GPIO_Init(GPIOA,&GPIO_InitStructure);

GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING;
GPIO_InitStructure.GPIO_Pin=GPIO_Pin_10;
GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
GPIO_Init(GPIOA,&GPIO_InitStructure);
}

void ck_init_1()
{
USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	
USART_InitStructure.USART_BaudRate=9600;
USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
USART_InitStructure.USART_Mode=USART_Mode_Tx|USART_Mode_Rx;

	
USART_InitStructure.USART_Parity=USART_Parity_No;
USART_InitStructure.USART_StopBits=USART_StopBits_1;
USART_InitStructure.USART_WordLength=USART_WordLength_8b;
 USART_Init(USART1,&USART_InitStructure);
USART_ITConfig(USART1,USART_IT_RXNE, ENABLE);	
	 USART_Cmd(USART1,ENABLE);
 USART_ClearFlag(USART1, USART_IT_RXNE); 			//���жϣ�����һ�����жϺ����������ж�
USART_GetFlagStatus(USART1,USART_FLAG_TC);


	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
	NVIC_InitStructure.NVIC_IRQChannel=USART1_IRQn;

NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=1;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
}
void  gpio_init_2()
{GPIO_InitTypeDef GPIO_InitStructure;
RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);


GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;
GPIO_InitStructure.GPIO_Pin=GPIO_Pin_2;
GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
GPIO_Init(GPIOA,&GPIO_InitStructure);

GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING;
GPIO_InitStructure.GPIO_Pin=GPIO_Pin_3;
GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
GPIO_Init(GPIOA,&GPIO_InitStructure);
}

void ck_init_2()
{
USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
	
USART_InitStructure.USART_BaudRate=9600;
USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
USART_InitStructure.USART_Mode=USART_Mode_Tx|USART_Mode_Rx;

	
USART_InitStructure.USART_Parity=USART_Parity_No;
USART_InitStructure.USART_StopBits=USART_StopBits_1;
USART_InitStructure.USART_WordLength=USART_WordLength_8b;
 USART_Init(USART2,&USART_InitStructure);
USART_ITConfig(USART2,USART_IT_RXNE, ENABLE);	
	 USART_Cmd(USART2,ENABLE);
 	USART_ClearFlag(USART2, USART_IT_RXNE); 			//���жϣ�����һ�����жϺ����������ж�
USART_GetFlagStatus(USART1,USART_FLAG_TC);



	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
	NVIC_InitStructure.NVIC_IRQChannel=USART2_IRQn;

NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=1;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);

}
void  gpio_init_3()
{GPIO_InitTypeDef GPIO_InitStructure;
RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);


GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;
GPIO_InitStructure.GPIO_Pin=GPIO_Pin_10;
GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
GPIO_Init(GPIOB,&GPIO_InitStructure);

GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING;
GPIO_InitStructure.GPIO_Pin=GPIO_Pin_11;
GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
GPIO_Init(GPIOB,&GPIO_InitStructure);
}
//c8t6have
void ck_init_3()
{
USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE);
	
USART_InitStructure.USART_BaudRate=9600;
USART_InitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
USART_InitStructure.USART_Mode=USART_Mode_Tx|USART_Mode_Rx;

	
USART_InitStructure.USART_Parity=USART_Parity_No;
USART_InitStructure.USART_StopBits=USART_StopBits_1;
USART_InitStructure.USART_WordLength=USART_WordLength_8b;
 USART_Init(USART3,&USART_InitStructure);
 
USART_ITConfig(USART3,USART_IT_RXNE, ENABLE);	
	 USART_Cmd(USART3,ENABLE);
USART_ClearFlag(USART3, USART_IT_RXNE); 			//���жϣ�����һ�����жϺ����������ж�
USART_GetFlagStatus(USART1,USART_FLAG_TC);

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
//	NVIC_InitStructure.NVIC_IRQChannel=USART3_IRQn;

NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=1;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	

}
//void EMPTYRxBuffer(u8 len)
//{
//	u8 i;
//	for(i=0;i<len;i++)
//	RxBuffer[i]=0;
//}
//void USART1_IRQHandler()
//{
//if(	USART_GetITStatus(USART1,USART_IT_RXNE)!=RESET)
//{
//	USART_ClearITPendingBit(USART1,USART_IT_RXNE);
//	RxBuffer[RxCount]=USART_ReceiveData(USART1);
//	RxCount++;
//	RxCount&=0xFF;
//}
//if(RxBuffer[RxCount-1]==0xEA)
//	RxHeader=RxCount-1;
//if((RxBuffer[RxHeader]==0xEA)&&(RxBuffer[RxCount-1]==0x55))
//{
//	RxLen=RxCount-1-RxHeader;
//	RxOK=1;
//}
//if(USART_GetFlagStatus(USART1,USART_FLAG_ORE)==SET)
//{
//	USART_ClearFlag(USART1,USART_FLAG_ORE);
//	USART_ReceiveData(USART1);
//}
//}

void put(int *str)
{
while(*str)
{
USART_SendData(USART1,*str++);
while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
}
}
void put1(int hex)
{

USART_SendData(USART1,hex);
while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);

}
void put1_2(int hex)
{

USART_SendData(USART2,hex);
while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);

}
void put3(int hex)
{

USART_SendData(USART1,hex);
while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);

}


 void USART1_IRQHandler()
{
	

	if(USART_GetITStatus(USART1,USART_IT_RXNE) ==SET)
	{
		unsigned int RxData =USART_ReceiveData(USART1);
		
			if(RxData == 'A')
			{
				
				a=1;
			
		}

USART_ClearITPendingBit(USART1,USART_IT_RXNE);
	}
}
 void USART2_IRQHandler()
{
	static int cot=-1;

	if(USART_GetITStatus(USART2,USART_IT_RXNE) ==SET)
	{
		
		unsigned int RxData =USART_ReceiveData(USART2);
		cot++;

		if(cot==0)
		RxBuffer[0]=RxData;
if(cot==1)
			RxBuffer[1]=RxData;
if(cot==2)
{
	cot=-1;
			RxBuffer[2]=RxData;
}

USART_ClearITPendingBit(USART2,USART_IT_RXNE);
	}
}
void USART3_IRQHandler()
{
	

	if(USART_GetITStatus(USART3,USART_IT_RXNE) ==SET)
	{
		unsigned int RxData =USART_ReceiveData(USART3);
		
			
USART_ClearITPendingBit(USART3,USART_IT_RXNE);
	}
}

	
	