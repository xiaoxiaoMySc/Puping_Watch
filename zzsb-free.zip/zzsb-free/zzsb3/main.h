#include<stm32f10x.h>
extern uint16_t second, minute, hour, week, day, month, year;
extern void time_appear();
extern	float (*dh)(int mode);
extern float (*dh1)(int mode);
extern	float dhfy(int mode);
	extern		     int sysj;
extern  int xptime;
extern int dj;
void timer_apper2();
void zfdh();
