#ifndef _KEY_H
#define _KEY_H
#include<stm32f10x.h>

#define key1 GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)
#define key2 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)
#define key3 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)

#define keyunps 0
#define key1ps 1
#define key2ps 2
#define key3ps 3

int key_scan(unsigned int MODE);

void Key_Init(void);

void key_int();
#endif