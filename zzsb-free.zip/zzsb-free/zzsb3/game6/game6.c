#include "stm32f10x.h"
#include<math.h>
#include<stdio.h>
#include<Delay.h>
#include<OLED.h>
#include<OLED_Data.h>
#include<stdlib.h>
#include<KEY.h>
#include<menu.h>
#include<game6.h>
#include "timerclock.h"
//oledÇý¶¯´úÂëÀ´×Ô½­Ð­¿Æ¼¼
//oled½Ób6b7b8b9£¨b7Îª¸ßµçÆ½£©
//Ò»¸öÁ½ÖáÒ¡¸Ë£¬x½Óa0£¬y½Óa1£¬z½Óa2
//´ËÎå×ÓÆåÐ¡ÓÎÏ·ÊÇÁ·Ï°ÓÃµÄ£¬Ã»ÓÐ¿¼ÂÇÌ«¶à£¬ÈçÓÐbugÇëÎð¹Ö£¡
int x_game6,y_game6,xx_game6,yy_game6,xxx_game6,yyy_game6,xi_game6,yi_game6;
u8 key_game6, keyvalue_game6;
u8 qaq,get;
u8 map_game6[8][9];
u8 p1get=0,p2get=0,p2set,p1set;
u8 win_game6;
int xnadc_count_x_6=20000,xnadc_count_y_6=20000;
int KEY_game6;
void mapini()
{
	u8 a,b;
	for (a=0;a<8;a++)
	for (b=0;b<9;b++)
	{
		map_game6[a][b]=3;
	}
}
static int state_game6=0;

void getad_game6()  //Ò¡¸ËºÍ°´¼ü////////////////////////////////////////////////////////////////////////////////////
{
   

KEY_game6=key_scan(0);
if(KEY_game6==key1ps)
{
state_game6++;
}
if(state_game6>3)
state_game6=0;
if(state_game6==0)
{
if(KEY_game6==key3ps)
xnadc_count_x_6+=300;
if(KEY_game6==key2ps)
xnadc_count_x_6-=300;
}
if(state_game6==1)
{
if(KEY_game6==key3ps)
xnadc_count_y_6+=300;
if(KEY_game6==key2ps)
xnadc_count_y_6-=300;
}

	if (xnadc_count_x_6>=xi_game6+100||xnadc_count_x_6<=xi_game6-100||xnadc_count_y_6>=xi_game6+100||xnadc_count_y_6<=xi_game6-100)
		{
      x_game6=xnadc_count_x_6;
		  y_game6=xnadc_count_y_6;
			xxx_game6=x_game6/100-xi_game6/100;
			yyy_game6=y_game6/100-xi_game6/100;
			if (xx_game6+xxx_game6/4>0&&xx_game6+xxx_game6/4<128)	xx_game6=xx_game6+xxx_game6/4;
			if (yy_game6+yyy_game6/4>0&&yy_game6+yyy_game6/4<64) yy_game6=yy_game6+yyy_game6/4;
		}
if (key_game6>1)
		{
			if(state_game6==2)
			{
		if (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)==0)
					{
							 keyvalue_game6=1;
							key_game6=0;
					}
				}
		}

			
}
void pageini()
{
	u8 p;
	for (p=0;p<11;p++)
	{
		OLED_DrawLine(5+p*7, 0, 5+p*7, 64);
	}
	for (p=0;p<10;p++)
	{
		OLED_DrawLine(5, p*7, 75, p*7);
	}
}
void setapoint()
{
	if ( keyvalue_game6==1)
	{
		if (xx_game6>5&&xx_game6<73)
		{
			if (yy_game6>4&&yy_game6<10) {if(map_game6[0][(xx_game6-7)/7]==3){map_game6[0][(xx_game6-7)/7]=1;p1get=1;}}
			else if (yy_game6>10&&yy_game6<18) {if(map_game6[1][(xx_game6-7)/7]==3){map_game6[1][(xx_game6-7)/7]=1;p1get=1;}}
			else if (yy_game6>18&&yy_game6<25) {if(map_game6[2][(xx_game6-7)/7]==3){map_game6[2][(xx_game6-7)/7]=1;p1get=1;}}
			else if (yy_game6>25&&yy_game6<32){if(map_game6[3][(xx_game6-7)/7]==3){map_game6[3][(xx_game6-7)/7]=1;p1get=1;}}
			else if (yy_game6>32&&yy_game6<38) {if(map_game6[4][(xx_game6-7)/7]==3){map_game6[4][(xx_game6-7)/7]=1;p1get=1;}}
			else if (yy_game6>38&&yy_game6<45){if(map_game6[5][(xx_game6-7)/7]==3){ map_game6[5][(xx_game6-7)/7]=1;p1get=1;}}
			else if (yy_game6>45&&yy_game6<52){ if(map_game6[6][(xx_game6-7)/7]==3){map_game6[6][(xx_game6-7)/7]=1;p1get=1;}}
			else if (yy_game6>52&&yy_game6<59) {if(map_game6[7][(xx_game6-7)/7]==3){map_game6[7][(xx_game6-7)/7]=1;p1get=1;}}
		}
	}
}
void getadd(u8 num)
{
	u8 ee,rr;
		for (rr=0;rr<8;rr++)
	{
		for (ee=0;ee<9;ee++)
			{
				if (map_game6[rr][ee]==3) {map_game6[rr][ee]=num;get=1;break;}
			}
			if (get==1) {get=0;break;}
	}
}
void judge()
{
	u8 v,vv;
	for(v=0;v<8;v++)
	for (vv=0;vv<9;vv++)
	{
		          if ((map_game6[v][vv]==2)&&(map_game6[v][vv+1]==2)&&(map_game6[v][vv+2]==2)&&(map_game6[v][vv+3]==2)&&(map_game6[v][vv+4]==2)) {win_game6=2;break;}
				    	if ((map_game6[v][vv]==2)&&(map_game6[v+1][vv]==2)&&(map_game6[v+2][vv]==2)&&(map_game6[v+3][vv]==2)&&(map_game6[v+4][vv]==2)) {win_game6=2;break;}
							if ((map_game6[v][vv]==2)&&(map_game6[v+1][vv+1]==2)&&(map_game6[v+2][vv+2]==2)&&(map_game6[v+3][vv+3]==2)&&(map_game6[v+4][vv+4]==2)) {win_game6=2;break;}
							if ((map_game6[v][vv]==2)&&(map_game6[v+1][vv-1]==2)&&(map_game6[v+2][vv-2]==2)&&(map_game6[v+3][vv-3]==2)&&(map_game6[v+4][vv-4]==2)) {win_game6=2;break;}
		          if ((map_game6[v][vv]==1)&&(map_game6[v][vv+1]==1)&&(map_game6[v][vv+2]==1)&&(map_game6[v][vv+3]==1)&&(map_game6[v][vv+4]==1)) {win_game6=1;break;}
			       	if ((map_game6[v][vv]==1)&&(map_game6[v+1][vv]==1)&&(map_game6[v+2][vv]==1)&&(map_game6[v+3][vv]==1)&&(map_game6[v+4][vv]==1)) {win_game6=1;break;}
							if ((map_game6[v][vv]==1)&&(map_game6[v+1][vv+1]==1)&&(map_game6[v+2][vv+2]==1)&&(map_game6[v+3][vv+3]==1)&&(map_game6[v+4][vv+4]==1)) {win_game6=1;break;}
							if ((map_game6[v][vv]==1)&&(map_game6[v+1][vv-1]==1)&&(map_game6[v+2][vv-2]==1)&&(map_game6[v+3][vv-3]==1)&&(map_game6[v+4][vv-4]==1)) {win_game6=1;break;}
													
  }
}
void repoint()
{
	u8 r,e,ee;
	for(r=0;r<8;r++)
{
	for (e=0;e<9;e++)
	{
				if ((map_game6[r][e]==1)&&(map_game6[r+1][e]==1)&&(map_game6[r+2][e]==1)&&(map_game6[r+3][e]==1))
				{
					if (map_game6[r-1][e]==3) {map_game6[r-1][e]=2;p2get=1;break;}else if(map_game6[r+4][e]==3){map_game6[r+4][e]=2;p2get=1;break;} 
				}
					if ((map_game6[r][e]==1)&&(map_game6[r][e+1]==1)&&(map_game6[r][e+2]==1)&&(map_game6[r][e+3]==1))
					{
						if (map_game6[r][e-1]==3) {map_game6[r][e-1]=2;p2get=1;break;}else if(map_game6[r][e+4]==3){map_game6[r][e+4]=2;p2get=1;break;} 
					}
					if ((map_game6[r][e]==1)&&(map_game6[r+1][e+1]==1)&&(map_game6[r+2][e+2]==1)&&(map_game6[r+3][e+3]==1))
			{
				if (map_game6[r-1][e-1]==3){map_game6[r-1][e-1]=2;p2get=1;break;}else if (map_game6[r+4][e+4]==3){map_game6[r+4][e+4]=2;p2get=1;break;}
			}
			if ((map_game6[r][e]==1)&&(map_game6[r-1][e+1]==1)&&(map_game6[r-2][e+2]==1)&&(map_game6[r-3][e+3]==1))
			{
				if (map_game6[r-4][e+4]==3){map_game6[r-4][e+4]=2;p2get=1;break;}else if (map_game6[r+1][e-1]==3){map_game6[r+1][e-1]=2;p2get=1;break;}//ÓÅÏÈÈý¸öÆå×ÓÎÞÈ±¿Ú
			}
	
			if ((map_game6[r][e]==1)&&(map_game6[r+3][e]==1)&&(map_game6[r-1][e]==3)&&(map_game6[r+4][e]==3))    //Æä´ÎÈý¸öÆå×ÓÓÐÈ±¿Ú
				{
					if (map_game6[r+1][e]==1) { if(map_game6[r+2][e]==3){map_game6[r+2][e]=2;p2get=1;break;}}
					if (map_game6[r+2][e]==1) { if(map_game6[r+1][e]==3){map_game6[r+1][e]=2;p2get=1;break;}} 
				}
					if ((map_game6[r][e]==1)&&(map_game6[r][e+3]==1)&&(map_game6[r][e-1]==3)&&(map_game6[r][e+4]==3))
					{
							if (map_game6[r][e+1]==1) { if(map_game6[r][e+2]==3){map_game6[r][e+2]=2;p2get=1;break;}}
					    if (map_game6[r][e+2]==1) { if(map_game6[r][e+1]==3){map_game6[r][e+1]=2;p2get=1;break;}} 
					}
					if ((map_game6[r][e]==1)&&(map_game6[r+3][e+3]==1)&&(map_game6[r-1][e-1]==3)&&(map_game6[r+4][e+4]==3))
			{
				if (map_game6[r+1][e+1]==1){if (map_game6[r+2][e+2]==3){map_game6[r+2][e+2]=2;p2get=1;break;}}else if (map_game6[r+2][e+2]==1){if (map_game6[r+1][e+1]==3){map_game6[r+1][e+1]=2;p2get=1;break;}}
			}
			if ((map_game6[r][e]==1)&&(map_game6[r-3][e+3]==1)&&(map_game6[r+1][e-1]==3)&&(map_game6[r-4][e+4]==3))
			{
				if (map_game6[r-1][e+1]==1){if (map_game6[r-2][e+2]==3) {map_game6[r-2][e+2]=2;p2get=1;break;}}else if (map_game6[r-2][e+2]==1){if (map_game6[r-1][e+1]==3) {map_game6[r-1][e+1]=2;p2get=1;break;}}
			}

						if ((map_game6[r][e]==1)&&(map_game6[r+3][e]==1))         //ÔÙ´ÎÈý¸öÆå×ÓÓÐÈ±¿Ú£¬µ«¶Â×¡Ò»Í·
				{
					if (map_game6[r+1][e]==1) { if(map_game6[r+2][e]==3){map_game6[r+2][e]=2;p2get=1;break;}}
					if (map_game6[r+2][e]==1) { if(map_game6[r+1][e]==3){map_game6[r+1][e]=2;p2get=1;break;}} 
				}
					if ((map_game6[r][e]==1)&&(map_game6[r][e+3]==1))
					{
							if (map_game6[r][e+1]==1) { if(map_game6[r][e+2]==3){map_game6[r][e+2]=2;p2get=1;break;}}
					    if (map_game6[r][e+2]==1) { if(map_game6[r][e+1]==3){map_game6[r][e+1]=2;p2get=1;break;}} 
					}
					if ((map_game6[r][e]==1)&&(map_game6[r+3][e+3]==1))
			{
				if (map_game6[r+1][e+1]==1){if (map_game6[r+2][e+2]==3){map_game6[r+2][e+2]=2;p2get=1;break;}}else if (map_game6[r+2][e+2]==1){if (map_game6[r+1][e+1]==3){map_game6[r+1][e+1]=2;p2get=1;break;}}
			}
			if ((map_game6[r][e]==1)&&(map_game6[r-3][e+3]==1))
			{
				if (map_game6[r-1][e+1]==1){if (map_game6[r-2][e+2]==3) {map_game6[r-2][e+2]=2;p2get=1;break;}}else if (map_game6[r-2][e+2]==1){if (map_game6[r-1][e+1]==3) {map_game6[r-1][e+1]=2;p2get=1;break;}}
			}
			
				if ((map_game6[r][e]==1)&&(map_game6[r+1][e]==1)&&(map_game6[r+2][e]==1)&&(map_game6[r-1][e]==3)&&(map_game6[r+3][e]==3))     //ÔÙÔÙ´ÎÈý¸öÆå×ÓÎÞÈ±¿Ú£¬µ«¶Â×¡Ò»Í·
				{
					if (map_game6[r-1][e]==3) {map_game6[r-1][e]=2;p2get=1;break;}else if(map_game6[r+3][e]==3){map_game6[r+3][e]=2;p2get=1;break;} 
				}
			if ((map_game6[r][e]==1)&&(map_game6[r][e+1]==1)&&(map_game6[r][e+2]==1)&&(map_game6[r][e-1]==3)&&(map_game6[r][e+3]==3))
					{
						if (map_game6[r][e-1]==3) {map_game6[r][e-1]=2;p2get=1;break;}else if(map_game6[r][e+3]==3){map_game6[r][e+3]=2;p2get=1;break;} 
					}

			if ((map_game6[r][e]==1)&&(map_game6[r+1][e+1]==1)&&(map_game6[r+2][e+2]==1)&&(map_game6[r-1][e-1]==3)&&(map_game6[r+3][e+3]==3))
			{
				if (map_game6[r-1][e-1]==3){map_game6[r-1][e-1]=2;p2get=1;break;}else if (map_game6[r+3][e+3]==3){map_game6[r+3][e+3]=2;p2get=1;break;}
			}
			if ((map_game6[r][e]==1)&&(map_game6[r-1][e+1]==1)&&(map_game6[r-2][e+2]==1)&&(map_game6[r-3][e+3]==3)&&(map_game6[r+1][e-1]==3))
			{
				if (map_game6[r-3][e+3]==3){map_game6[r-3][e+3]=2;p2get=1;break;}else if (map_game6[r+1][e-1]==3){map_game6[r+1][e-1]=2;p2get=1;break;}
			}

	}
	if (p2get==1) {p2get=0;p2set=1;break;}
	if (r==7&&e==8&&p2get==0) {p2set=0;break;}
}
	p1get=0;
	if (p2set==0)
	{
		for(r=0;r<8;r++)
		{
  	for (e=0;e<9;e++)
		{
			if (map_game6[r][e]==1) {
			ee=0;if (qaq==0) {for (ee=0;ee<9;ee++) {if (map_game6[r][e+ee]==3) {map_game6[r][e+ee]=2;break;}if (e+ee==8) {qaq=1;break;}}}
			if (qaq==1)  {for (ee=0;ee<8;ee++){if (map_game6[r+ee][e]==3){map_game6[r+ee][e]=2;break;}if (r+ee==7) {qaq=2;break;}}}
			if (qaq==2) {for (ee=0;ee<8;ee++){if (map_game6[r+ee][r+ee]==3){map_game6[r+ee][r+ee]=2;break;}if (r+ee==7||e+ee==8){qaq=3;break;}}}
			if (qaq==3) getadd(2);
			p2set=1;break;
			}
		}
			if (p2set==1) {break;}
		}
	}
	p2set=0;
}
void drawmap()
{
	u8 j,k;
	for (j=0;j<8;j++)
	for (k=0;k<9;k++)
	{
		if (map_game6[j][k]==1) OLED_DrawCircle(5+k*7+7, j*7+7,2,OLED_UNFILLED );
		else if (map_game6[j][k]==2) OLED_DrawCircle(5+k*7+7, j*7+7,2,OLED_FILLED );
		
	}
}
void game6(void)
{
int8_t p;
		dack=0;
dackdh();
	dack=0;

	 LK=0;		

	xi_game6=xnadc_count_x_6;
	yi_game6=xnadc_count_y_6;
	pageini();
	OLED_ReverseArea(0, 0, 128, 64);
	mapini();
	TIM_Cmd(TIM3,ENABLE);

	while (1)
	{
lightdh();

		if (win_game6==0)
		{
	OLED_ClearArea(0, 0, 128, 64);
		getad_game6();
		pageini();
		setapoint();
		 judge();
		 if (p1get==1)	repoint();
		drawmap();
		OLED_DrawLine(xx_game6-2, yy_game6-2, xx_game6+2,yy_game6+2);
		OLED_DrawLine(xx_game6+2, yy_game6-2, xx_game6-2, yy_game6+2);
		OLED_ReverseArea(0, 0, 128, 64);
	/*	OLED_ShowNum(75, 30,wina,2, OLED_8X16);
		OLED_ShowNum(95, 30,winb,2, OLED_8X16);
		*/
	        OLED_ShowNum(122,58,state_game6,1,OLED_6X8);

		OLED_Update();
		 keyvalue_game6=0;
		}
	else if (win_game6==1)
	{

	OLED_Clear();

				OLED_ShowString1(60,30,"YOU WIN!", OLED_8X16);OLED_Update();
OLED_Update();
 x_game6=0,y_game6=0,xx_game6=0,yy_game6=0,xxx_game6=0,yyy_game6=0,xi_game6=0,yi_game6=0;
key_game6=0, keyvalue_game6=0;
 qaq=0,get=0;
 for(int save_oo=0;save_oo<=7;save_oo++)
		   		   for(int save_oo1=0;save_oo1<=8;save_oo1++)
 map_game6[save_oo][save_oo1]=0;

 p1get=0,p2get=0,p2set=0,p1set=0;
win_game6=0;


	
		dackdh();
LK=0;
	TIM_Cmd(TIM3,DISABLE);

		break;
	}
	else if (win_game6==2)
	{
OLED_Clear();
				OLED_ShowString1(60,30,"YOU LOST!", OLED_8X16);OLED_Update();
OLED_Update();

x_game6=0,y_game6=0,xx_game6=0,yy_game6=0,xxx_game6=0,yyy_game6=0,xi_game6=0,yi_game6=0;
key_game6=0, keyvalue_game6=0;
 qaq=0,get=0;
 for(int save_oo=0;save_oo<=7;save_oo++)
		   		   for(int save_oo1=0;save_oo1<=8;save_oo1++)
 map_game6[save_oo][save_oo1]=0;

 p1get=0,p2get=0,p2set=0,p1set=0;
win_game6=0;

		dackdh();
LK=0;	
	TIM_Cmd(TIM3,DISABLE);

		break;
	}

	if(state_game6==3){
if(KEY_game6==2){
	
x_game6=0,y_game6=0,xx_game6=0,yy_game6=0,xxx_game6=0,yyy_game6=0,xi_game6=0,yi_game6=0;
key_game6=0, keyvalue_game6=0;
 qaq=0,get=0;
 for(int save_oo=0;save_oo<=7;save_oo++)
		   		   for(int save_oo1=0;save_oo1<=8;save_oo1++)
 map_game6[save_oo][save_oo1]=0;

 p1get=0,p2get=0,p2set=0,p1set=0;
win_game6=0;
	dackdh();
LK=0;	TIM_Cmd(TIM3,DISABLE);

	break;
}}
	}


}
