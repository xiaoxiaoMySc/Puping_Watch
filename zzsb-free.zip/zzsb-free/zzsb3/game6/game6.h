#ifndef __GAME6_H
#define __GAME6_H
void game6();
extern u8 key_game6,qaq;
#endif